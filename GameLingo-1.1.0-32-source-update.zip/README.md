# Game Lingo iPhone 1.1.0+32 — Corresponding Source

The iPhone client is distributed under LICENSE-iOS: GNU AGPL-3.0-or-later
with the included OpenSSL and application-store additional permissions.
Copyright for Game Lingo client changes: Mustafa SENOCAK, 2026.
Third-party files retain their copyright and license notices. No server,
admin application, user data, PSN registration, API key, signing identity,
provisioning profile or device diagnostic record is included.

This version supports foreground translation. Screen-lock/background speech
is not advertised or enabled. The app keeps the iOS 15.5 deployment target.
Apple on-device Translation is used when the OS/language pair supports it;
on older iOS versions the Game Lingo online translation service is required.

## Contents and reproducible build inputs

- Flutter/Dart iPhone client, assets, tests and Xcode project.
- Apple Vision camera reader and Apple Translation bridge.
- Native PS5 bridge and patched chiaki-ng core (upstream revision
  ee7d5d8b2bdd32d0f1e4b9bdd466e738f4e62a4a); fmt 12.2.0 is header-only.
- Exact OpenSSL/curl source archives and public Dart/plugin source packages.
- pubspec.lock and TOOLCHAIN.json pin dependencies and the Flutter revision.
- SOURCE-MANIFEST.json lists SHA-256 for every source file in this archive.

## Build on macOS

Use Xcode 27.2, Python 3.9+, CMake, Ninja, Perl and CocoaPods 1.17.0.
Install Flutter 3.47.5 at framework revision
6a19cca56475dbfba1478ee68d7bd0c2ef891da1. Its unmodified SDK, Dart/Flutter runtime
source and licenses are available from the official Flutter repositories:
https://github.com/flutter/flutter/tree/6a19cca56475dbfba1478ee68d7bd0c2ef891da1
https://github.com/flutter/flutter/tree/6a19cca56475dbfba1478ee68d7bd0c2ef891da1/engine
The unmodified Flutter framework and native engine source are also included
in dependency-sources/flutter. Dart SDK toolchain source: https://github.com/dart-lang/sdk
See TOOLCHAIN.json and the engine DEPS file for exact toolchain/dependency revisions.
Run these commands at the extracted project root (Flutter must be on PATH):

    flutter pub get
    python3 tool/remote_play_lab/ios/build_engine.py --minimum-ios 15.5
    GAME_LINGO_APP_STORE_RELEASE=1 flutter build ios --release --no-codesign --config-only --build-name=1.1.0 --build-number=32 --dart-define=GAME_LINGO_TV_ENABLED=true --dart-define=GAME_LINGO_PS5_ENABLED=true
    cd ios
    GAME_LINGO_APP_STORE_RELEASE=1 pod install
    cd ..
    GAME_LINGO_APP_STORE_RELEASE=1 xcodebuild -workspace ios/Runner.xcworkspace -scheme Runner -configuration Release -sdk iphoneos -destination generic/platform=iOS IPHONEOS_DEPLOYMENT_TARGET=15.5 CODE_SIGNING_ALLOWED=NO build

Use your own bundle/team signing settings to install on your devices. Apple
signing credentials are deliberately not included. Service endpoints are public
client configuration; access to paid third-party services remains subject to
those services' terms and availability. Source rights do not require a Premium
subscription. This package does not license Sony trademarks or grant PSN access.

## Changes to upstream components

The iOS core uses MIT fmt and the already vendored fast_float parser instead
of libc++ APIs unavailable on iOS 15.5. The provider retains earlier DTLS and
certificate-chain fixes. iOS native ML Kit binaries were removed; local MIT
Dart/plugin forks retain Android declarations only. Android is not a target of
this iPhone source release; backend and admin code are not relicensed.
