import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'tv/on_device_screen_translator.dart';
import 'vision/platform_text_recognizer.dart';
import 'package:http/http.dart' as http;
import 'package:image/image.dart' as img;
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'notifications/reminder_widgets.dart';
import 'tv/tv_connection_page.dart';
import 'voices/game_ai_voice_store.dart';
import 'tv/mac_voice_page.dart';
import 'tv/phone_audio_page.dart';
import 'tv/remote_play_bridge.dart';
import 'tv/translation_access.dart';
import 'tv/tv_premium_access.dart';
import 'tv/tv_premium_proof.dart';
import 'legal/source_information_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isIOS) {
    LicenseRegistry.addLicense(() async* {
      final text = await rootBundle.loadString('assets/licenses/GameLingo-AGPL.txt');
      yield LicenseEntryWithLineBreaks(['Game Lingo iOS', 'chiaki-ng'], text);
    });
  }

  // Uygulamanın varsayılan yönü dikeydir. Yalnızca canlı çeviri
  // ekranı kendi yaşam döngüsü boyunca landscape yönlerini ayrıca açar.
  await SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.portraitUp,
  ]);

  // Uygulama açılırken daha önce doğrulanmış Apple transaction'ı
  // yeniden backend üzerinden kontrol edilir. Böylece süresi dolmuş
  // veya iptal/revoke edilmiş bir abonelik yalnızca cihazdaki eski
  // SharedPreferences kaydı yüzünden Premium kalamaz.
  await AppStoreSubscriptionController.instance.initialize(
    refreshProduct: false,
    forceEntitlementRefresh: true,
  );
  TvPremiumAccess.verify = AppStoreSubscriptionController.instance.tvPremiumProof;
  TvPremiumAccess.openPremium = (context) => Navigator.of(context).push<void>(
    MaterialPageRoute<void>(builder: (_) => const PremiumPage()),
  );

  final voicePreview = const bool.fromEnvironment('GAME_LINGO_REMOTE_PLAY_PREVIEW') &&
      Platform.isIOS && await MacVoicePage.hasPairing();
  final phoneAudioPreview = const bool.fromEnvironment('GAME_LINGO_PHONE_AUDIO_PREVIEW') && Platform.isIOS;
  runApp(OyunCeviriApp(voicePreview: voicePreview, phoneAudioPreview: phoneAudioPreview));
}

// ============================================================
// OYUN BAZLI KARAKTER -> SES EŞLEŞTİRME
// ============================================================

class GameVoiceStore {
  static const String _storageKey = 'game_voice_assignments';

  static const String _manualStorageKey = 'game_voice_manual_overrides';

  // Eski sürümlerde atanmış sesleri ve eski karakter
  // profil önbelleğini sadece BİR KEZ temizlemek için.
  static const String _genderVoiceMigrationKey =
      'gender_voice_migration_v4_force_reset_done';

  static final Map<int, Map<String, String>> _gameAssignments = {};

  static final Map<int, Set<String>> _manualOverrides = {};

  static bool _loaded = false;

  static Future<void> loadFromStorage() async {
    if (_loaded) return;

    final prefs = await SharedPreferences.getInstance();

    final migrationDone = prefs.getBool(_genderVoiceMigrationKey) ?? false;

    if (!migrationDone) {
      // SADECE ses/karakter eşleştirmelerini sıfırla.
      // Kayıtlı oyunlara dokunulmaz.
      await prefs.remove(_storageKey);
      await prefs.remove(_manualStorageKey);
      await prefs.remove('character_profiles');

      _gameAssignments.clear();
      _manualOverrides.clear();

      await prefs.setBool(_genderVoiceMigrationKey, true);

      debugPrint(
        'SES MİGRASYONU V4: Tüm eski ses '
        'eşleştirmeleri ve karakter profilleri '
        'zorla temizlendi.',
      );
    }

    final raw = prefs.getString(_storageKey);

    _gameAssignments.clear();
    _manualOverrides.clear();

    if (raw != null && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);

        if (decoded is Map<String, dynamic>) {
          for (final entry in decoded.entries) {
            final gameId = int.tryParse(entry.key);

            if (gameId == null) {
              continue;
            }

            final value = entry.value;

            if (value is Map<String, dynamic>) {
              _gameAssignments[gameId] = value.map(
                (key, value) => MapEntry(key, value.toString()),
              );
            } else if (value is Map) {
              _gameAssignments[gameId] = Map<String, String>.from(
                value.map(
                  (key, value) => MapEntry(key.toString(), value.toString()),
                ),
              );
            }
          }
        }
      } catch (e) {
        debugPrint(
          'SES EŞLEŞTİRME KAYDI '
          'OKUNAMADI: $e',
        );
      }
    }

    // Ek güvenlik: generic tr-TR-language eski bir kayıttan
    // geri gelirse otomatik olarak sil.
    var removedGenericVoice = false;

    for (final gameEntry in _gameAssignments.entries) {
      final speakersToRemove = <String>[];

      for (final voiceEntry in gameEntry.value.entries) {
        final voiceKey = voiceEntry.value.toLowerCase();

        if (voiceKey.startsWith('tr-tr-language|')) {
          speakersToRemove.add(voiceEntry.key);
        }
      }

      for (final speaker in speakersToRemove) {
        gameEntry.value.remove(speaker);
        removedGenericVoice = true;
      }
    }

    if (removedGenericVoice) {
      final cleanedEncodable = <String, dynamic>{};

      for (final entry in _gameAssignments.entries) {
        cleanedEncodable[entry.key.toString()] = entry.value;
      }

      await prefs.setString(_storageKey, jsonEncode(cleanedEncodable));

      debugPrint(
        'GENERIC SES TEMİZLENDİ: '
        'tr-TR-language kaydı kaldırıldı.',
      );
    }

    final manualRaw = prefs.getString(_manualStorageKey);

    if (manualRaw != null && manualRaw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(manualRaw);

        if (decoded is Map<String, dynamic>) {
          for (final entry in decoded.entries) {
            final gameId = int.tryParse(entry.key);

            if (gameId == null) {
              continue;
            }

            final value = entry.value;

            if (value is List) {
              _manualOverrides[gameId] = value
                  .map((item) => item.toString().trim().toUpperCase())
                  .where((item) => item.isNotEmpty)
                  .toSet();
            }
          }
        }
      } catch (e) {
        debugPrint(
          'MANUEL SES KAYDI '
          'OKUNAMADI: $e',
        );
      }
    }

    _loaded = true;
  }

  static Future<void> _saveToStorage() async {
    final prefs = await SharedPreferences.getInstance();

    final encodable = <String, dynamic>{};

    for (final entry in _gameAssignments.entries) {
      encodable[entry.key.toString()] = entry.value;
    }

    await prefs.setString(_storageKey, jsonEncode(encodable));

    final manualEncodable = <String, dynamic>{};

    for (final entry in _manualOverrides.entries) {
      manualEncodable[entry.key.toString()] = entry.value.toList();
    }

    await prefs.setString(_manualStorageKey, jsonEncode(manualEncodable));
  }

  static Map<String, String> assignmentsForGame(int gameId) {
    return _gameAssignments.putIfAbsent(gameId, () => <String, String>{});
  }

  static String normalizeSpeaker(String speaker) {
    return speaker.trim().toUpperCase();
  }

  static String? getVoiceKey({required int gameId, required String speaker}) {
    final assignments = assignmentsForGame(gameId);

    return assignments[normalizeSpeaker(speaker)];
  }

  static bool isManualOverride({required int gameId, required String speaker}) {
    final normalized = normalizeSpeaker(speaker);

    return _manualOverrides[gameId]?.contains(normalized) ?? false;
  }

  static Future<void> assignVoice({
    required int gameId,
    required String speaker,
    required String voiceKey,
    bool manual = false,
  }) async {
    final normalized = normalizeSpeaker(speaker);

    final assignments = assignmentsForGame(gameId);

    assignments[normalized] = voiceKey;

    final manualSet = _manualOverrides.putIfAbsent(gameId, () => <String>{});

    if (manual) {
      manualSet.add(normalized);
    } else {
      manualSet.remove(normalized);
    }

    await _saveToStorage();
  }

  static Set<String> usedVoiceKeys(int gameId) {
    return assignmentsForGame(gameId).values.toSet();
  }

  static Future<void> removeGameData(int gameId) async {
    _gameAssignments.remove(gameId);
    _manualOverrides.remove(gameId);
    await _saveToStorage();
    await GameAiVoiceStore.removeGameData(gameId);
  }
}

// ============================================================
// ELEVENLABS KARAKTER SESİ MANUEL SEÇİMİ
// ============================================================

// ============================================================
// OYUN BAZLI KARAKTER PROFİLİ ÖNBELLEĞİ
// ============================================================
//
// Backend'den çözülen karakter bilgilerini cihazda saklar.
// Böylece Arthur gibi bir karakter her altyazıda tekrar IGDB'ye sorulmaz.
//

class CharacterProfileStore {
  static const String _storageKey = 'character_profiles';

  static final Map<String, CharacterProfile> _profiles = {};

  static bool _loaded = false;

  static String _key({required int gameId, required String speaker}) {
    return '$gameId|${speaker.trim().toUpperCase()}';
  }

  static Future<void> loadFromStorage() async {
    if (_loaded) return;

    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);

    _profiles.clear();

    if (raw != null && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);

        if (decoded is Map<String, dynamic>) {
          for (final entry in decoded.entries) {
            final value = entry.value;

            if (value is Map<String, dynamic>) {
              _profiles[entry.key] = CharacterProfile.fromJson(value);
            } else if (value is Map) {
              _profiles[entry.key] = CharacterProfile.fromJson(
                Map<String, dynamic>.from(value),
              );
            }
          }
        }
      } catch (e) {
        debugPrint('KARAKTER PROFİL KAYDI OKUNAMADI: $e');
      }
    }

    _loaded = true;
  }

  static CharacterProfile? get({required int gameId, required String speaker}) {
    return _profiles[_key(gameId: gameId, speaker: speaker)];
  }

  static Future<void> save({
    required int gameId,
    required String speaker,
    required CharacterProfile profile,
  }) async {
    _profiles[_key(gameId: gameId, speaker: speaker)] = profile;

    final prefs = await SharedPreferences.getInstance();

    final encodable = <String, dynamic>{};

    for (final entry in _profiles.entries) {
      encodable[entry.key] = entry.value.toJson();
    }

    await prefs.setString(_storageKey, jsonEncode(encodable));
  }

  static Future<void> removeGameData(int gameId) async {
    final prefix = '$gameId|';

    _profiles.removeWhere((key, value) => key.startsWith(prefix));

    final prefs = await SharedPreferences.getInstance();

    final encodable = <String, dynamic>{};

    for (final entry in _profiles.entries) {
      encodable[entry.key] = entry.value.toJson();
    }

    await prefs.setString(_storageKey, jsonEncode(encodable));
  }
}

// Shared visual language. Kept in this file so main.dart remains drop-in ready.
abstract final class AppDesign {
  static const background = Color(0xFF0B1018);
  static const surface = Color(0xFF141C28);
  static const surfaceRaised = Color(0xFF1C2736);
  static const border = Color(0xFF293548);
  static const primary = Color(0xFF79E2C3);
  static const lavender = Color(0xFFB4ABFF);
  static const text = Color(0xFFF2F5FA);
  static const muted = Color(0xFF9AA9BE);

  static ThemeData get theme {
    final scheme =
        ColorScheme.fromSeed(
          seedColor: primary,
          brightness: Brightness.dark,
        ).copyWith(
          primary: primary,
          onPrimary: background,
          secondary: lavender,
          onSecondary: background,
          surface: surface,
          onSurface: text,
          onSurfaceVariant: muted,
          outline: border,
          error: const Color(0xFFFF909A),
        );
    final base = ThemeData(useMaterial3: true, colorScheme: scheme);
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
    );
    return base.copyWith(
      scaffoldBackgroundColor: background,
      canvasColor: surface,
      textTheme: base.textTheme
          .apply(bodyColor: text, displayColor: text)
          .copyWith(
            headlineLarge: const TextStyle(
              fontSize: 36,
              height: 1.12,
              letterSpacing: -1.3,
              fontWeight: FontWeight.w800,
              color: text,
            ),
            headlineMedium: const TextStyle(
              fontSize: 28,
              height: 1.2,
              letterSpacing: -0.8,
              fontWeight: FontWeight.w800,
              color: text,
            ),
            titleLarge: const TextStyle(
              fontSize: 21,
              height: 1.25,
              letterSpacing: -0.4,
              fontWeight: FontWeight.w700,
              color: text,
            ),
            titleMedium: const TextStyle(
              fontSize: 16,
              height: 1.4,
              fontWeight: FontWeight.w600,
              color: text,
            ),
            bodyLarge: const TextStyle(fontSize: 16, height: 1.55, color: text),
            bodyMedium: const TextStyle(fontSize: 14, height: 1.5, color: text),
            bodySmall: const TextStyle(fontSize: 12, height: 1.5, color: muted),
          ),
      appBarTheme: const AppBarTheme(
        backgroundColor: background,
        foregroundColor: text,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: text,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
        systemOverlayStyle: SystemUiOverlayStyle.light,
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: background,
          disabledBackgroundColor: surfaceRaised,
          disabledForegroundColor: muted,
          minimumSize: const Size(48, 56),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
          elevation: 0,
          shape: shape,
          textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: text,
          side: const BorderSide(color: border),
          minimumSize: const Size(48, 52),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: shape,
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          minimumSize: const Size(48, 48),
          foregroundColor: primary,
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(
          minimumSize: const Size(48, 48),
          foregroundColor: text,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        hintStyle: const TextStyle(color: muted, fontSize: 14),
        prefixIconColor: muted,
        suffixIconColor: muted,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 18,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: primary, width: 1.5),
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: const BorderSide(color: border),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        dragHandleColor: border,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: surfaceRaised,
        contentTextStyle: const TextStyle(color: text),
        behavior: SnackBarBehavior.floating,
        shape: shape,
      ),
      dividerTheme: const DividerThemeData(
        color: border,
        thickness: 1,
        space: 1,
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: primary,
        linearTrackColor: surfaceRaised,
      ),
      sliderTheme: base.sliderTheme.copyWith(
        activeTrackColor: primary,
        inactiveTrackColor: border,
        thumbColor: primary,
        trackHeight: 4,
      ),
      tooltipTheme: const TooltipThemeData(
        waitDuration: Duration(milliseconds: 500),
      ),
    );
  }
}

class OyunCeviriApp extends StatelessWidget {
  const OyunCeviriApp({super.key, this.voicePreview = false, this.phoneAudioPreview = false});
  final bool voicePreview;
  final bool phoneAudioPreview;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Game Lingo',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF0D0D10),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C5CFF),
          brightness: Brightness.dark,
        ),
      ),
      routes: {'/home': (_) => const OnboardingGate()},
      home: phoneAudioPreview ? const PhoneAudioPage() : voicePreview ? const MacVoicePage() : const OnboardingGate(),
    );
  }
}


// ============================================================
// İLK AÇILIŞ / UYGULAMA TANITIMI
// ============================================================
//
// Bu ekran yalnızca ilk kullanımda gösterilir.
// Kullanıcı "Atla" veya "Başla" dediğinde tamamlanma bilgisi
// SharedPreferences'a kaydedilir ve sonraki açılışlarda doğrudan
// mevcut HomePage gösterilir.
//
class OnboardingGate extends StatefulWidget {
  const OnboardingGate({super.key});

  @override
  State<OnboardingGate> createState() => _OnboardingGateState();
}

class _OnboardingGateState extends State<OnboardingGate> {
  bool? onboardingCompleted;

  @override
  void initState() {
    super.initState();
    _loadOnboardingState();
  }

  Future<void> _loadOnboardingState() async {
    final prefs = await SharedPreferences.getInstance();
    final completed =
        prefs.getBool(OnboardingPage.storageKey) ?? false;

    if (!mounted) return;

    setState(() {
      onboardingCompleted = completed;
    });
  }

  Future<void> _finishOnboarding() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(
      OnboardingPage.storageKey,
      true,
    );

    if (!mounted) return;

    setState(() {
      onboardingCompleted = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final completed = onboardingCompleted;

    if (completed == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D0D10),
        body: Center(
          child: SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: Color(0xFF7C5CFF),
            ),
          ),
        ),
      );
    }

    if (completed) {
      return const DailyReminderHost(child: HomePage());
    }

    return OnboardingPage(
      onFinished: _finishOnboarding,
    );
  }
}

class OnboardingPage extends StatefulWidget {
  static const String storageKey =
      'game_lingo_onboarding_completed_v1';

  final Future<void> Function() onFinished;

  const OnboardingPage({
    super.key,
    required this.onFinished,
  });

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  static const Color _background = Color(0xFF0D0D10);
  static const Color _surface = Color(0xFF18181E);
  static const Color _surfaceRaised = Color(0xFF22222A);
  static const Color _border = Color(0xFF292932);
  static const Color _primary = Color(0xFF7C5CFF);
  static const Color _primarySoft = Color(0xFFB9AAFF);

  final PageController pageController = PageController();

  int currentPage = 0;
  bool isFinishing = false;

  static const List<_OnboardingSlideData> slides = [
    _OnboardingSlideData(
      assetPath: 'assets/onboarding_1.png',
      imageAlignment: Alignment(0, -0.05),
      icon: Icons.center_focus_strong_rounded,
      eyebrow: 'CANLI ÇEVİRİ',
      title: 'Oyun altyazılarını\nanında Türkçeleştir.',
      description:
          'Telefonunun kamerasını oyun ekranına yönelt. '
          'Game Lingo altyazıları algılar ve Türkçe karşılığını gösterir.',
      badgeIcon: Icons.videocam_outlined,
      badgeText: 'Kamera ile algılama',
    ),
    _OnboardingSlideData(
      assetPath: 'assets/onboarding_2.png',
      imageAlignment: Alignment(0, -0.10),
      icon: Icons.subtitles_rounded,
      eyebrow: 'AKILLI TARAMA',
      title: 'Sadece ekrana yönelt.\nAnında çevir.',
      description:
          'Tarama alanını oyundaki altyazının üzerine getir. '
          'Game Lingo metni gerçek zamanlı algılar ve çeviriyi gösterir.',
      badgeIcon: Icons.crop_free_rounded,
      badgeText: 'Oyuna özel tarama alanı',
    ),
    _OnboardingSlideData(
      assetPath: 'assets/onboarding_3.png',
      imageAlignment: Alignment(0, -0.12),
      icon: Icons.record_voice_over_rounded,
      eyebrow: 'TÜRKÇE SESLENDİRME',
      title: 'Karakterleri\nTürkçe dinle.',
      description:
          'Algılanan karakterlere uygun Türkçe sesler atanır. '
          'İstersen karakter seslerini daha sonra değiştirebilirsin.',
      badgeIcon: Icons.graphic_eq_rounded,
      badgeText: 'Karaktere özel ses',
    ),
    _OnboardingSlideData(
      assetPath: 'assets/onboarding_4.png',
      imageAlignment: Alignment(0, -0.04),
      icon: Icons.sports_esports_rounded,
      eyebrow: 'OYUN KÜTÜPHANEN',
      title: 'Favori oyunlarını ekle.\nHer zaman elinin altında.',
      description:
          'Oynadığın oyunları kütüphanene ekle, çeviri ayarlarını '
          'oyun bazında sakla ve istediğin zaman devam et.',
      badgeIcon: Icons.play_arrow_rounded,
      badgeText: 'Çeviriyi başlat',
    ),
  ];

  bool get isLastPage =>
      currentPage == slides.length - 1;

  Future<void> _complete() async {
    if (isFinishing) return;

    setState(() {
      isFinishing = true;
    });

    try {
      await widget.onFinished();
    } finally {
      if (mounted) {
        setState(() {
          isFinishing = false;
        });
      }
    }
  }

  Future<void> _next() async {
    if (isLastPage) {
      await _complete();
      return;
    }

    await pageController.nextPage(
      duration: const Duration(milliseconds: 360),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                22,
                12,
                14,
                4,
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: _primary,
                      borderRadius: BorderRadius.circular(13),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x337C5CFF),
                          blurRadius: 20,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Image.asset(
                      'assets/game_lingo_logo.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Game Lingo',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.3,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'Canlı oyun çevirmeni',
                        style: TextStyle(
                          color: Colors.white38,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  AnimatedOpacity(
                    opacity: isLastPage ? 0 : 1,
                    duration:
                        const Duration(milliseconds: 180),
                    child: IgnorePointer(
                      ignoring: isLastPage || isFinishing,
                      child: TextButton(
                        onPressed: _complete,
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white60,
                        ),
                        child: const Text(
                          'Atla',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: pageController,
                itemCount: slides.length,
                physics: const BouncingScrollPhysics(),
                onPageChanged: (index) {
                  setState(() {
                    currentPage = index;
                  });
                },
                itemBuilder: (context, index) {
                  return _OnboardingSlide(
                    data: slides[index],
                    background: _background,
                    surface: _surface,
                    surfaceRaised: _surfaceRaised,
                    border: _border,
                    primary: _primary,
                    primarySoft: _primarySoft,
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                22,
                8,
                22,
                22,
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment:
                        MainAxisAlignment.center,
                    children: List.generate(
                      slides.length,
                      (index) {
                        final active =
                            index == currentPage;

                        return AnimatedContainer(
                          duration: const Duration(
                            milliseconds: 220,
                          ),
                          curve: Curves.easeOut,
                          width: active ? 28 : 8,
                          height: 8,
                          margin:
                              const EdgeInsets.symmetric(
                            horizontal: 4,
                          ),
                          decoration: BoxDecoration(
                            color: active
                                ? _primary
                                : Colors.white12,
                            borderRadius:
                                BorderRadius.circular(99),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    height: 58,
                    child: FilledButton(
                      onPressed:
                          isFinishing ? null : _next,
                      style: FilledButton.styleFrom(
                        backgroundColor: _primary,
                        foregroundColor: Colors.white,
                        disabledBackgroundColor:
                            const Color(0xFF34343D),
                        disabledForegroundColor:
                            Colors.white60,
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(17),
                        ),
                      ),
                      child: AnimatedSwitcher(
                        duration: const Duration(
                          milliseconds: 180,
                        ),
                        child: isFinishing
                            ? const SizedBox(
                                key: ValueKey(
                                  'loading',
                                ),
                                width: 22,
                                height: 22,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth: 2.2,
                                  color: Colors.white,
                                ),
                              )
                            : Row(
                                key: ValueKey(
                                  isLastPage
                                      ? 'start'
                                      : 'next',
                                ),
                                mainAxisAlignment:
                                    MainAxisAlignment.center,
                                mainAxisSize:
                                    MainAxisSize.min,
                                children: [
                                  Text(
                                    isLastPage
                                        ? 'Game Lingo’yu Kullanmaya Başla'
                                        : 'Devam',
                                    style:
                                        const TextStyle(
                                      fontSize: 16,
                                      fontWeight:
                                          FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Icon(
                                    isLastPage
                                        ? Icons
                                            .sports_esports_rounded
                                        : Icons
                                            .arrow_forward_rounded,
                                    size: 21,
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardingSlideData {
  final String assetPath;
  final Alignment imageAlignment;
  final IconData icon;
  final String eyebrow;
  final String title;
  final String description;
  final IconData badgeIcon;
  final String badgeText;

  const _OnboardingSlideData({
    required this.assetPath,
    required this.imageAlignment,
    required this.icon,
    required this.eyebrow,
    required this.title,
    required this.description,
    required this.badgeIcon,
    required this.badgeText,
  });
}

class _OnboardingSlide extends StatelessWidget {
  final _OnboardingSlideData data;
  final Color background;
  final Color surface;
  final Color surfaceRaised;
  final Color border;
  final Color primary;
  final Color primarySoft;

  const _OnboardingSlide({
    required this.data,
    required this.background,
    required this.surface,
    required this.surfaceRaised,
    required this.border,
    required this.primary,
    required this.primarySoft,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final visualHeight =
            (constraints.maxHeight * 0.52)
                .clamp(210.0, 300.0)
                .toDouble();

        return SingleChildScrollView(
          physics:
              const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
            22,
            8,
            22,
            8,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: constraints.maxHeight - 16,
            ),
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: visualHeight,
                  width: double.infinity,
                  child: _OnboardingVisual(
                    data: data,
                    background: background,
                    surface: surface,
                    surfaceRaised: surfaceRaised,
                    border: border,
                    primary: primary,
                    primarySoft: primarySoft,
                  ),
                ),
                const SizedBox(height: 28),
                Text(
                  data.eyebrow,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: primarySoft,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2.1,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  data.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    height: 1.12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.8,
                  ),
                ),
                const SizedBox(height: 14),
                ConstrainedBox(
                  constraints:
                      const BoxConstraints(
                    maxWidth: 420,
                  ),
                  child: Text(
                    data.description,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 14,
                      height: 1.55,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _OnboardingVisual extends StatelessWidget {
  final _OnboardingSlideData data;
  final Color background;
  final Color surface;
  final Color surfaceRaised;
  final Color border;
  final Color primary;
  final Color primarySoft;

  const _OnboardingVisual({
    required this.data,
    required this.background,
    required this.surface,
    required this.surfaceRaised,
    required this.border,
    required this.primary,
    required this.primarySoft,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: border),
        boxShadow: const [
          BoxShadow(
            color: Color(0x26000000),
            blurRadius: 28,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            data.assetPath,
            fit: BoxFit.cover,
            alignment: data.imageAlignment,
            filterQuality: FilterQuality.high,
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0x08000000),
                  Color(0x16000000),
                  Color(0x46000000),
                ],
                stops: [0.0, 0.62, 1.0],
              ),
            ),
          ),
          Positioned(
            left: 14,
            bottom: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 11,
                vertical: 7,
              ),
              decoration: BoxDecoration(
                color: background.withValues(alpha: 0.84),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.10),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    data.badgeIcon,
                    size: 15,
                    color: primarySoft,
                  ),
                  const SizedBox(width: 7),
                  Text(
                    data.badgeText,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AppPageHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? eyebrow;
  final Widget? trailing;
  final VoidCallback? onBack;

  const AppPageHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.eyebrow,
    this.trailing,
    this.onBack,
  });

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      if (onBack != null) ...[
        IconButton.outlined(
          onPressed: onBack,
          tooltip: 'Geri',
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        const SizedBox(height: 24),
      ],
      if (eyebrow != null) ...[
        Text(
          eyebrow!,
          style: const TextStyle(
            color: AppDesign.primary,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 10),
      ],
      Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              title,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ),
          if (trailing != null) ...[const SizedBox(width: 12), trailing!],
        ],
      ),
      if (subtitle != null) ...[
        const SizedBox(height: 10),
        Text(
          subtitle!,
          style: const TextStyle(
            color: AppDesign.muted,
            height: 1.5,
            fontSize: 14,
          ),
        ),
      ],
    ],
  );
}

class GameCover extends StatelessWidget {
  final GameResult game;
  final double? width;
  final double? height;
  final double borderRadius;
  const GameCover({
    super.key,
    required this.game,
    this.width,
    this.height,
    this.borderRadius = 18,
  });

  Widget _fallback() => DecoratedBox(
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: game.id.isEven
            ? const [Color(0xFF314952), Color(0xFF142932)]
            : const [Color(0xFF373858), Color(0xFF1B2038)],
      ),
    ),
    child: Center(
      child: Icon(
        Icons.sports_esports_outlined,
        color: AppDesign.text.withValues(alpha: 0.5),
        size: width != null && width! < 100 ? 28 : 48,
      ),
    ),
  );

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(borderRadius),
    child: SizedBox(
      width: width,
      height: height,
      child: game.coverUrl == null || game.coverUrl!.trim().isEmpty
          ? _fallback()
          : Image.network(
              game.coverUrl!,
              fit: BoxFit.cover,
              errorBuilder: (_, error, stackTrace) => _fallback(),
              loadingBuilder: (_, child, progress) =>
                  progress == null ? child : _fallback(),
            ),
    ),
  );
}


// ============================================================
// OYUN KÜTÜPHANESİ -> BACKEND SENKRONİZASYONU
// ============================================================
//
// Amaç:
// - Oyunlarım listesi cihazda normal şekilde SharedPreferences'ta kalır.
// - Backend'e yalnızca rastgele uygulama-kurulum kimliği + oyun metadatası
//   gönderilir.
// - Backend kurulum kimliğinin kendisini değil SHA-256 özetini saklar.
// - Aynı kurulum aynı oyunu tekrar eklediğinde sayaç şişmez.
// - Oyun silinince bir sonraki senkronizasyonda aktif sayaçtan düşer.
// - Uygulama açılışında tam liste tekrar gönderildiği için kaçırılmış bir
//   ekleme/silme isteği sonraki açılışta kendini düzeltir.
//
class GameLibrarySyncService {
  static const String _installationIdKey =
      'game_library_installation_id_v1';

  static const String _backendBaseUrl =
      'https://api.gamelingo.app';

  static Future<void> _queue = Future<void>.value();

  static void scheduleSync(Iterable<GameResult> games) {
    final snapshot = List<GameResult>.of(
      games,
      growable: false,
    );

    _queue = _queue
        .then((_) => _sendSnapshot(snapshot))
        .catchError((Object error, StackTrace stackTrace) {
          debugPrint(
            'OYUN KÜTÜPHANESİ SENKRONİZASYON HATASI: $error',
          );
        });
  }

  static Future<String> _installationId() async {
    final prefs = await SharedPreferences.getInstance();

    final existing =
        prefs.getString(_installationIdKey)?.trim();

    if (existing != null && existing.length >= 24) {
      return existing;
    }

    final secureRandom = math.Random.secure();

    final bytes = List<int>.generate(
      32,
      (_) => secureRandom.nextInt(256),
      growable: false,
    );

    final generated =
        base64UrlEncode(bytes).replaceAll('=', '');

    await prefs.setString(
      _installationIdKey,
      generated,
    );

    return generated;
  }

  static Future<void> _sendSnapshot(
    List<GameResult> games,
  ) async {
    final installationId =
        await _installationId();

    final uri = Uri.parse(
      '$_backendBaseUrl/games/library/sync',
    );

    final payload = <String, dynamic>{
      'installationId': installationId,
      'games': games
          .map(
            (game) => <String, dynamic>{
              'id': game.id,
              'name': game.name,
              'coverUrl': game.coverUrl,
              'firstReleaseDate':
                  game.firstReleaseDate,
            },
          )
          .toList(growable: false),
    };

    final response = await http
        .post(
          uri,
          headers: const {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: jsonEncode(payload),
        )
        .timeout(
          const Duration(seconds: 8),
        );

    if (response.statusCode < 200 ||
        response.statusCode >= 300) {
      debugPrint(
        'OYUN KÜTÜPHANESİ SENKRONİZASYON REDDEDİLDİ: '
        'HTTP ${response.statusCode}',
      );

      return;
    }

    debugPrint(
      'OYUN KÜTÜPHANESİ SENKRONİZE: '
      '${games.length} oyun',
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const String _savedGamesKey = 'saved_games';

  final List<GameResult> savedGames = [];

  bool isLoadingSavedGames = true;

  @override
  void initState() {
    super.initState();

    loadSavedData();
  }

  Future<void> loadSavedData() async {
    await GameVoiceStore.loadFromStorage();

    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_savedGamesKey);

    final loadedGames = <GameResult>[];

    if (raw != null && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);

        if (decoded is List) {
          for (final item in decoded) {
            if (item is Map<String, dynamic>) {
              loadedGames.add(GameResult.fromJson(item));
            } else if (item is Map) {
              loadedGames.add(
                GameResult.fromJson(Map<String, dynamic>.from(item)),
              );
            }
          }
        }
      } catch (e) {
        debugPrint('KAYITLI OYUNLAR OKUNAMADI: $e');
      }
    }

    if (!mounted) return;

    setState(() {
      savedGames
        ..clear()
        ..addAll(loadedGames);

      isLoadingSavedGames = false;
    });

    // Mevcut kullanıcıların daha önce kaydettiği oyunlar da uygulama
    // güncellemesinden sonraki ilk açılışta admin sayaçlarına yansır.
    GameLibrarySyncService.scheduleSync(
      loadedGames,
    );
  }

  Future<void> saveGames() async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = savedGames.map((game) => game.toJson()).toList();

    await prefs.setString(_savedGamesKey, jsonEncode(encoded));
  }

  Future<void> openAddGamePage() async {
    final selectedGame = await Navigator.push<GameResult>(
      context,
      MaterialPageRoute(builder: (context) => const AddGamePage()),
    );

    if (selectedGame == null) return;

    final alreadyExists = savedGames.any((game) => game.id == selectedGame.id);

    if (!alreadyExists) {
      setState(() {
        savedGames.add(selectedGame);
      });

      await saveGames();

      GameLibrarySyncService.scheduleSync(
        savedGames,
      );
    }

    if (!mounted) return;

    // Oyun arama sonucuna dokunulduğunda kullanıcıyı ana ekranda
    // bırakmak yerine doğrudan oyun detay ekranına götür.
    // Oyun yine "Oyunlarım" listesine kaydedilmiş olarak kalır.
    openGame(selectedGame);
  }

  void openGame(GameResult game) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => GameDetailPage(game: game)),
    );
  }

  Future<void> removeGame(GameResult game) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Oyunu sil'),
          content: Text(
            '${game.name} Oyunlarım listesinden silinsin mi? '
            'Bu oyuna ait ses, tarama alanı ve kamera ayarları da temizlenecek.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Vazgeç'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFB94040),
              ),
              child: const Text('Sil'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    setState(() {
      savedGames.removeWhere((savedGame) => savedGame.id == game.id);
    });

    await saveGames();

    GameLibrarySyncService.scheduleSync(
      savedGames,
    );

    await Future.wait([
      GameVoiceStore.removeGameData(game.id),
      CharacterProfileStore.removeGameData(game.id),
      GameScanAreaStore.remove(game.id),
      GameCameraZoomStore.remove(game.id),
    ]);

    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${game.name} silindi.'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> openPs5Translation() async {
    await Navigator.of(context).push<void>(MaterialPageRoute(builder: (pageContext) {
      Future<void> premium() async {
        if (!pageContext.mounted) return;
        await Navigator.of(pageContext).push(MaterialPageRoute(builder: (_) => const PremiumPage(trialExpired: true)));
      }
      return PhoneAudioPage(access: TranslationAccess(
        request: () async {
          final premiumActive = await AppStoreSubscriptionController.instance.ensurePremiumAccess(forceServer: true);
          if (premiumActive || !await FreeTranslationTrialStore.isExhausted()) return true;
          await premium(); return false;
        },
        consumeSeconds: (seconds) async {
          final subscription = AppStoreSubscriptionController.instance;
          if (subscription.premiumActive && (subscription.premiumExpiresAt == null || DateTime.now().isBefore(subscription.premiumExpiresAt!))) return true;
          final used = await FreeTranslationTrialStore.loadUsedSeconds();
          final next = used + seconds;
          await FreeTranslationTrialStore.saveUsedSeconds(next);
          return next < FreeTranslationTrialStore.totalSeconds;
        },
        expired: premium,
      ));
    }));
  }

  void openPremiumPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PremiumPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Image.asset(
                      'assets/game_lingo_logo.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Game Lingo',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          'Canlı oyun çevirmeni',
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.white54,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  InkWell(
                    onTap: openPremiumPage,
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1B1828),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: const Color(0xFF7C5CFF),
                        ),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.workspace_premium_rounded,
                            size: 18,
                            color: Color(0xFFB9AAFF),
                          ),
                          SizedBox(width: 6),
                          Text(
                            'Premium',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFFD6CEFF),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              if (remotePlayEnabled && Platform.isIOS) ...[
                const SizedBox(height: 22),
                SizedBox(width: double.infinity, child: FilledButton.icon(
                  onPressed: openPs5Translation,
                  icon: const Icon(Icons.sports_esports_outlined),
                  label: const Text('PS5 · Kamerasız çeviri'),
                )),
              ],
              const SizedBox(height: 42),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Oyunlarım',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  if (tvRelayEnabled) const TvConnectButton(),
                  const ReminderSettingsButton(),
                  if (Platform.isIOS) IconButton(
                    tooltip: 'Kaynak kodu ve lisanslar', icon: const Icon(Icons.info_outline),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SourceInformationPage())),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Oynamak istediğin oyunu seç veya yeni bir oyun ekle.',
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.white54,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 28),
              Expanded(
                child: isLoadingSavedGames
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : savedGames.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 90,
                              height: 90,
                              decoration: BoxDecoration(
                                color: const Color(0xFF18181E),
                                borderRadius: BorderRadius.circular(26),
                              ),
                              child: const Icon(
                                Icons.sports_esports_rounded,
                                size: 42,
                                color: Colors.white38,
                              ),
                            ),
                            const SizedBox(height: 22),
                            const Text(
                              'Henüz oyun eklemedin',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'İlk oyununu ekleyerek\nçeviriye başlayabilirsin.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 14,
                                height: 1.5,
                                color: Colors.white38,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.separated(
                        itemCount: savedGames.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 14),
                        itemBuilder: (context, index) {
                          final game = savedGames[index];

                          return InkWell(
                            onTap: () => openGame(game),
                            borderRadius: BorderRadius.circular(18),
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFF18181E),
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(
                                  color: const Color(0xFF26262E),
                                ),
                              ),
                              child: Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(11),
                                    child: SizedBox(
                                      width: 76,
                                      height: 104,
                                      child: game.coverUrl != null
                                          ? Image.network(
                                              game.coverUrl!,
                                              fit: BoxFit.cover,
                                            )
                                          : const ColoredBox(
                                              color: Color(0xFF24242B),
                                              child: Icon(
                                                Icons.image_outlined,
                                                color: Colors.white38,
                                              ),
                                            ),
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Text(
                                      game.name,
                                      style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: () =>
                                        removeGame(
                                      game,
                                    ),
                                    tooltip:
                                        'Oyunu sil',
                                    icon: const Icon(
                                      Icons.delete_outline_rounded,
                                      color: Color(
                                        0xFFE57373,
                                      ),
                                    ),
                                  ),
                                  const Icon(
                                    Icons.chevron_right_rounded,
                                    color: Colors.white38,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
              SizedBox(
                width: double.infinity,
                height: 58,
                child: FilledButton.icon(
                  onPressed: openAddGamePage,
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF7C5CFF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(17),
                    ),
                  ),
                  icon: const Icon(Icons.add_rounded),
                  label: const Text(
                    'Yeni Oyun Ekle',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBrandHeader() => Row(
    children: [
      Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: AppDesign.primary,
          borderRadius: BorderRadius.circular(15),
        ),
        child: const Icon(
          Icons.translate_rounded,
          color: AppDesign.background,
          size: 25,
        ),
      ),
      const SizedBox(width: 12),
      const Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Game Lingo',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.5,
              ),
            ),
            Text(
              'Oyunun dilini değiştir.',
              style: TextStyle(fontSize: 11, color: AppDesign.muted),
            ),
          ],
        ),
      ),
      const SizedBox(width: 8),
      ListenableBuilder(
        listenable: AppStoreSubscriptionController.instance,
        builder: (context, child) =>
            MediaQuery.textScalerOf(context).scale(14) > 19
            ? IconButton.outlined(
                onPressed: openPremiumPage,
                tooltip: 'Premium',
                icon: const Icon(
                  Icons.auto_awesome_rounded,
                  color: AppDesign.lavender,
                ),
              )
            : OutlinedButton(
                onPressed: openPremiumPage,
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppDesign.lavender,
                  backgroundColor: AppDesign.lavender.withValues(alpha: 0.08),
                  side: BorderSide(
                    color: AppDesign.lavender.withValues(alpha: 0.25),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.auto_awesome_rounded, size: 16),
                    const SizedBox(width: 7),
                    Text(
                      AppStoreSubscriptionController.instance.premiumActive
                          ? 'Premium ✓'
                          : 'Premium',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
      ),
    ],
  );

  Widget _buildWelcome(bool roomy) {
    final copy = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'HER HİKÂYEYE DAHİL OL',
          style: TextStyle(
            color: AppDesign.primary,
            fontSize: 10,
            letterSpacing: 2.1,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'Oyuna odaklan.\nHikâyeyi kaçırma.',
          style: TextStyle(
            fontSize: roomy ? 42 : 32,
            height: 1.12,
            letterSpacing: -1.3,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'Altyazıları kameranla çevir,\ndiyalogları Türkçe dinle.',
          style: TextStyle(color: AppDesign.muted, fontSize: 14, height: 1.65),
        ),
        const SizedBox(height: 22),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _featurePill(
              Icons.center_focus_strong_rounded,
              'Kamera ile çeviri',
            ),
            _featurePill(Icons.graphic_eq_rounded, 'Türkçe seslendirme'),
          ],
        ),
      ],
    );
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF182932), AppDesign.surface, Color(0xFF1D2238)],
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppDesign.border),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -72,
            top: -72,
            child: ExcludeSemantics(
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppDesign.primary.withValues(alpha: 0.07),
                    width: 35,
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(roomy ? 32 : 24),
            child: roomy
                ? Row(
                    children: [
                      Expanded(flex: 6, child: copy),
                      const SizedBox(width: 32),
                      const Expanded(
                        flex: 5,
                        child: _TranslationIllustration(),
                      ),
                    ],
                  )
                : copy,
          ),
        ],
      ),
    );
  }

  Widget _featurePill(IconData icon, String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(
      color: AppDesign.background.withValues(alpha: 0.38),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: AppDesign.primary),
        const SizedBox(width: 7),
        Flexible(
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: AppDesign.text,
            ),
          ),
        ),
      ],
    ),
  );

  Widget _buildEmptyLibrary() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
    decoration: BoxDecoration(
      color: AppDesign.surface,
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: AppDesign.border),
    ),
    child: Column(
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            color: AppDesign.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(22),
          ),
          child: const Icon(
            Icons.sports_esports_outlined,
            color: AppDesign.primary,
            size: 30,
          ),
        ),
        const SizedBox(height: 18),
        const Text(
          'İlk hikâyen seni bekliyor',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 19,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Oyununu kütüphanene ekle.\nAltyazıları birlikte Türkçeye çevirelim.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 13, color: AppDesign.muted, height: 1.6),
        ),
      ],
    ),
  );

  Widget _buildLibraryCard(GameResult game) {
    final year = game.firstReleaseDate == null
        ? null
        : DateTime.fromMillisecondsSinceEpoch(
            game.firstReleaseDate! * 1000,
          ).year;
    return Material(
      color: AppDesign.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: const BorderSide(color: AppDesign.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => openGame(game),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GameCover(game: game, width: 78, height: 116, borderRadius: 13),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (year != null) ...[
                      Text(
                        '$year',
                        style: const TextStyle(
                          fontSize: 10,
                          color: AppDesign.muted,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 6),
                    ],
                    Text(
                      game.name,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15,
                        height: 1.3,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.2,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Row(
                      children: [
                        Icon(
                          Icons.play_arrow_rounded,
                          size: 14,
                          color: AppDesign.primary,
                        ),
                        SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            'Oyunu aç',
                            style: TextStyle(
                              fontSize: 11,
                              color: AppDesign.primary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                tooltip: '${game.name} için seçenekler',
                padding: EdgeInsets.zero,
                icon: const Icon(
                  Icons.more_vert_rounded,
                  color: AppDesign.muted,
                  size: 20,
                ),
                onSelected: (value) {
                  if (value == 'remove') removeGame(game);
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(
                    value: 'remove',
                    child: Row(
                      children: [
                        Icon(
                          Icons.delete_outline_rounded,
                          color: Color(0xFFFF909A),
                          size: 20,
                        ),
                        SizedBox(width: 10),
                        Flexible(child: Text('Kütüphaneden kaldır')),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TranslationIllustration extends StatelessWidget {
  const _TranslationIllustration();
  @override
  Widget build(BuildContext context) => ExcludeSemantics(
    child: Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppDesign.background.withValues(alpha: 0.55),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppDesign.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.closed_caption_outlined,
                size: 18,
                color: AppDesign.muted,
              ),
              SizedBox(width: 8),
              Text(
                'İNGİLİZCE',
                style: TextStyle(
                  color: AppDesign.muted,
                  fontSize: 10,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            'A new adventure awaits.',
            style: TextStyle(fontSize: 16, color: AppDesign.muted),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 18),
            child: Icon(
              Icons.south_rounded,
              size: 18,
              color: AppDesign.primary,
            ),
          ),
          const Text(
            'TÜRKÇE',
            style: TextStyle(
              color: AppDesign.primary,
              fontSize: 10,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'Yeni bir macera\nseni bekliyor.',
            style: TextStyle(
              fontSize: 23,
              height: 1.25,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: List.generate(
              24,
              (i) => Container(
                width: 3,
                height: [8.0, 14.0, 22.0, 12.0, 28.0, 18.0][i % 6],
                margin: const EdgeInsets.only(right: 4),
                decoration: BoxDecoration(
                  color: AppDesign.primary.withValues(
                    alpha: 0.3 + (i % 4) * 0.15,
                  ),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

// ============================================================
// PREMIUM ERİŞİM DURUMU
// ============================================================
//
// SharedPreferences artık Premium'un "asıl kaynağı" değildir.
// Burada yalnızca Apple backend doğrulamasının son sonucu cache'lenir.
//
// Gerçek akış:
//   iPhone StoreKit
//        ↓
//   transactionId
//        ↓
//   Railway /apple/subscription/verify
//        ↓
//   Apple App Store Server API
//
// Premium kararı backend'in Apple'dan aldığı sonuca göre verilir.
// Yerel cache yalnızca kısa süreli/offline kullanım kolaylığı içindir.
//
class PremiumEntitlementCache {
  const PremiumEntitlementCache({
    required this.active,
    required this.transactionId,
    required this.expiresAt,
    required this.lastVerifiedAt,
    required this.status,
  });

  final bool active;
  final String? transactionId;
  final DateTime? expiresAt;
  final DateTime? lastVerifiedAt;
  final String? status;

  bool get hasTransactionId =>
      transactionId != null && transactionId!.trim().isNotEmpty;

  bool get isLocallyUsable {
    if (!active || !hasTransactionId) {
      return false;
    }

    final now = DateTime.now().toUtc();
    final normalizedStatus = (status ?? '').toString().trim().toLowerCase();

    // Apple Billing Grace Period sırasında transaction expiresDate'i
    // geçmiş olabilir. Backend son 24 saat içinde grace-period olarak
    // doğruladıysa kısa süreli offline cache'e izin veriyoruz.
    if (normalizedStatus == 'billing_grace_period') {
      final verifiedAt = lastVerifiedAt;

      if (verifiedAt == null) {
        return false;
      }

      return now.difference(verifiedAt.toUtc()) <= const Duration(hours: 24);
    }

    final expiry = expiresAt;

    if (expiry != null) {
      return now.isBefore(expiry.toUtc());
    }

    // Apple aktif dedi ama expiresAt dönmediyse cache sonsuza kadar
    // açık kalmasın. En fazla 24 saat sonra yeniden server kontrolü şart.
    final verifiedAt = lastVerifiedAt;

    if (verifiedAt == null) {
      return false;
    }

    return now.difference(verifiedAt.toUtc()) <= const Duration(hours: 24);
  }

  bool get shouldRefreshFromServer {
    if (!hasTransactionId) {
      return false;
    }

    final now = DateTime.now().toUtc();
    final verifiedAt = lastVerifiedAt;

    if (verifiedAt == null) {
      return true;
    }

    if (now.difference(verifiedAt.toUtc()) >= const Duration(minutes: 5)) {
      return true;
    }

    final expiry = expiresAt;

    if (expiry != null &&
        !now.isBefore(expiry.toUtc().subtract(const Duration(seconds: 30)))) {
      return true;
    }

    if (!isLocallyUsable) {
      return true;
    }

    return false;
  }
}

class PremiumAccessStore {
  static const String _premiumActiveKey = 'game_lingo_premium_active_v1';

  static const String _transactionIdKey = 'game_lingo_apple_transaction_id_v1';

  static const String _expiresAtKey = 'game_lingo_apple_expires_at_v1';

  static const String _lastVerifiedAtKey =
      'game_lingo_apple_last_verified_at_v1';

  static const String _statusKey = 'game_lingo_apple_subscription_status_v1';

  static Future<PremiumEntitlementCache> loadEntitlement() async {
    final prefs = await SharedPreferences.getInstance();

    final active = prefs.getBool(_premiumActiveKey) ?? false;

    final transactionId = prefs.getString(_transactionIdKey)?.trim();

    final expiresAtRaw = prefs.getString(_expiresAtKey);

    final verifiedAtRaw = prefs.getString(_lastVerifiedAtKey);

    final status = prefs.getString(_statusKey)?.trim();

    return PremiumEntitlementCache(
      active: active,
      transactionId: transactionId == null || transactionId.isEmpty
          ? null
          : transactionId,
      expiresAt: expiresAtRaw == null ? null : DateTime.tryParse(expiresAtRaw),
      lastVerifiedAt: verifiedAtRaw == null
          ? null
          : DateTime.tryParse(verifiedAtRaw),
      status: status == null || status.isEmpty ? null : status,
    );
  }

  static Future<bool> isPremiumActive() async {
    final cache = await loadEntitlement();

    return cache.isLocallyUsable;
  }

  static Future<void> saveVerifiedEntitlement({
    required bool active,
    required String transactionId,
    required String status,
    DateTime? expiresAt,
  }) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(_premiumActiveKey, active);

    await prefs.setString(_transactionIdKey, transactionId);

    await prefs.setString(_statusKey, status);

    await prefs.setString(
      _lastVerifiedAtKey,
      DateTime.now().toUtc().toIso8601String(),
    );

    if (expiresAt == null) {
      await prefs.remove(_expiresAtKey);
    } else {
      await prefs.setString(_expiresAtKey, expiresAt.toUtc().toIso8601String());
    }
  }

  static Future<void> clearUnverifiedLegacyPremium() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(_premiumActiveKey, false);

    await prefs.remove(_expiresAtKey);

    await prefs.remove(_lastVerifiedAtKey);

    await prefs.remove(_statusKey);
  }
}

class _AppleSubscriptionVerificationResult {
  const _AppleSubscriptionVerificationResult({
    required this.authoritative,
    required this.premium,
    required this.status,
    required this.transactionId,
    required this.originalTransactionId,
    required this.expiresAt,
    required this.errorMessage,
    this.acknowledged,
  });

  final bool authoritative;
  final bool premium;
  final String status;
  final String? transactionId;
  final String? originalTransactionId;
  final DateTime? expiresAt;
  final String? errorMessage;
  final bool? acknowledged;

  String effectiveTransactionId(String fallback) {
    final original = originalTransactionId?.trim();

    if (original != null && original.isNotEmpty) {
      return original;
    }

    final transaction = transactionId?.trim();

    if (transaction != null && transaction.isNotEmpty) {
      return transaction;
    }

    return fallback;
  }
}

// ============================================================
// APP STORE ABONELİK YÖNETİCİSİ
// ============================================================
//
// App Store Connect Product ID:
//   gamelingo_monthly
//
// App Store Connect'te bu ürüne 3 günlük ücretsiz introductory offer
// tanımlandı.
//
// Satın alma/restore sonucu artık doğrudan Premium açmaz.
// Önce Railway backend transaction ID'yi Apple App Store Server API ile
// doğrular. Backend premium=true döndürürse erişim açılır.
//
class AppStoreSubscriptionController extends ChangeNotifier {
  AppStoreSubscriptionController._();

  static final AppStoreSubscriptionController instance =
      AppStoreSubscriptionController._();

  static const String productId = 'gamelingo_monthly';

  static const String backendBaseUrl = 'https://api.gamelingo.app';

  final InAppPurchase _inAppPurchase = InAppPurchase.instance;

  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;

  ProductDetails? product;

  bool isInitialized = false;
  bool isLoading = false;
  bool storeAvailable = false;
  bool purchasePending = false;
  bool restorePending = false;
  bool premiumActive = false;
  bool entitlementChecking = false;

  DateTime? premiumExpiresAt;
  String? premiumStatus;

  String? errorMessage;

  // iOS ve Android mağaza metinlerini aynı kod tabanından yönet.
  // Satın alma altyapısı in_app_purchase ile iki platformda da mağaza
  // ürününü sorgular; kullanıcıya gösterilen mağaza adı platforma göre değişir.
  bool get isGooglePlay => Platform.isAndroid;
  bool get isAppStore => Platform.isIOS;

  String get storeName => isGooglePlay ? 'Google Play' : 'App Store';

  String? get recurringDisplayPrice {
    final currentProduct = product;

    if (currentProduct == null) {
      return null;
    }

    if (isGooglePlay && currentProduct is GooglePlayProductDetails) {
      final index = currentProduct.subscriptionIndex;

      final offers = currentProduct.productDetails.subscriptionOfferDetails;

      if (index != null &&
          offers != null &&
          index >= 0 &&
          index < offers.length) {
        final pricingPhases = offers[index].pricingPhases;

        if (pricingPhases.isNotEmpty) {
          // free-trial-3d teklifinde ilk faz 0 TL,
          // son faz ise gerçek aylık yenileme fiyatıdır.
          return pricingPhases.last.formattedPrice;
        }
      }
    }

    return currentProduct.price;
  }

  String? _verificationIdForPurchase(PurchaseDetails purchase) {
    if (isGooglePlay) {
      final token = purchase.verificationData.serverVerificationData.trim();

      return token.isEmpty ? null : token;
    }

    final transactionId = purchase.purchaseID?.trim();

    return transactionId == null || transactionId.isEmpty
        ? null
        : transactionId;
  }

  // StoreKit aynı purchase update'i kısa aralıklarla birden fazla kez
  // yayınlayabiliyor. Stream callback'leri üst üste binerse aynı
  // transaction iki kere backend'e gönderilip iki kere completePurchase
  // çağrılabiliyor.
  //
  // _processingTransactionIds: şu anda doğrulanmakta olan transaction'lar.
  // _handledTransactionIds: bu uygulama oturumunda Apple tarafından
  // authoritative olarak doğrulanıp başarıyla tamamlanmış transaction'lar.
  final Set<String> _processingTransactionIds = <String>{};

  final Set<String> _handledTransactionIds = <String>{};

  Future<void> initialize({
    bool refreshProduct = true,
    bool forceEntitlementRefresh = false,
  }) async {
    bool recoverGooglePlayPurchase = false;

    if (!isInitialized) {
      isInitialized = true;

      final cache = await PremiumAccessStore.loadEntitlement();

      premiumActive = cache.isLocallyUsable;

      premiumExpiresAt = cache.expiresAt;

      premiumStatus = cache.status;

      // Uygulama Android'de silinip yeniden kurulunca SharedPreferences
      // tamamen temizlenir. Google Play aboneliği ise mağaza hesabında
      // yaşamaya devam eder. Bu nedenle cihazda doğrulanmış purchase token
      // yoksa aktif Google Play aboneliğini doğrudan Play Billing'den
      // yeniden bulup backend ile doğrulamamız gerekir.
      recoverGooglePlayPurchase = isGooglePlay && !cache.hasTransactionId;

      // Eski sürüm yalnızca bool=true saklıyordu. Transaction ID olmayan
      // bu kayıt artık güvenilir kabul edilmez. Kullanıcı mağazadan gerçek
      // satın alımını tekrar getirebilir.
      if (cache.active && !cache.hasTransactionId) {
        premiumActive = false;

        await PremiumAccessStore.clearUnverifiedLegacyPremium();

        debugPrint(
          'PREMIUM LEGACY CACHE TEMİZLENDİ: '
          'Doğrulanabilir mağaza kimliği yok.',
        );
      }

      _purchaseSubscription ??= _inAppPurchase.purchaseStream.listen(
        _handlePurchaseUpdates,
        onError: (Object error) {
          purchasePending = false;
          restorePending = false;
          errorMessage = 'Satın alma akışı hatası: $error';

          debugPrint('STORE PURCHASE STREAM HATASI: $error');

          notifyListeners();
        },
      );
    }

    if (recoverGooglePlayPurchase) {
      await _recoverGooglePlayOwnedSubscription(showUserError: false);
    }

    // Fresh-install kurtarma aktif satın alımı bulduysa _handlePurchaseUpdates
    // backend doğrulamasını zaten yapıp tokenı yerel cache'e kaydetti.
    // Bulamadıysa veya Play sorgusu geçici başarısız olduysa mevcut cache/token
    // üzerinden normal server kontrolüne devam ediyoruz.
    await ensurePremiumAccess(forceServer: forceEntitlementRefresh);

    if (refreshProduct) {
      await refreshStoreProduct();
    }
  }

  /// TV access always requires a fresh server decision, never the free timer
  /// or the offline Premium cache. The TV verifies the reference independently.
  Future<TvPremiumProof> tvPremiumProof() async {
    final cache = await PremiumAccessStore.loadEntitlement();
    final reference = cache.transactionId;
    if (reference == null || reference.isEmpty) {
      throw const TvPremiumException('premium_required');
    }
    final result = await _verifyTransactionWithBackend(reference);
    if (!result.authoritative) {
      throw const TvPremiumException('subscription_check_failed');
    }
    final verifiedReference = result.effectiveTransactionId(reference);
    premiumActive = result.premium;
    premiumExpiresAt = result.expiresAt;
    premiumStatus = result.status;
    await PremiumAccessStore.saveVerifiedEntitlement(
      active: result.premium, transactionId: verifiedReference,
      status: result.status, expiresAt: result.expiresAt,
    );
    notifyListeners();
    if (!result.premium) throw const TvPremiumException('premium_required');
    return TvPremiumProof(
      store: isGooglePlay ? 'google_play' : 'apple',
      verificationId: verifiedReference,
    );
  }

  Future<bool> ensurePremiumAccess({bool forceServer = false}) async {
    final cache = await PremiumAccessStore.loadEntitlement();

    premiumActive = cache.isLocallyUsable;

    premiumExpiresAt = cache.expiresAt;

    premiumStatus = cache.status;

    final transactionId = cache.transactionId?.trim();

    if (transactionId == null || transactionId.isEmpty) {
      notifyListeners();
      return false;
    }

    final shouldContactServer = forceServer || cache.shouldRefreshFromServer;

    if (!shouldContactServer) {
      notifyListeners();
      return premiumActive;
    }

    entitlementChecking = true;
    notifyListeners();

    try {
      final verification = await _verifyTransactionWithBackend(transactionId);

      if (!verification.authoritative) {
        debugPrint(
          'PREMIUM SERVER KONTROLÜ GEÇİCİ BAŞARISIZ: '
          '${verification.errorMessage ?? "bilinmeyen hata"}',
        );

        // Backend/Internet geçici olarak yoksa yalnızca hâlâ geçerli olan
        // son doğrulanmış cache kullanılır.
        premiumActive = cache.isLocallyUsable;

        return premiumActive;
      }

      final effectiveTransactionId = verification.effectiveTransactionId(
        transactionId,
      );

      premiumActive = verification.premium;

      premiumExpiresAt = verification.expiresAt;

      premiumStatus = verification.status;

      await PremiumAccessStore.saveVerifiedEntitlement(
        active: verification.premium,
        transactionId: effectiveTransactionId,
        status: verification.status,
        expiresAt: verification.expiresAt,
      );

      debugPrint(
        'PREMIUM SERVER KONTROLÜ ($storeName): '
        'premium=${verification.premium} | '
        'status=${verification.status} | '
        'expires=${verification.expiresAt?.toIso8601String() ?? "null"}',
      );

      return premiumActive;
    } finally {
      entitlementChecking = false;
      notifyListeners();
    }
  }

  Future<_AppleSubscriptionVerificationResult> _verifyTransactionWithBackend(
    String verificationId,
  ) async {
    final endpoint = isGooglePlay
        ? '/google/subscription/verify'
        : '/apple/subscription/verify';

    final uri = Uri.parse('$backendBaseUrl$endpoint');

    final requestBody = isGooglePlay
        ? <String, dynamic>{'purchaseToken': verificationId}
        : <String, dynamic>{'transactionId': verificationId};

    try {
      final response = await http
          .post(
            uri,
            headers: const {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: jsonEncode(requestBody),
          )
          .timeout(const Duration(seconds: 10));

      dynamic decoded;

      try {
        decoded = jsonDecode(response.body);
      } catch (_) {
        return _AppleSubscriptionVerificationResult(
          authoritative: false,
          premium: false,
          status: 'invalid_backend_response',
          transactionId: null,
          originalTransactionId: null,
          expiresAt: null,
          errorMessage:
              'Backend geçerli JSON döndürmedi. HTTP ${response.statusCode}.',
        );
      }

      if (decoded is! Map) {
        return const _AppleSubscriptionVerificationResult(
          authoritative: false,
          premium: false,
          status: 'invalid_backend_response',
          transactionId: null,
          originalTransactionId: null,
          expiresAt: null,
          errorMessage: 'Backend yanıt biçimi geçersiz.',
        );
      }

      final data = Map<String, dynamic>.from(decoded);

      // 5xx: mağaza API'si/backend geçici sorunu olabilir.
      // Son doğrulanmış ve hâlâ geçerli cache'i aniden kapatmıyoruz.
      if (response.statusCode >= 500) {
        return _AppleSubscriptionVerificationResult(
          authoritative: false,
          premium: false,
          status: (data['status'] ?? 'server_error').toString(),
          transactionId: null,
          originalTransactionId: null,
          expiresAt: null,
          errorMessage:
              (data['error'] ?? '$storeName doğrulama servisine ulaşılamadı.')
                  .toString(),
        );
      }

      final expiresAtText = data['expiresAt']?.toString();

      final expiresAt = expiresAtText == null || expiresAtText.trim().isEmpty
          ? null
          : DateTime.tryParse(expiresAtText);

      final status =
          (data['status'] ?? (data['premium'] == true ? 'active' : 'inactive'))
              .toString();

      // 2xx/4xx backend cevabı authoritative kabul edilir.
      // Örn. purchase_not_found / transaction_not_found Premium vermez.
      return _AppleSubscriptionVerificationResult(
        authoritative: true,
        premium: data['premium'] == true,
        status: status,
        transactionId: data['transactionId']?.toString(),
        originalTransactionId: data['originalTransactionId']?.toString(),
        expiresAt: expiresAt,
        errorMessage: data['error']?.toString(),
        acknowledged: data['acknowledged'] is bool
            ? data['acknowledged'] as bool
            : null,
      );
    } on TimeoutException {
      return _AppleSubscriptionVerificationResult(
        authoritative: false,
        premium: false,
        status: 'timeout',
        transactionId: null,
        originalTransactionId: null,
        expiresAt: null,
        errorMessage: '$storeName abonelik doğrulaması zaman aşımına uğradı.',
      );
    } on SocketException catch (e) {
      return _AppleSubscriptionVerificationResult(
        authoritative: false,
        premium: false,
        status: 'network_error',
        transactionId: null,
        originalTransactionId: null,
        expiresAt: null,
        errorMessage:
            '$storeName abonelik doğrulaması için internet bağlantısı yok: ${e.message}',
      );
    } catch (e) {
      return _AppleSubscriptionVerificationResult(
        authoritative: false,
        premium: false,
        status: 'verification_error',
        transactionId: null,
        originalTransactionId: null,
        expiresAt: null,
        errorMessage: '$storeName abonelik doğrulaması başarısız: $e',
      );
    }
  }

  Future<void> refreshStoreProduct() async {
    if (isLoading) {
      debugPrint('STOREKIT YENİLEME ATLANDI: zaten yükleniyor.');
      return;
    }

    isLoading = true;
    errorMessage = null;
    notifyListeners();

    debugPrint(
      'STOREKIT SORGU BAŞLADI | '
      'productId=$productId',
    );

    try {
      storeAvailable = await _inAppPurchase.isAvailable();

      debugPrint('STOREKIT AVAILABLE: $storeAvailable');

      if (!storeAvailable) {
        product = null;
        errorMessage = '$storeName satın alma servisine şu anda ulaşılamıyor.';
        return;
      }

      await queryProduct();
    } catch (e, st) {
      product = null;
      errorMessage = '$storeName bilgileri alınamadı: $e';

      debugPrint('STOREKIT SORGU EXCEPTION: $e');
      debugPrint('$st');
    } finally {
      isLoading = false;

      debugPrint(
        'STOREKIT SORGU BİTTİ | '
        'available=$storeAvailable | '
        'product=${product?.id ?? "null"} | '
        'price=${product?.price ?? "null"} | '
        'error=${errorMessage ?? "null"}',
      );

      notifyListeners();
    }
  }

  Future<void> queryProduct() async {
    errorMessage = null;

    final response = await _inAppPurchase.queryProductDetails(const <String>{
      productId,
    });

    debugPrint(
      'STOREKIT RESPONSE | '
      'requested=$productId | '
      'found=${response.productDetails.map((e) => e.id).toList()} | '
      'notFound=${response.notFoundIDs} | '
      'error=${response.error?.message ?? "null"}',
    );

    if (response.error != null) {
      errorMessage = response.error!.message;
    }

    if (response.notFoundIDs.contains(productId)) {
      product = null;
      errorMessage = '$storeName ürünü bulunamadı: $productId';
      notifyListeners();
      return;
    }

    if (response.productDetails.isEmpty) {
      product = null;
      errorMessage = 'Aylık abonelik bilgisi $storeName üzerinden alınamadı.';
      notifyListeners();
      return;
    }

    ProductDetails? matchedProduct;

    if (isGooglePlay) {
      GooglePlayProductDetails? trialProduct;

      GooglePlayProductDetails? monthlyBaseProduct;

      GooglePlayProductDetails? firstGoogleProduct;

      for (final item in response.productDetails) {
        if (item.id != productId || item is! GooglePlayProductDetails) {
          continue;
        }

        firstGoogleProduct ??= item;

        final index = item.subscriptionIndex;

        final offers = item.productDetails.subscriptionOfferDetails;

        if (index == null ||
            offers == null ||
            index < 0 ||
            index >= offers.length) {
          continue;
        }

        final offer = offers[index];

        debugPrint(
          'GOOGLE PLAY PLAN: '
          'basePlan=${offer.basePlanId} | '
          'offer=${offer.offerId ?? "none"} | '
          'phases=${offer.pricingPhases.map((e) => "${e.formattedPrice}/${e.billingPeriod}").toList()}',
        );

        if (offer.basePlanId == 'monthly' && offer.offerId == 'free-trial-3d') {
          trialProduct = item;
          continue;
        }

        if (offer.basePlanId == 'monthly' && offer.offerId == null) {
          monthlyBaseProduct ??= item;
        }
      }

      matchedProduct = trialProduct ?? monthlyBaseProduct ?? firstGoogleProduct;
    } else {
      for (final item in response.productDetails) {
        if (item.id == productId) {
          matchedProduct = item;
          break;
        }
      }
    }

    if (matchedProduct == null) {
      product = null;
      errorMessage =
          '$storeName ürünü listede döndü ancak eşleşme yapılamadı: $productId';
      notifyListeners();
      return;
    }

    product = matchedProduct;

    debugPrint(
      'MAĞAZA ÜRÜNÜ HAZIR: '
      '${product!.id} / ${product!.price}',
    );

    notifyListeners();
  }

  Future<void> buyMonthly() async {
    if (purchasePending) {
      return;
    }

    if (!storeAvailable) {
      errorMessage = '$storeName satın alma servisi kullanılamıyor.';
      notifyListeners();
      return;
    }

    if (product == null) {
      isLoading = true;
      notifyListeners();

      try {
        await queryProduct();
      } finally {
        isLoading = false;
        notifyListeners();
      }
    }

    final currentProduct = product;

    if (currentProduct == null) {
      return;
    }

    purchasePending = true;
    errorMessage = null;
    notifyListeners();

    try {
      late final PurchaseParam purchaseParam;

      if (isGooglePlay && currentProduct is GooglePlayProductDetails) {
        purchaseParam = GooglePlayPurchaseParam(
          productDetails: currentProduct,
          offerToken: currentProduct.offerToken,
        );

        debugPrint(
          'GOOGLE PLAY SATIN ALMA BAŞLATILIYOR: '
          'product=${currentProduct.id} | '
          'offerToken=${currentProduct.offerToken == null ? "none" : "present"}',
        );
      } else {
        purchaseParam = PurchaseParam(productDetails: currentProduct);
      }

      final started = await _inAppPurchase.buyNonConsumable(
        purchaseParam: purchaseParam,
      );

      if (!started) {
        purchasePending = false;
        errorMessage = 'Satın alma işlemi başlatılamadı.';
        notifyListeners();
      }
    } catch (e) {
      purchasePending = false;
      errorMessage = 'Satın alma başlatılamadı: $e';
      notifyListeners();
    }
  }

  Future<bool> _recoverGooglePlayOwnedSubscription({
    required bool showUserError,
  }) async {
    if (!isGooglePlay) {
      return false;
    }

    try {
      final androidAddition = _inAppPurchase
          .getPlatformAddition<InAppPurchaseAndroidPlatformAddition>();

      final response = await androidAddition.queryPastPurchases();

      if (response.error != null) {
        final message =
            'Google Play abonelik sorgusu başarısız: '
            '${response.error!.message}';

        debugPrint(message);

        if (showUserError) {
          errorMessage = message;
        }

        notifyListeners();
        return false;
      }

      final matchingPurchases = response.pastPurchases
          .where((purchase) => purchase.productID == productId)
          .toList();

      debugPrint(
        'GOOGLE PLAY OWNED SUBSCRIPTION SORGUSU: '
        'toplam=${response.pastPurchases.length} | '
        'gamelingo=${matchingPurchases.length}',
      );

      if (matchingPurchases.isEmpty) {
        if (showUserError) {
          errorMessage =
              'Bu Google Play hesabında aktif Game Lingo Premium aboneliği bulunamadı.';
        }

        notifyListeners();
        return false;
      }

      // queryPastPurchases aktif/owned Google Play satın alımlarını doğrudan
      // döndürür. Stream'i beklemek yerine aynı doğrulama hattından geçiriyoruz;
      // böylece uygulama silinip yeniden kurulduğunda da purchaseToken backend'e
      // gönderilir ve Premium cache yeniden oluşturulur.
      await _handlePurchaseUpdates(<PurchaseDetails>[...matchingPurchases]);

      return premiumActive;
    } catch (e) {
      final message = 'Google Play aboneliği geri yüklenemedi: $e';

      debugPrint(message);

      if (showUserError) {
        errorMessage = message;
      }

      notifyListeners();
      return false;
    }
  }

  Future<void> restorePurchases() async {
    if (restorePending) {
      return;
    }

    restorePending = true;
    errorMessage = null;
    notifyListeners();

    try {
      if (isGooglePlay) {
        // Android'de restorePurchases() sonucu purchaseStream üzerinden
        // asenkron geldiği için UI bazen doğrulama bitmeden "bulunamadı"
        // gösterebiliyordu. Aktif aboneliği doğrudan sorgulayıp sonucu burada
        // await ederek bu yarış durumunu kaldırıyoruz.
        await _recoverGooglePlayOwnedSubscription(showUserError: true);
      } else {
        await _inAppPurchase.restorePurchases();
      }
    } catch (e) {
      errorMessage = 'Satın alımlar geri yüklenemedi: $e';
    } finally {
      restorePending = false;
      notifyListeners();
    }
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.productID != productId) {
        continue;
      }

      if (purchase.status == PurchaseStatus.pending) {
        purchasePending = true;
        notifyListeners();
        continue;
      }

      if (purchase.status == PurchaseStatus.error) {
        purchasePending = false;
        restorePending = false;

        errorMessage =
            purchase.error?.message ?? 'Satın alma sırasında bir hata oluştu.';

        notifyListeners();
        continue;
      }

      if (purchase.status == PurchaseStatus.canceled) {
        purchasePending = false;
        restorePending = false;
        errorMessage = null;

        notifyListeners();
        continue;
      }

      if (purchase.status != PurchaseStatus.purchased &&
          purchase.status != PurchaseStatus.restored) {
        continue;
      }

      final transactionId = _verificationIdForPurchase(purchase);

      if (transactionId == null || transactionId.isEmpty) {
        premiumActive = false;
        purchasePending = false;
        restorePending = false;
        entitlementChecking = false;

        errorMessage = isGooglePlay
            ? 'Google Play satın alma işlemi geldi ancak purchase token alınamadı. '
                  'Satın Alımları Geri Yükle seçeneğini tekrar dene.'
            : 'App Store satın alma işlemi geldi ancak transaction ID alınamadı. '
                  'Satın Alımları Geri Yükle seçeneğini tekrar dene.';

        debugPrint(
          'STORE PURCHASE VERIFICATION ID YOK | '
          'store=$storeName | '
          'status=${purchase.status} | '
          'product=${purchase.productID}',
        );

        notifyListeners();
        continue;
      }

      // Aynı transaction bu uygulama oturumunda zaten başarıyla
      // işlendi ve completePurchase tamamlandıysa tekrar hiçbir şey yapma.
      if (_handledTransactionIds.contains(transactionId)) {
        debugPrint(
          'APPLE PURCHASE DUPLICATE ATLANDI | '
          'transactionId=$transactionId | '
          'reason=already_handled',
        );

        continue;
      }

      // Stream aynı transaction'ı ilk doğrulama hâlâ devam ederken
      // yeniden yayınlayabilir. Set.add false dönerse aynı transaction
      // zaten başka bir callback tarafından işleniyordur.
      final acquiredProcessingLock = _processingTransactionIds.add(
        transactionId,
      );

      if (!acquiredProcessingLock) {
        debugPrint(
          'APPLE PURCHASE DUPLICATE ATLANDI | '
          'transactionId=$transactionId | '
          'reason=verification_in_flight',
        );

        continue;
      }

      bool serverAnsweredAuthoritatively = false;

      bool completePurchaseSucceeded = !purchase.pendingCompletePurchase;

      purchasePending = true;
      entitlementChecking = true;
      errorMessage = null;
      notifyListeners();

      try {
        debugPrint(
          'STORE PURCHASE BACKEND DOĞRULAMA BAŞLADI | '
          'store=$storeName | '
          'status=${purchase.status} | '
          'verificationId=${isGooglePlay ? "purchaseToken" : "transactionId"}',
        );

        final verification = await _verifyTransactionWithBackend(transactionId);

        serverAnsweredAuthoritatively = verification.authoritative;

        if (verification.authoritative) {
          final effectiveTransactionId = verification.effectiveTransactionId(
            transactionId,
          );

          premiumActive = verification.premium;

          premiumExpiresAt = verification.expiresAt;

          premiumStatus = verification.status;

          await PremiumAccessStore.saveVerifiedEntitlement(
            active: verification.premium,
            transactionId: effectiveTransactionId,
            status: verification.status,
            expiresAt: verification.expiresAt,
          );

          if (verification.premium) {
            errorMessage = null;

            debugPrint(
              'PREMIUM $storeName TARAFINDAN DOĞRULANDI: '
              '${purchase.status} / '
              '${purchase.productID} / '
              'status=${verification.status} / '
              'expires=${verification.expiresAt?.toIso8601String() ?? "null"}',
            );
          } else {
            errorMessage = purchase.status == PurchaseStatus.restored
                ? 'Geri yükleme tamamlandı ancak $storeName aktif bir Game Lingo Premium aboneliği göstermiyor.'
                : 'Satın alma $storeName tarafından kontrol edildi ancak abonelik şu anda aktif görünmüyor.';

            debugPrint(
              'PREMIUM REDDEDİLDİ: '
              'status=${verification.status}',
            );
          }
        } else {
          // Backend/Apple geçici olarak cevap veremediyse transaction'ı
          // tamamlamıyoruz ve handled listesine almıyoruz. Böylece StoreKit
          // daha sonra yeniden yayınladığında tekrar doğrulanabilir.
          final cache = await PremiumAccessStore.loadEntitlement();

          premiumActive = cache.isLocallyUsable;

          errorMessage =
              verification.errorMessage ??
              '$storeName abonelik doğrulaması şu anda yapılamadı. İnternet bağlantını kontrol edip tekrar dene.';

          debugPrint(
            'PREMIUM DOĞRULAMA GEÇİCİ BAŞARISIZ: '
            '${verification.errorMessage}',
          );
        }

        if (purchase.pendingCompletePurchase && serverAnsweredAuthoritatively) {
          if (isGooglePlay && verification.acknowledged == true) {
            // Backend Google Play Developer API üzerinden
            // purchase token'ı zaten acknowledge etti.
            completePurchaseSucceeded = true;

            debugPrint('GOOGLE PLAY PURCHASE BACKEND TARAFINDAN ACKNOWLEDGED.');
          } else {
            try {
              await _inAppPurchase.completePurchase(purchase);

              completePurchaseSucceeded = true;

              debugPrint(
                'STORE PURCHASE TAMAMLANDI: '
                '$storeName',
              );
            } catch (e) {
              completePurchaseSucceeded = false;

              debugPrint(
                'STORE COMPLETE PURCHASE HATASI: '
                '$storeName | $e',
              );
            }
          }
        }

        // Yalnızca Apple/backend authoritative cevap verdiyse ve
        // completePurchase gerekiyorsa başarıyla tamamlandıysa bu
        // transaction'ı aynı app oturumunda "işlendi" olarak işaretle.
        if (serverAnsweredAuthoritatively && completePurchaseSucceeded) {
          _handledTransactionIds.add(transactionId);
        }
      } finally {
        _processingTransactionIds.remove(transactionId);

        purchasePending = false;
        restorePending = false;
        entitlementChecking = false;

        notifyListeners();
      }
    }

    notifyListeners();
  }
}

// ============================================================
// TEK SEFERLİK 5 DAKİKALIK ÜCRETSİZ ÇEVİRİ DENEMESİ
// ============================================================
// Bu sayaç cihazda kalıcı olarak tutulur. Uygulamayı kapatıp açmak
// veya başka bir oyuna geçmek ücretsiz süreyi sıfırlamaz.
class FreeTranslationTrialStore {
  static const String _usedSecondsKey =
      'free_translation_trial_used_seconds_v1';

  static const int totalSeconds = 5 * 60;

  static Future<int> loadUsedSeconds() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getInt(_usedSecondsKey) ?? 0;

    return value.clamp(0, totalSeconds).toInt();
  }

  static Future<void> saveUsedSeconds(int seconds) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setInt(_usedSecondsKey, seconds.clamp(0, totalSeconds).toInt());
  }

  static Future<int> remainingSeconds() async {
    final used = await loadUsedSeconds();
    return (totalSeconds - used).clamp(0, totalSeconds).toInt();
  }

  static Future<bool> isExhausted() async {
    return await remainingSeconds() <= 0;
  }
}

// ============================================================
// GAME LINGO PREMIUM - PAYWALL TASARIMI
// ============================================================
// Bu ilk adım yalnızca premium ekranının arayüzünü oluşturur.
// Gerçek App Store abonelik ürünü ve satın alma akışı sonraki
// adımda StoreKit / in_app_purchase ile bağlanacaktır.

class PremiumPage extends StatefulWidget {
  final bool trialExpired;

  const PremiumPage({super.key, this.trialExpired = false});

  @override
  State<PremiumPage> createState() => _PremiumPageState();
}

class _PremiumPageState extends State<PremiumPage> {
  static final Uri _termsUri = Uri.parse(
    'https://oyun-ceviri-backend-production-2af7.up.railway.app/terms',
  );

  static final Uri _privacyUri = Uri.parse(
    'https://oyun-ceviri-backend-production-2af7.up.railway.app/privacy',
  );

  final AppStoreSubscriptionController subscription =
      AppStoreSubscriptionController.instance;

  Future<void> _openLegalPage(Uri uri) async {
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);

      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Bağlantı açılamadı. Lütfen tekrar deneyin.'),
          ),
        );
      }
    } catch (e) {
      debugPrint('YASAL BAĞLANTI AÇMA HATASI: $e');

      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Bağlantı açılamadı. Lütfen internet bağlantınızı kontrol edin.',
          ),
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();

    subscription.addListener(_subscriptionChanged);

    unawaited(subscription.initialize(forceEntitlementRefresh: true));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;

      debugPrint(
        'PREMIUM EKRANI AÇILDI | '
        'initialized=${subscription.isInitialized} | '
        'available=${subscription.storeAvailable} | '
        'product=${subscription.product?.id ?? "null"} | '
        'loading=${subscription.isLoading} | '
        'pending=${subscription.purchasePending} | '
        'premium=${subscription.premiumActive}',
      );
    });
  }

  void _subscriptionChanged() {
    if (!mounted) return;
    setState(() {});
  }

  @override
  void dispose() {
    subscription.removeListener(_subscriptionChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF7C5CFF);

    final product =
        subscription.product;

    final isGooglePlay = Platform.isAndroid;
    final storeName = isGooglePlay ? 'Google Play' : 'App Store';

    final displayPrice =
        subscription.recurringDisplayPrice ??
        (subscription.isLoading
            ? 'Yükleniyor...'
            : 'Fiyat alınamadı');

    final canPurchase =
        subscription.storeAvailable &&
        product != null &&
        !subscription.purchasePending &&
        !subscription.isLoading &&
        !subscription.premiumActive;

    String purchaseButtonText;

    if (subscription.premiumActive) {
      purchaseButtonText =
          'Premium Aktif';
    } else if (subscription.purchasePending) {
      purchaseButtonText =
          '$storeName onayı bekleniyor...';
    } else if (subscription.isLoading) {
      purchaseButtonText =
          '$storeName’a bağlanıyor...';
    } else {
      purchaseButtonText =
          '3 Gün Ücretsiz Başla';
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D10),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 18, 0),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () =>
                        Navigator.pop(context),
                    icon: const Icon(
                      Icons.arrow_back_rounded,
                    ),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed:
                        subscription.restorePending
                            ? null
                            : () async {
                                await subscription
                                    .restorePurchases();

                                if (!context.mounted) {
                                  return;
                                }

                                ScaffoldMessenger.of(
                                  context,
                                ).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      subscription.premiumActive
                                          ? 'Premium aboneliğin geri yüklendi.'
                                          : '$storeName hesabındaki satın alımlar kontrol edildi.',
                                    ),
                                  ),
                                );
                              },
                    child: Text(
                      subscription.restorePending
                          ? 'Kontrol Ediliyor...'
                          : 'Geri Yükle',
                      style: const TextStyle(
                        color: Colors.white70,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(22, 12, 22, 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (widget.trialExpired &&
                        !subscription.premiumActive) ...[
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF1B1828),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: const Color(0x667C5CFF),
                          ),
                        ),
                        child: const Row(
                          children: [
                            Icon(
                              Icons.timer_off_outlined,
                              color: Color(0xFFB9AAFF),
                            ),
                            SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                '5 dakikalık ücretsiz kullanımın tamamlandı. Premium ile kesintisiz devam edebilirsin.',
                                style: TextStyle(
                                  fontSize: 13,
                                  height: 1.4,
                                  color: Colors.white70,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 22),
                    ],
                    if (subscription.premiumActive) ...[
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF16251C),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: const Color(0x665BD47C),
                          ),
                        ),
                        child: const Row(
                          children: [
                            Icon(
                              Icons.verified_rounded,
                              color: Color(0xFF75E394),
                            ),
                            SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                'Game Lingo Premium aktif. Canlı çeviriyi sınırsız kullanabilirsin.',
                                style: TextStyle(
                                  fontSize: 13,
                                  height: 1.4,
                                  color: Colors.white70,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 22),
                    ],
                    Center(
                      child: Container(
                        width: 86,
                        height: 86,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(26),
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF9B87FF),
                              Color(0xFF5A3FE3),
                            ],
                          ),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x557C5CFF),
                              blurRadius: 30,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.workspace_premium_rounded,
                          size: 43,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Game Lingo Premium',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.6,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Oyunu bölmeden, altyazıları anında Türkçeye çevir ve karakterleri kendi sesleriyle takip et.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        height: 1.5,
                        color: Colors.white60,
                      ),
                    ),
                    const SizedBox(height: 30),
                    const _PremiumFeature(
                      icon: Icons.translate_rounded,
                      title: 'Canlı yapay zekâ çevirisi',
                      description:
                          'Oyun altyazılarını bağlama uygun şekilde anlık Türkçeye çevir.',
                    ),
                    const SizedBox(height: 12),
                    const _PremiumFeature(
                      icon: Icons.record_voice_over_rounded,
                      title: 'Karaktere özel Türkçe sesler',
                      description:
                          'Algılanan karakterlere farklı Türkçe sesler otomatik olarak atanır.',
                    ),
                    const SizedBox(height: 12),
                    const _PremiumFeature(
                      icon: Icons.center_focus_strong_rounded,
                      title: 'Akıllı altyazı algılama',
                      description:
                          'OCR tarama alanını oyuna göre ayarla, uygulama seçimini hatırlasın.',
                    ),
                    const SizedBox(height: 12),
                    const _PremiumFeature(
                      icon: Icons.speed_rounded,
                      title: 'Kesintisiz oyun deneyimi',
                      description:
                          'Çeviri ve seslendirme arka planda sıraya alınır; oyun akışı bölünmez.',
                    ),
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: const Color(0xFF18181E),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: accent,
                          width: 1.4,
                        ),
                      ),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '3 Gün Ücretsiz',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                SizedBox(height: 5),
                                Text(
                                  'Uygun kullanıcılar için 3 günlük deneme',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.white54,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 14),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                displayPrice,
                                style: const TextStyle(
                                  fontSize: 19,
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFFD6CEFF),
                                ),
                              ),
                              const SizedBox(height: 2),
                              const Text(
                                '/ ay',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.white38,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      subscription.premiumActive
                          ? 'Aboneliğin aktif.'
                          : '3 günlük ücretsiz denemeden sonra $displayPrice / ay. Deneme uygunluğu $storeName tarafından belirlenir.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 11,
                        height: 1.4,
                        color: Colors.white38,
                      ),
                    ),
                    if (!subscription.isLoading &&
                        subscription.product == null) ...[
                      const SizedBox(height: 10),
                      SizedBox(
                        height: 44,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            unawaited(
                              subscription
                                  .refreshStoreProduct(),
                            );
                          },
                          icon: const Icon(
                            Icons.refresh_rounded,
                            size: 18,
                          ),
                          label: Text(
                            '$storeName Ürününü Yeniden Kontrol Et',
                          ),
                        ),
                      ),
                    ],
                    if (subscription.errorMessage != null) ...[
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A171A),
                          borderRadius: BorderRadius.circular(13),
                          border: Border.all(
                            color: Colors.redAccent.withValues(
                              alpha: 0.30,
                            ),
                          ),
                        ),
                        child: Text(
                          subscription.errorMessage!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.redAccent,
                            fontSize: 12,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 14),
                    SizedBox(
                      height: 58,
                      child: FilledButton(
                        onPressed:
                            canPurchase
                                ? () {
                                    unawaited(
                                      subscription
                                          .buyMonthly(),
                                    );
                                  }
                                : null,
                        style: FilledButton.styleFrom(
                          backgroundColor: accent,
                          foregroundColor: Colors.white,
                          disabledBackgroundColor:
                              subscription.premiumActive
                                  ? const Color(0xFF3B6E4A)
                                  : const Color(0xFF34343D),
                          disabledForegroundColor:
                              Colors.white70,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(17),
                          ),
                        ),
                        child: Text(
                          purchaseButtonText,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      isGooglePlay
                          ? 'Abonelik, ücretsiz deneme sona erdiğinde Google Play hesabına bağlı ödeme yönteminden tahsil edilir. Mevcut dönem bitmeden en az 24 saat önce iptal edilmezse otomatik olarak yenilenir.'
                          : 'Abonelik, ücretsiz deneme sona erdiğinde Apple Kimliğine bağlı ödeme yönteminden tahsil edilir. Mevcut dönem bitmeden en az 24 saat önce iptal edilmezse otomatik olarak yenilenir.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11,
                        height: 1.45,
                        color: Colors.white38,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 14,
                      runSpacing: 6,
                      children: [
                        TextButton(
                          onPressed: () =>
                              _openLegalPage(
                            _termsUri,
                          ),
                          child: const Text(
                            'Kullanım Koşulları',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white54,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () =>
                              _openLegalPage(
                            _privacyUri,
                          ),
                          child: const Text(
                            'Gizlilik Politikası',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.white54,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PremiumFeature extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final bool isLast;

  const _PremiumFeature({
    required this.icon,
    required this.title,
    required this.description,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF18181E),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: const Color(0xFF26262E),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFF252136),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(
              icon,
              color: const Color(0xFFB9AAFF),
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 13,
                    height: 1.4,
                    color: Colors.white54,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AddGamePage extends StatefulWidget {
  const AddGamePage({super.key});

  @override
  State<AddGamePage> createState() => _AddGamePageState();
}

class _AddGamePageState extends State<AddGamePage> {
  final TextEditingController gameController = TextEditingController();

  Timer? _debounce;
  bool isLoading = false;
  String? errorMessage;
  List<GameResult> games = [];

  void onSearchChanged(String value) {
    setState(() {});
    _debounce?.cancel();

    final query = value.trim();

    if (query.length < 2) {
      setState(() {
        games = [];
        errorMessage = null;
        isLoading = false;
      });
      return;
    }

    _debounce = Timer(
      const Duration(milliseconds: 500),
      () => searchGames(query),
    );
  }

  Future<void> searchGames(String query) async {
    if (!mounted) return;

    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final uri = Uri.parse(
        'https://api.gamelingo.app/games/search?q=${Uri.encodeQueryComponent(query)}',
      );

      final response = await http.get(uri);

      if (response.statusCode != 200) {
        throw Exception('Sunucu hatası');
      }

      final data = jsonDecode(response.body);
      final results = data['results'] as List<dynamic>;

      if (!mounted) return;
      if (gameController.text.trim() != query) return;

      setState(() {
        games = results
            .map((item) => GameResult.fromJson(item as Map<String, dynamic>))
            .toList();

        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        games = [];
        isLoading = false;
        errorMessage =
            'Oyun listesine ulaşamadık. Bağlantını kontrol edip tekrar dene.';
      });
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    gameController.dispose();
    super.dispose();
  }

  Widget _statusPanel({
    required IconData icon,
    required String title,
    required String description,
    bool loading = false,
    Widget? action,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 36),
      decoration: BoxDecoration(
        color: AppDesign.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppDesign.border),
      ),
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppDesign.surfaceRaised,
              borderRadius: BorderRadius.circular(20),
            ),
            alignment: Alignment.center,
            child: loading
                ? const SizedBox(
                    width: 26,
                    height: 26,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: AppDesign.primary,
                    ),
                  )
                : Icon(icon, color: AppDesign.primary, size: 30),
          ),
          const SizedBox(height: 20),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.5,
              color: AppDesign.text,
            ),
          ),
          const SizedBox(height: 10),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Text(
              description,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppDesign.muted,
                fontSize: 14,
                height: 1.6,
              ),
            ),
          ),
          if (action != null) ...[const SizedBox(height: 20), action],
        ],
      ),
    );
  }

  Widget _searchContent() {
    if (gameController.text.trim().length < 2) {
      return SliverToBoxAdapter(
        child: _statusPanel(
          icon: Icons.sports_esports_outlined,
          title: 'Sıradaki hikâyeni bul',
          description:
              'Oyun adından en az iki harf yaz. Sonuçlardan birini seçerek kütüphanene ekle.',
        ),
      );
    }

    if (isLoading) {
      return SliverToBoxAdapter(
        child: Semantics(
          liveRegion: true,
          child: _statusPanel(
            icon: Icons.search_rounded,
            title: 'Oyunlar aranıyor',
            description: 'Aramana uygun oyunları getiriyoruz.',
            loading: true,
          ),
        ),
      );
    }

    if (errorMessage != null) {
      return SliverToBoxAdapter(
        child: Semantics(
          liveRegion: true,
          child: _statusPanel(
            icon: Icons.wifi_off_rounded,
            title: 'Bir bağlantı sorunu var',
            description: errorMessage!,
            action: OutlinedButton.icon(
              onPressed: () => searchGames(gameController.text.trim()),
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Tekrar dene'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppDesign.primary,
                minimumSize: const Size(140, 48),
                side: const BorderSide(color: AppDesign.border),
              ),
            ),
          ),
        ),
      );
    }

    if (games.isEmpty) {
      return SliverToBoxAdapter(
        child: _statusPanel(
          icon: Icons.search_off_rounded,
          title: 'Henüz eşleşme yok',
          description:
              'Oyun adını kontrol et veya adın daha kısa bir bölümünü aramayı dene.',
        ),
      );
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate((context, index) {
        if (index == 0) {
          return Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 16),
            child: Text(
              '${games.length} OYUN BULUNDU',
              style: const TextStyle(
                color: AppDesign.muted,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.6,
              ),
            ),
          );
        }
        final game = games[index - 1];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Material(
            color: AppDesign.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
              side: const BorderSide(color: AppDesign.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: () => Navigator.pop(context, game),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    GameCover(
                      game: game,
                      width: 62,
                      height: 82,
                      borderRadius: 12,
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            game.name,
                            style: const TextStyle(
                              color: AppDesign.text,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              height: 1.35,
                              letterSpacing: -0.25,
                            ),
                          ),
                          const SizedBox(height: 7),
                          const Text(
                            'Kütüphaneye ekle',
                            style: TextStyle(
                              color: AppDesign.muted,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: AppDesign.surfaceRaised,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.add_rounded,
                        size: 20,
                        color: AppDesign.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }, childCount: games.length + 1),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_rounded),
                padding: EdgeInsets.zero,
              ),
              const SizedBox(height: 24),
              const Text(
                'Yeni Oyun Ekle',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Oynamak istediğin oyunun adını yaz.',
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.white54,
                ),
              ),
              const SizedBox(height: 34),
              TextField(
                controller: gameController,
                autofocus: true,
                onChanged: onSearchChanged,
                decoration: InputDecoration(
                  hintText: 'Örn. Red Dead Redemption 2',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: gameController.text.isNotEmpty
                      ? IconButton(
                          onPressed: () {
                            gameController.clear();

                            setState(() {
                              games = [];
                              errorMessage = null;
                              isLoading = false;
                            });
                          },
                          icon: const Icon(Icons.close_rounded),
                        )
                      : null,
                  filled: true,
                  fillColor: const Color(0xFF18181E),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(
                      color: Color(0xFF26262E),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(
                      color: Color(0xFF7C5CFF),
                      width: 1.5,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Expanded(
                child: Builder(
                  builder: (context) {
                    if (gameController.text.trim().length < 2) {
                      return const Center(
                        child: Text(
                          'Aramak için oyun adını yazmaya başla.',
                          style: TextStyle(color: Colors.white38),
                        ),
                      );
                    }

                    if (isLoading) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }

                    if (errorMessage != null) {
                      return Center(
                        child: Text(
                          errorMessage!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.redAccent,
                          ),
                        ),
                      );
                    }

                    if (games.isEmpty) {
                      return const Center(
                        child: Text(
                          'Sonuç bulunamadı.',
                          style: TextStyle(color: Colors.white38),
                        ),
                      );
                    }

                    return ListView.separated(
                      itemCount: games.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final game = games[index];

                        return InkWell(
                          onTap: () {
                            Navigator.pop(context, game);
                          },
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF18181E),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFF26262E),
                              ),
                            ),
                            child: Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: SizedBox(
                                    width: 70,
                                    height: 96,
                                    child: game.coverUrl != null
                                        ? Image.network(
                                            game.coverUrl!,
                                            fit: BoxFit.cover,
                                          )
                                        : const ColoredBox(
                                            color: Color(0xFF24242B),
                                            child: Icon(
                                              Icons.image_outlined,
                                            ),
                                          ),
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Text(
                                    game.name,
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                                const Icon(
                                  Icons.chevron_right_rounded,
                                  color: Colors.white38,
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GameDetailPage extends StatelessWidget {
  final GameResult game;

  const GameDetailPage({super.key, required this.game});

  Future<void> _startTranslation(BuildContext context) async {
    final premiumActive = await AppStoreSubscriptionController.instance
        .ensurePremiumAccess(forceServer: true);

    if (!context.mounted) return;

    if (!premiumActive) {
      final exhausted = await FreeTranslationTrialStore.isExhausted();

      if (!context.mounted) return;

      if (exhausted) {
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const PremiumPage(trialExpired: true),
          ),
        );
        return;
      }
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CameraTranslationPage(game: game),
      ),
    );
  }

  Widget _hero(bool wide) {
    final description = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: AppDesign.background.withValues(alpha: 0.8),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: AppDesign.border),
          ),
          child: const Text(
            'SENİN OYUNUN · SENİN HİKÂYEN',
            style: TextStyle(
              color: AppDesign.primary,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.25,
              height: 1.4,
            ),
          ),
        ),
        const SizedBox(height: 18),
        Text(
          game.name,
          style: TextStyle(
            color: AppDesign.text,
            fontSize: wide ? 36 : 28,
            height: 1.12,
            fontWeight: FontWeight.w800,
            letterSpacing: -1,
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'Altyazıları Türkçe takip etmek için kameranı oyun ekranına yönelt.',
          style: TextStyle(color: AppDesign.muted, fontSize: 15, height: 1.6),
        ),
      ],
    );
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppDesign.border),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(27),
        child: Stack(
          children: [
            Positioned.fill(
              child: Opacity(
                opacity: 0.35,
                child: GameCover(
                  game: game,
                  width: double.infinity,
                  height: double.infinity,
                  borderRadius: 0,
                ),
              ),
            ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppDesign.surface.withValues(alpha: 0.6),
                      AppDesign.surface.withValues(alpha: 0.94),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(wide ? 32 : 24),
              child: wide
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        GameCover(game: game, width: 166, height: 224),
                        const SizedBox(width: 30),
                        Expanded(child: description),
                      ],
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        GameCover(game: game, width: 112, height: 150),
                        const SizedBox(height: 24),
                        description,
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _launchCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppDesign.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppDesign.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'ÇEVİRİ DİLİ',
            style: TextStyle(
              color: AppDesign.muted,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.6,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _language('EN', 'İngilizce', false)),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Icon(
                  Icons.arrow_forward_rounded,
                  color: AppDesign.muted,
                  size: 20,
                ),
              ),
              Expanded(child: _language('TR', 'Türkçe', true)),
            ],
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 22),
            child: Divider(height: 1, color: AppDesign.border),
          ),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => _startTranslation(context),
              style: FilledButton.styleFrom(
                backgroundColor: AppDesign.primary,
                foregroundColor: AppDesign.background,
                minimumSize: const Size(0, 56),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 17,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              icon: const Icon(Icons.play_arrow_rounded, size: 25),
              label: const Text(
                'Çeviriyi Başlat',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Kamera açıldığında altyazı alanını oyun ekranına göre ayarlayabilirsin.',
            style: TextStyle(color: AppDesign.muted, fontSize: 12, height: 1.6),
          ),
        ],
      ),
    );
  }

  Widget _language(String code, String label, bool highlighted) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          code,
          style: TextStyle(
            color: highlighted ? AppDesign.primary : AppDesign.text,
            fontSize: 26,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.8,
          ),
        ),
        const SizedBox(height: 5),
        Text(
          label,
          style: const TextStyle(color: AppDesign.muted, fontSize: 13),
        ),
      ],
    );
  }

  Widget _voicesCard(BuildContext context) {
    return Material(
      color: AppDesign.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
        side: const BorderSide(color: AppDesign.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CharacterVoicesPage(game: game),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppDesign.surfaceRaised,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(
                  Icons.record_voice_over_rounded,
                  color: AppDesign.lavender,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Karakter sesleri',
                      style: TextStyle(
                        color: AppDesign.text,
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.3,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Karakterlerin Türkçe seslerini düzenle.',
                      style: TextStyle(
                        color: AppDesign.muted,
                        fontSize: 13,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              const Icon(Icons.chevron_right_rounded, color: AppDesign.muted),
            ],
          ),
        ),
      ),
    );
  }

  Widget _setupGuide() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppDesign.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppDesign.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Başlamadan önce',
            style: TextStyle(
              color: AppDesign.text,
              fontSize: 18,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 22),
          _step(
            '01',
            'Oyunda altyazıları aç',
            'İngilizce diyalogların ekranda göründüğünden emin ol.',
          ),
          const SizedBox(height: 20),
          _step(
            '02',
            'Kamerayı ekrana yönelt',
            'Telefonunu sabit tut ve altyazıları net görecek şekilde yerleştir.',
          ),
          const SizedBox(height: 20),
          _step(
            '03',
            'Altyazı alanını belirle',
            'Çeviri ekranında tarama alanını altyazıların üzerine getir.',
          ),
        ],
      ),
    );
  }

  Widget _step(String number, String title, String body) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8),
          decoration: BoxDecoration(
            color: AppDesign.surfaceRaised,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            number,
            style: const TextStyle(
              color: AppDesign.primary,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: AppDesign.text,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                body,
                style: const TextStyle(
                  color: AppDesign.muted,
                  fontSize: 12,
                  height: 1.6,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_rounded),
                padding: EdgeInsets.zero,
              ),
              const SizedBox(height: 24),
              if (game.coverUrl != null)
                Center(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.network(
                      game.coverUrl!,
                      width: 180,
                      height: 245,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              const SizedBox(height: 28),
              Text(
                game.name,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Bu oyun için çeviri ayarlarını buradan yöneteceksin.',
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.white54,
                  height: 1.4,
                ),
              ),
              const Spacer(),

              SizedBox(
                width: double.infinity,
                height: 54,
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CharacterVoicesPage(
                          game: game,
                        ),
                      ),
                    );
                  },
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(
                      color: Color(0xFF7C5CFF),
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(17),
                    ),
                  ),
                  icon: const Icon(
                    Icons.record_voice_over_rounded,
                  ),
                  label: const Text(
                    'Karakter Sesleri',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              SizedBox(
                width: double.infinity,
                height: 58,
                child: FilledButton.icon(
                  onPressed: () async {
                    final premiumActive =
                        await AppStoreSubscriptionController
                            .instance
                            .ensurePremiumAccess(
                              forceServer: true,
                            );

                    if (!context.mounted) return;

                    if (!premiumActive) {
                      final exhausted =
                          await FreeTranslationTrialStore.isExhausted();

                      if (!context.mounted) return;

                      if (exhausted) {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const PremiumPage(
                              trialExpired: true,
                            ),
                          ),
                        );
                        return;
                      }
                    }

                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CameraTranslationPage(
                          game: game,
                        ),
                      ),
                    );
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF7C5CFF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(17),
                    ),
                  ),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text(
                    'Çeviriyi Başlat',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CharacterVoicesPage extends StatefulWidget {
  final GameResult game;

  const CharacterVoicesPage({super.key, required this.game});

  @override
  State<CharacterVoicesPage> createState() => _CharacterVoicesPageState();
}

class _CharacterVoicesPageState extends State<CharacterVoicesPage> {
  static const String backendBaseUrl = 'https://api.gamelingo.app';

  // ELEVENLABS_API_KEY yalnızca Text-to-Speech izniyle oluşturulduysa
  // ElevenLabs /v2/voices çağrısı Voices Read izni olmadığı için reddedilir.
  // Böyle bir durumda ekran tamamen kilitlenmesin; mevcut Game Lingo ses
  // havuzu yine seçilebilir. Voices Read açıldığı anda backend tüm erişilebilir
  // ElevenLabs seslerini döndürür ve bu liste otomatik olarak genişler.
  static const List<AiVoiceOption> fallbackAiVoices = [
    AiVoiceOption(voiceId: 'OMPrkDOvnYasPecb05Rb', name: 'Arthur', gender: 'male', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'enCmlalD3FDYNfJskCY9', name: 'Michael', gender: 'male', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'GZjSCLkzCKh5lsmbn2VO', name: 'Berk', gender: 'male', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'Ongxzjm6NAJamxlPiP4z', name: 'Akin', gender: 'male', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'sZXOZNdVMeHi5J0uiQF7', name: 'Enes', gender: 'male', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'KsAmBSHXsuxsZ1lZZXlG', name: 'Angry Speaker', gender: 'male', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'W3C2vBPukr5b5jvoXhPK', name: 'Kira', gender: 'female', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'HBDoL4wkcalemIO0nUAu', name: 'Emily E.', gender: 'female', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'WtA85syCrJwasGeHGH2p', name: 'Ember', gender: 'female', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'esy0r39YPLQjOczyOib8', name: 'Britney', gender: 'female', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'nXpBQckSqPfSghXiaOwA', name: 'Kim', gender: 'female', category: 'Game Lingo'),
    AiVoiceOption(voiceId: 'Qbw4VpyUrHEG7NigKzty', name: 'Kristen', gender: 'female', category: 'Game Lingo'),
  ];

  final AudioPlayer previewPlayer = AudioPlayer();
  StreamSubscription<void>? previewCompleteSubscription;

  bool isLoading = true;
  String? voiceLoadError;
  String? previewingVoiceId;

  List<AiVoiceOption> elevenLabsVoices = [];

  Map<String, AiVoiceOption> get aiAssignments =>
      GameAiVoiceStore.assignmentsForGame(widget.game.id);

  @override
  void initState() {
    super.initState();

    previewCompleteSubscription = previewPlayer.onPlayerComplete.listen((_) {
      if (!mounted) return;
      setState(() => previewingVoiceId = null);
    });

    initializePage();
  }

  Future<void> initializePage() async {
    await GameVoiceStore.loadFromStorage();
    await GameAiVoiceStore.loadFromStorage();
    await CharacterProfileStore.loadFromStorage();
    await loadElevenLabsVoices();
  }

  Future<void> loadElevenLabsVoices({bool forceRefresh = false}) async {
    if (mounted) {
      setState(() {
        isLoading = true;
        voiceLoadError = null;
      });
    }

    try {
      final uri = Uri.parse('$backendBaseUrl/tts/ai/voices').replace(
        queryParameters: forceRefresh ? const {'refresh': '1'} : null,
      );
      final response = await http.get(
        uri,
        headers: const {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 12));

      dynamic decoded;
      try {
        decoded = jsonDecode(response.body);
      } catch (_) {
        throw Exception('Ses listesi geçerli JSON döndürmedi.');
      }

      if (response.statusCode < 200 ||
          response.statusCode >= 300 ||
          decoded is! Map ||
          decoded['ok'] != true) {
        final error = decoded is Map ? decoded['error'] : null;
        throw Exception(
          error?.toString().trim().isNotEmpty == true
              ? error.toString()
              : 'ElevenLabs ses listesi alınamadı. HTTP ${response.statusCode}',
        );
      }

      final rawVoices = decoded['voices'];
      final parsed = <AiVoiceOption>[];

      if (rawVoices is List) {
        for (final item in rawVoices) {
          if (item is! Map) continue;
          final voice = AiVoiceOption.fromJson(
            Map<String, dynamic>.from(item),
          );
          if (voice.voiceId.isEmpty || voice.name.isEmpty) continue;
          parsed.add(voice);
        }
      }

      final unique = <String, AiVoiceOption>{};
      for (final voice in parsed) {
        unique[voice.voiceId] = voice;
      }

      final voices = unique.values.toList()
        ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

      if (!mounted) return;

      final limited = decoded['limited'] == true;
      final warning = decoded['warning']?.toString().trim();
      final effectiveVoices = voices.isNotEmpty
          ? voices
          : List<AiVoiceOption>.from(fallbackAiVoices);

      if (!mounted) return;

      setState(() {
        elevenLabsVoices = effectiveVoices;
        isLoading = false;
        voiceLoadError = limited
            ? (warning?.isNotEmpty == true
                ? warning
                : 'Tam ElevenLabs ses listesi için API anahtarında Voices Read iznini aç. Şimdilik Game Lingo sesleri gösteriliyor.')
            : voices.isEmpty
            ? 'ElevenLabs hesabında ses bulunamadı. Geçici Game Lingo sesleri gösteriliyor.'
            : null;
      });

      debugPrint(
        'ELEVENLABS SES LİSTESİ: ${effectiveVoices.length} ses yüklendi'
        '${limited ? ' (sınırlı/fallback)' : ''}.',
      );
    } catch (e) {
      debugPrint('ELEVENLABS SES LİSTESİ HATASI: $e');

      if (!mounted) return;

      setState(() {
        elevenLabsVoices = List<AiVoiceOption>.from(fallbackAiVoices);
        isLoading = false;
        voiceLoadError =
            'Tam ElevenLabs listesine ulaşılamadı. Karakter seslerini değiştirebilmen için Game Lingo sesleri gösteriliyor. ElevenLabs API anahtarında Voices Read iznini açınca tüm erişilebilir sesler otomatik görünecek.';
      });
    }
  }

  AiVoiceOption? voiceFromStored(AiVoiceOption? stored) {
    if (stored == null) return null;

    for (final voice in elevenLabsVoices) {
      if (voice.voiceId == stored.voiceId) return voice;
    }

    return stored;
  }

  Future<void> previewVoice(AiVoiceOption voice, String speaker) async {
    if (voice.isAutomatic || voice.voiceId.isEmpty) return;

    try {
      await previewPlayer.stop();

      if (!mounted) return;
      setState(() => previewingVoiceId = voice.voiceId);

      String audioUrl = voice.previewUrl?.trim() ?? '';

      // ElevenLabs'in hazır preview URL'si yoksa mevcut AI TTS backend'i
      // üzerinden bu voiceId ile kısa Türkçe örnek üret.
      if (audioUrl.isEmpty) {
        final response = await http
            .post(
              Uri.parse('$backendBaseUrl/tts/ai/prepare'),
              headers: const {
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept': 'application/json',
              },
              body: jsonEncode({
                'gameId': widget.game.id.toString(),
                'gameName': widget.game.name,
                'speaker': speaker,
                'canonicalCharacterName': speaker,
                'speakerGender': 'unknown',
                'text': 'Merhaba, ben $speaker. Bu ses benim için nasıl?',
                'voiceId': voice.voiceId,
                'devicePlatform': Platform.isIOS
                    ? 'ios'
                    : Platform.isAndroid
                    ? 'android'
                    : null,
              }),
            )
            .timeout(const Duration(seconds: 4));

        final decoded = jsonDecode(response.body);
        if (decoded is! Map ||
            response.statusCode < 200 ||
            response.statusCode >= 300 ||
            decoded['ok'] != true) {
          throw Exception('Ses önizlemesi hazırlanamadı.');
        }

        audioUrl = decoded['audioUrl']?.toString().trim() ?? '';
      }

      if (audioUrl.isEmpty) {
        throw Exception('Ses önizleme bağlantısı bulunamadı.');
      }

      await previewPlayer.play(UrlSource(audioUrl));
    } catch (e) {
      debugPrint('ELEVENLABS SES ÖNİZLEME HATASI: $e');

      if (!mounted) return;
      setState(() => previewingVoiceId = null);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Ses önizlenemedi: ${e.toString().replaceFirst('Exception: ', '')}',
          ),
        ),
      );
    }
  }

  String voiceMeta(AiVoiceOption voice) {
    final parts = <String>[];

    if (voice.gender.isNotEmpty) parts.add(voice.gender);
    if (voice.accent.isNotEmpty) parts.add(voice.accent);
    if (voice.category.isNotEmpty) parts.add(voice.category);

    return parts.join(' • ');
  }

  Future<void> changeVoice(String speaker) async {
    if (elevenLabsVoices.isEmpty) {
      await loadElevenLabsVoices();
      if (!mounted || elevenLabsVoices.isEmpty) return;
    }

    final searchController = TextEditingController();
    var query = '';

    final selected = await showModalBottomSheet<AiVoiceOption>(
      context: context,
      backgroundColor: const Color(0xFF15151A),
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final normalizedQuery = query.trim().toLowerCase();
            final filtered = normalizedQuery.isEmpty
                ? elevenLabsVoices
                : elevenLabsVoices.where((voice) {
                    final haystack = [
                      voice.name,
                      voice.gender,
                      voice.accent,
                      voice.category,
                      voice.description,
                    ].join(' ').toLowerCase();
                    return haystack.contains(normalizedQuery);
                  }).toList();

            final current = GameAiVoiceStore.getVoice(
              gameId: widget.game.id,
              speaker: speaker,
            );

            return FractionallySizedBox(
              heightFactor: MediaQuery.orientationOf(context) ==
                      Orientation.landscape
                  ? 0.94
                  : 0.86,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$speaker için ElevenLabs sesi seç',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '${elevenLabsVoices.length} kullanılabilir ses • istediğin sesi seçebilirsin',
                      style: const TextStyle(color: Colors.white54),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: searchController,
                      onChanged: (value) {
                        setSheetState(() => query = value);
                      },
                      decoration: InputDecoration(
                        hintText: 'Ses ara…',
                        prefixIcon: const Icon(Icons.search_rounded),
                        suffixIcon: query.isEmpty
                            ? null
                            : IconButton(
                                onPressed: () {
                                  searchController.clear();
                                  setSheetState(() => query = '');
                                },
                                icon: const Icon(Icons.close_rounded),
                              ),
                        filled: true,
                        fillColor: const Color(0xFF1D1D23),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF1D1D23),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: current == null
                              ? const Color(0xFF7C5CFF)
                              : Colors.white10,
                        ),
                      ),
                      child: ListTile(
                        leading: const Icon(
                          Icons.auto_awesome_rounded,
                          color: Color(0xFFB9AAFF),
                        ),
                        title: const Text('Otomatik seçim'),
                        subtitle: const Text(
                          'Karaktere göre Game Lingo uygun ElevenLabs sesini seçer.',
                          maxLines: 2,
                        ),
                        trailing: current == null
                            ? const Icon(
                                Icons.check_circle_rounded,
                                color: Color(0xFF7C5CFF),
                              )
                            : null,
                        onTap: () => Navigator.pop(
                          sheetContext,
                          const AiVoiceOption.automatic(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: filtered.isEmpty
                          ? const Center(
                              child: Text(
                                'Aramana uygun ses bulunamadı.',
                                style: TextStyle(color: Colors.white54),
                              ),
                            )
                          : ListView.separated(
                              itemCount: filtered.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 9),
                              itemBuilder: (context, index) {
                                final voice = filtered[index];
                                final isSelected =
                                    current?.voiceId == voice.voiceId;
                                final meta = voiceMeta(voice);
                                final isPreviewing =
                                    previewingVoiceId == voice.voiceId;

                                return Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF1D1D23),
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(
                                      color: isSelected
                                          ? const Color(0xFF7C5CFF)
                                          : Colors.white10,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 40,
                                        height: 40,
                                        decoration: BoxDecoration(
                                          color: const Color(0xFF27272F),
                                          borderRadius:
                                              BorderRadius.circular(11),
                                        ),
                                        child: const Icon(
                                          Icons.graphic_eq_rounded,
                                          color: Color(0xFF9B87FF),
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              voice.name,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                            if (meta.isNotEmpty) ...[
                                              const SizedBox(height: 3),
                                              Text(
                                                meta,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                  color: Colors.white38,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ),
                                      IconButton(
                                        tooltip: 'Dinle',
                                        onPressed: isPreviewing
                                            ? null
                                            : () async {
                                                await previewVoice(
                                                  voice,
                                                  speaker,
                                                );
                                                if (context.mounted) {
                                                  setSheetState(() {});
                                                }
                                              },
                                        icon: isPreviewing
                                            ? const SizedBox(
                                                width: 20,
                                                height: 20,
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 2,
                                                ),
                                              )
                                            : const Icon(
                                                Icons.play_circle_outline_rounded,
                                              ),
                                      ),
                                      const SizedBox(width: 4),
                                      FilledButton(
                                        onPressed: () =>
                                            Navigator.pop(sheetContext, voice),
                                        style: FilledButton.styleFrom(
                                          backgroundColor: isSelected
                                              ? const Color(0xFF7C5CFF)
                                              : const Color(0xFF34343D),
                                        ),
                                        child: Text(
                                          isSelected ? 'Seçili' : 'Seç',
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    searchController.dispose();

    if (selected == null) return;

    await previewPlayer.stop();

    if (selected.isAutomatic) {
      await GameAiVoiceStore.clearVoice(
        gameId: widget.game.id,
        speaker: speaker,
      );
    } else {
      await GameAiVoiceStore.assignVoice(
        gameId: widget.game.id,
        speaker: speaker,
        voice: selected,
      );
    }

    if (!mounted) return;
    setState(() {
      previewingVoiceId = null;
    });
  }

  @override
  void dispose() {
    previewCompleteSubscription?.cancel();
    unawaited(previewPlayer.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final speakers = <String>{
      ...GameVoiceStore.assignmentsForGame(widget.game.id).keys,
      ...GameAiVoiceStore.speakersForGame(widget.game.id),
      ...aiAssignments.keys,
    }.toList()
      ..sort();

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded),
                    padding: EdgeInsets.zero,
                  ),
                  const Spacer(),
                  if (!isLoading)
                    IconButton(
                      tooltip: 'Ses listesini yenile',
                      onPressed: () => loadElevenLabsVoices(forceRefresh: true),
                      icon: const Icon(Icons.refresh_rounded),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                'Karakter Sesleri',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.game.name,
                style: const TextStyle(
                  fontSize: 15,
                  color: Colors.white54,
                ),
              ),
              const SizedBox(height: 8),
              if (!isLoading && elevenLabsVoices.isNotEmpty)
                Text(
                  '${elevenLabsVoices.length} ElevenLabs sesi kullanılabilir.',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF9B87FF),
                  ),
                ),
              if (voiceLoadError != null) ...[
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF241B1B),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF563838)),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.info_outline_rounded,
                        color: Color(0xFFFFB4AB),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          voiceLoadError!,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () => loadElevenLabsVoices(forceRefresh: true),
                        child: const Text('Tekrar dene'),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Expanded(
                child: isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : speakers.isEmpty
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.all(24),
                          child: Text(
                            'Henüz bir karakter algılanmadı.\n\nÖnce çeviriyi başlat ve oyundaki bir karakter konuşsun. Algılanan karakterler burada otomatik görünecek.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white54,
                              height: 1.5,
                            ),
                          ),
                        ),
                      )
                    : ListView.separated(
                        itemCount: speakers.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 12),
                        itemBuilder: (context, index) {
                          final speaker = speakers[index];
                          final selectedVoice = voiceFromStored(
                            GameAiVoiceStore.getVoice(
                              gameId: widget.game.id,
                              speaker: speaker,
                            ),
                          );

                          return Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: const Color(0xFF18181E),
                              borderRadius: BorderRadius.circular(17),
                              border: Border.all(
                                color: const Color(0xFF26262E),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF27272F),
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: const Icon(
                                    Icons.person_rounded,
                                    color: Color(0xFF9B87FF),
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        speaker,
                                        style: const TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        selectedVoice?.name ??
                                            'Otomatik ElevenLabs sesi',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.white54,
                                          fontSize: 13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (selectedVoice != null)
                                  IconButton(
                                    tooltip: 'Dinle',
                                    onPressed: () => previewVoice(
                                      selectedVoice,
                                      speaker,
                                    ),
                                    icon: const Icon(
                                      Icons.volume_up_rounded,
                                    ),
                                  ),
                                const SizedBox(width: 4),
                                OutlinedButton(
                                  onPressed: elevenLabsVoices.isEmpty
                                      ? null
                                      : () => changeVoice(speaker),
                                  child: const Text('Değiştir'),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// OYUN BAZLI ALTYAZI TARAMA ALANI
// ============================================================

class SubtitleScanArea {
  final double left;
  final double right;
  final double top;
  final double bottom;

  const SubtitleScanArea({
    required this.left,
    required this.right,
    required this.top,
    required this.bottom,
  });

  Map<String, dynamic> toJson() {
    return {'left': left, 'right': right, 'top': top, 'bottom': bottom};
  }

  factory SubtitleScanArea.fromJson(Map<String, dynamic> json) {
    double readFactor(String key, double fallback) {
      final value = json[key];

      if (value is num) {
        return value.toDouble().clamp(0.0, 1.0).toDouble();
      }

      return fallback;
    }

    final left = readFactor('left', 0.0);

    final right = readFactor('right', 0.95);

    final top = readFactor('top', 0.48);

    final bottom = readFactor('bottom', 0.82);

    // Bozuk/eski bir kayıt gelirse güvenli varsayılana dön.
    if (right - left < 0.20 || bottom - top < 0.10) {
      return const SubtitleScanArea(
        left: 0.0,
        right: 0.95,
        top: 0.48,
        bottom: 0.82,
      );
    }

    return SubtitleScanArea(left: left, right: right, top: top, bottom: bottom);
  }
}

class GameScanAreaStore {
  static const String _storageKey = 'game_subtitle_scan_areas_v1';

  static Future<SubtitleScanArea> load(int gameId) async {
    final prefs = await SharedPreferences.getInstance();

    final raw = prefs.getString(_storageKey);

    if (raw == null || raw.trim().isEmpty) {
      return const SubtitleScanArea(
        left: 0.0,
        right: 0.95,
        top: 0.48,
        bottom: 0.82,
      );
    }

    try {
      final decoded = jsonDecode(raw);

      if (decoded is Map<String, dynamic>) {
        final gameValue = decoded[gameId.toString()];

        if (gameValue is Map<String, dynamic>) {
          return SubtitleScanArea.fromJson(gameValue);
        }

        if (gameValue is Map) {
          return SubtitleScanArea.fromJson(
            Map<String, dynamic>.from(gameValue),
          );
        }
      }
    } catch (e) {
      debugPrint(
        'TARAMA ALANI KAYDI '
        'OKUNAMADI: $e',
      );
    }

    return const SubtitleScanArea(
      left: 0.0,
      right: 0.95,
      top: 0.48,
      bottom: 0.82,
    );
  }

  static Future<void> save(int gameId, SubtitleScanArea area) async {
    final prefs = await SharedPreferences.getInstance();

    final raw = prefs.getString(_storageKey);

    final allAreas = <String, dynamic>{};

    if (raw != null && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);

        if (decoded is Map<String, dynamic>) {
          allAreas.addAll(decoded);
        } else if (decoded is Map) {
          allAreas.addAll(Map<String, dynamic>.from(decoded));
        }
      } catch (e) {
        debugPrint(
          'TARAMA ALANI ESKİ KAYDI '
          'OKUNAMADI: $e',
        );
      }
    }

    allAreas[gameId.toString()] = area.toJson();

    await prefs.setString(_storageKey, jsonEncode(allAreas));
  }

  static Future<void> remove(int gameId) async {
    final prefs = await SharedPreferences.getInstance();

    final raw = prefs.getString(_storageKey);

    if (raw == null || raw.trim().isEmpty) {
      return;
    }

    try {
      final decoded = jsonDecode(raw);

      final allAreas = <String, dynamic>{};

      if (decoded is Map<String, dynamic>) {
        allAreas.addAll(decoded);
      } else if (decoded is Map) {
        allAreas.addAll(Map<String, dynamic>.from(decoded));
      }

      allAreas.remove(gameId.toString());

      await prefs.setString(_storageKey, jsonEncode(allAreas));
    } catch (e) {
      debugPrint('TARAMA ALANI SİLİNEMEDİ: $e');
    }
  }
}

class GameCameraZoomStore {
  static const String _storageKey = 'game_camera_zoom_levels_v1';

  static Future<double> load(int gameId) async {
    final prefs = await SharedPreferences.getInstance();

    final raw = prefs.getString(_storageKey);

    if (raw == null || raw.trim().isEmpty) {
      return 1.0;
    }

    try {
      final decoded = jsonDecode(raw);

      if (decoded is Map<String, dynamic>) {
        final value = decoded[gameId.toString()];

        if (value is num) {
          return value.toDouble();
        }
      }

      if (decoded is Map) {
        final value = decoded[gameId.toString()];

        if (value is num) {
          return value.toDouble();
        }
      }
    } catch (e) {
      debugPrint(
        'KAMERA ZOOM KAYDI '
        'OKUNAMADI: $e',
      );
    }

    return 1.0;
  }

  static Future<void> save(int gameId, double zoom) async {
    final prefs = await SharedPreferences.getInstance();

    final raw = prefs.getString(_storageKey);

    final allZoomLevels = <String, dynamic>{};

    if (raw != null && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);

        if (decoded is Map<String, dynamic>) {
          allZoomLevels.addAll(decoded);
        } else if (decoded is Map) {
          allZoomLevels.addAll(Map<String, dynamic>.from(decoded));
        }
      } catch (e) {
        debugPrint(
          'KAMERA ZOOM ESKİ KAYDI '
          'OKUNAMADI: $e',
        );
      }
    }

    allZoomLevels[gameId.toString()] = zoom;

    await prefs.setString(_storageKey, jsonEncode(allZoomLevels));
  }

  static Future<void> remove(int gameId) async {
    final prefs = await SharedPreferences.getInstance();

    final raw = prefs.getString(_storageKey);

    if (raw == null || raw.trim().isEmpty) {
      return;
    }

    try {
      final decoded = jsonDecode(raw);

      final allZoomLevels = <String, dynamic>{};

      if (decoded is Map<String, dynamic>) {
        allZoomLevels.addAll(decoded);
      } else if (decoded is Map) {
        allZoomLevels.addAll(Map<String, dynamic>.from(decoded));
      }

      allZoomLevels.remove(gameId.toString());

      await prefs.setString(_storageKey, jsonEncode(allZoomLevels));
    } catch (e) {
      debugPrint('KAMERA ZOOM KAYDI SİLİNEMEDİ: $e');
    }
  }
}

class _CameraMenuIcon extends StatelessWidget {
  final IconData icon;

  const _CameraMenuIcon({
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: const Color(0xFF252136),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        icon,
        size: 20,
        color: const Color(0xFFB9AAFF),
      ),
    );
  }
}

class CameraTranslationPage extends StatefulWidget {
  final GameResult game;

  const CameraTranslationPage({super.key, required this.game});

  @override
  State<CameraTranslationPage> createState() => _CameraTranslationPageState();
}

class _CameraTranslationPageState extends State<CameraTranslationPage> {
  CameraController? cameraController;
  CameraDescription? activeCameraDescription;

  bool isCameraPageDisposing = false;
  DateTime? lastLiveFrameAcceptedAt;

  // ==========================================================
  // ANDROID ADAPTİF PERFORMANS
  // ==========================================================
  // Güçlü cihazlarda tam çözünürlük korunur. OCR süresi kalıcı olarak
  // yükselirse Android otomatik olarak 1/2 lineer çözünürlüğe geçer
  // (piksel sayısı yaklaşık 4 kat azalır). Böylece MethodChannel üzerinden
  // taşınan NV21 veri miktarı ve native ML Kit yükü ciddi biçimde düşer.
  //
  // Kare aralığı da sabit değildir: altyazı görülürken hızlanır, boş
  // sahnede ve yavaş cihazlarda CPU'yu sürekli %100'e vurmamak için
  // otomatik olarak gevşer. Bir OCR sürerken gelen yeni kareler zaten
  // kuyruğa alınmaz; en güncel kare beklenir.
  int androidAdaptiveFrameIntervalMs = 220;
  double androidOcrAverageMs = 0.0;
  int androidOcrSampleCount = 0;
  bool androidHalfResolutionOcr = false;
  int androidHalfResolutionEmptyFrames = 0;
  DateTime? androidLastSubtitleRegionTextAt;

  static const int androidMinFrameIntervalMs = 150;
  static const int androidMaxFrameIntervalMs = 460;
  static const int androidHalfResolutionEnableAfterSamples = 5;
  static const double androidHalfResolutionEnableAverageMs = 140.0;
  static const int androidFullResolutionRescueAfterEmptyFrames = 2;

  Duration get liveFrameInterval => Platform.isAndroid
      ? Duration(milliseconds: androidAdaptiveFrameIntervalMs)
      : const Duration(milliseconds: 250);

  static const Map<DeviceOrientation, int> _deviceOrientations = {
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  final PlatformTextRecognizer textRecognizer = PlatformTextRecognizer(
    script: TextRecognitionScript.latin,
  );

  // Android release build'de google_mlkit_commons InputImageConverter
  // canlı NV21 karelerde kararsız davrandığı için Android OCR doğrudan
  // kendi Kotlin MethodChannel köprümüz üzerinden native ML Kit'e gider.
  // iOS tarafı mevcut Flutter ML Kit akışını kullanmaya devam eder.
  static const MethodChannel _nativeAndroidOcrChannel = MethodChannel(
    'com.mustafasenocak.gamelingo/native_ocr',
  );

  late final OnDeviceScreenTranslator translator;



  final FlutterTts flutterTts = FlutterTts();

  // ==========================================================
  // ELEVENLABS AI TTS STREAM PLAYER
  // ==========================================================
  // AI ses üretimi çeviri/OCR hattını hiçbir zaman bloklamaz.
  // /tts/ai/prepare yalnızca stream/cache URL'sini hazırlar;
  // gerçek ses bu player ile URL üzerinden progressive olarak oynatılır.
  // AI ses başlayamazsa mevcut cihaz TTS'i otomatik yedek olarak kullanılır.
  // Double-buffer:
  // aiAudioPlayer o anda konuşan sesi oynatır.
  // aiStandbyAudioPlayer sıradaki repliğin MP3 kaynağını önceden yükler.
  // Sıra değiştiğinde player referansları swap edilir; böylece ağ + dosya
  // hazırlığı + AVPlayer source hazırlığı mümkün olduğunca konuşma sırasında
  // tamamlanmış olur.
  AudioPlayer aiAudioPlayer = AudioPlayer();
  AudioPlayer aiStandbyAudioPlayer = AudioPlayer();

  String? aiStandbySpeechKey;
  String? aiStandbyFilePath;
  bool isAiStandbyLoading = false;

  // Prefetch edilen tüm sesler RAM'de beklemek yerine cihazın geçici
  // dizinine .mp3 olarak yazılır. Oynatma bittiğinde dosya silinir.
  final Set<String> aiTtsTempFiles = <String>{};

  static const String aiTtsBackendBaseUrl = 'https://api.gamelingo.app';

  // Şimdilik entegrasyon testi için açık. AI Premium ürünü eklendiğinde
  // bu bayrak abonelik entitlement'ı ile değiştirilecek.
  static const bool aiTtsEnabled = true;

  // Karakter adı/cinsiyeti bulunamayan altyazılar da cihaz TTS'ine
  // düşmesin. Bu sabit ElevenLabs sesi genel AI fallback olarak kullanılır.
  // İsim + doğrulanmış cinsiyet bulunduğunda backend karakter havuzundan
  // deterministik sesi seçmeye devam eder.
  static const String genericAiFallbackVoiceId =
      'Ongxzjm6NAJamxlPiP4z'; // Akin - warm / clear

  static const String genericAiFallbackVoiceName = 'Akin';

  static const Duration aiTtsPrepareTimeout = Duration(seconds: 2);

  // ElevenLabs/provider veya stream bağlantısı bu sürede gerçek playback
  // başlatamazsa kullanıcıyı bekletmeden cihaz TTS'ine düş.
  static const Duration aiTtsPlaybackStartupTimeout = Duration(
    milliseconds: 2500,
  );

  static const Duration aiTtsPlaybackCompletionTimeout = Duration(seconds: 30);

  Timer? ocrTimer;

  // ==========================================================
  // ÇEVİRİ OTURUMU + İLK KULLANIM REHBERİ
  // ==========================================================
  // Kamera önizlemesi hemen açılır fakat OCR/çeviri kullanıcı
  // "Çeviriyi Başlat" düğmesine dokunana kadar başlamaz. Böylece kullanıcı
  // zoom ve tarama alanını ücretsiz demo süresini tüketmeden ayarlayabilir.
  static const String _cameraIntroSeenKey =
      'translation_camera_intro_v1_seen';

  bool showCameraIntro = false;
  bool isCameraIntroLoaded = false;
  bool isTranslationRunning = false;
  bool isStartingTranslation = false;

  // ==========================================================
  // 5 DAKİKALIK ÜCRETSİZ ÇEVİRİ DENEMESİ
  // ==========================================================
  Timer? demoUsageTimer;
  int demoUsedSeconds = 0;
  bool isDemoUsageLoaded = false;
  bool demoExpiryNavigationStarted = false;
  bool isPremiumUser = false;

  int get demoRemainingSeconds =>
      (FreeTranslationTrialStore.totalSeconds - demoUsedSeconds)
          .clamp(0, FreeTranslationTrialStore.totalSeconds)
          .toInt();

  String get demoRemainingLabel {
    final minutes = demoRemainingSeconds ~/ 60;
    final seconds = demoRemainingSeconds % 60;

    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }

  bool isLoading = true;
  bool isProcessingImage = false;
  bool isTranslatorReady = false;
  bool isTranslating = false;
  bool isTtsReady = false;
  bool isSpeaking = false;
  bool showEnglishText = false;
  bool showTurkishText = false;
  bool isLoadingVoices = false;

  // ==========================================================
  // TTS AYAR CACHE
  // ==========================================================
  // Android TTS ayarları motor içinde kalıcıdır. Aynı karakter ve
  // aynı duygu arka arkaya konuşurken setVoice / setSpeechRate /
  // setPitch / setVolume çağrılarını tekrar göndermek gereksiz
  // MethodChannel gecikmesi yaratır.
  //
  // Bu alanlar son uygulanmış TTS konfigürasyonunu tutar. Sadece
  // gerçekten değişen ayar Android tarafına gönderilir.
  String? lastAppliedTtsVoiceKey;
  double? lastAppliedTtsSpeechRate;
  double? lastAppliedTtsPitch;
  double? lastAppliedTtsVolume;

  // ==========================================================
  // BAĞIMSIZ TTS KUYRUĞU
  // ==========================================================
  // OCR/çeviri hattı artık TTS konuşmasının bitmesini beklemez.
  // Yeni altyazılar çevrilir ve burada sıraya alınır; tek bir TTS
  // worker sıradaki konuşmaları güvenli biçimde art arda seslendirir.
  final List<SpeechJob> speechQueue = [];
  final Set<String> queuedSpeechKeys = {};

  // Kuyrukta bekleyen AI replikleri, sıraları gelmeden arka planda
  // hazırlanır. Böylece önceki ses bittiği anda hazır ses oynatılabilir.
  final Map<String, Future<AiTtsPreparedAudio?>> aiTtsPrefetchInFlight = {};

  // Karakter profil sorgusu canlı seslendirmeyi BLOKLAMAZ.
  // Aynı konuşmacı için tek bir arka plan sorgusu çalışır.
  final Map<String, Future<CharacterProfile>> characterProfileLookupsInFlight =
      {};

  // Bulunamayan karakteri her replikte tekrar tekrar sorgulamayalım.
  final Map<String, DateTime> characterProfileNegativeCacheUntil = {};

  static const Duration characterProfileNegativeCacheDuration = Duration(
    minutes: 30,
  );

  bool isSpeechWorkerRunning = false;
  String? currentSpeechKey;

  // ==========================================================
  // CANLI ANDROID OCR + ÇEVİRİ KUYRUĞU
  // ==========================================================
  // OCR artık çeviri isteğinin bitmesini beklemez. Çeviri sürerken
  // yeni bir altyazı görülürse en güncel metin tek-slot kuyruğa alınır.
  // Böylece kısa süre ekranda kalan replikler isTranslating yüzünden
  // tamamen kaçırılmaz.
  String? pendingTranslationSource;
  bool translationDrainRunning = false;

  // CameraX NV21 canlı akışında beklenmeyen cihaz/format problemi
  // olursa uygulama otomatik olarak fotoğraf tabanlı güvenli moda döner.
  int liveFrameConversionFailureCount = 0;
  bool isUsingPhotoOcrFallback = false;
  bool hasLoggedLiveFrameFormat = false;

  // ==========================================================
  // ANDROID EKRANDA KALAN ALTYAZI KİLİDİ
  // ==========================================================
  // Android canlı OCR aynı ekrandaki cümleyi her karede yeniden
  // görebilir. Zaman penceresine güvenmek yerine, aynı altyazı
  // ekranda kaldığı sürece onu yalnızca BİR KEZ çeviri/TTS'ye
  // gönderiyoruz. Yeni/farklı altyazı geldiğinde kilit anında değişir.
  // Metin gerçekten kaybolursa kısa bir boşluk sonrasında kilit açılır;
  // böylece aynı cümle oyunda daha sonra gerçekten tekrar edilirse okunur.
  String? androidVisibleSubtitleFingerprint;
  DateTime? androidVisibleSubtitleLastSeenAt;
  int androidVisibleSubtitleEmptyFrames = 0;

  static const int androidVisibleSubtitleEmptyFramesToRelease = 4;

  static const Duration androidVisibleSubtitleReleaseDelay = Duration(
    milliseconds: 900,
  );

  List<TtsVoiceOption> turkishVoices = [];

  String? cameraError;

  String recognizedText = 'Altyazı bekleniyor...';
  String translatedText = 'Türkçe çeviri bekleniyor...';

  // ==========================================================
  // AKILLI OCR STABİLİZASYONU
  // ==========================================================
  // Temiz OCR sonucu anında çeviriye gider.
  // Şüpheli/bozuk görünen tek kare ise yaklaşık bir sonraki
  // canlı OCR karesiyle doğrulanır. Böylece ARWR / bltch /
  // "t over here" gibi geçici kamera-OCR hataları gereksiz yere
  // Groq'a gönderilmez.
  String? pendingOcrCandidate;
  double pendingOcrCandidateScore = 0.0;
  DateTime? pendingOcrCandidateAt;

  static const double immediateOcrConfidenceScore = 85.0;

  static const double ocrCandidateSimilarityThreshold = 0.72;

  static const Duration maxOcrStabilizationWait = Duration(milliseconds: 550);

  String lastTranslatedSource = '';
  String lastSpokenText = '';
  DateTime? lastSpokenAt;

  // TTS katmanındaki duplicate koruması yalnızca kısa süreli olsun.
  // Böylece aynı replik oyun içinde daha sonra tekrar oynatıldığında
  // sunucu/R2 cache'i gerçekten test edilebilir ve tekrar seslendirilebilir.
  static const Duration ttsDuplicateCooldown = Duration(milliseconds: 1200);

  String? currentSpeaker;
  DateTime? lastSpeakerDetectedAt;
  String? lastConfirmedSpeakerDialogue;

  // Aynı karakterin ardışık cümlelerinde duygunun bir karede
  // normal, diğer karede öfkeli/panik gibi zıplamasını önler.
  final Map<String, SpeechEmotion> lastEmotionBySpeaker = {};
  final Map<String, DateTime> lastEmotionAtBySpeaker = {};

  // Groq'a yalnızca kısa bağlam gönderiyoruz.
  // Böylece deyim/argo anlamı iyileşirken gereksiz token harcanmaz.
  final List<String> recentDialogueContext = [];

  // Aynı altyazı ekranda birkaç saniye kaldığında OCR onu tekrar tekrar
  // okuyabilir. Bu alanlar aynı satırın yeniden Groq'a gönderilmesini ve
  // tekrar seslendirilmesini engeller.
  String? lastProcessedSubtitleKey;
  DateTime? lastProcessedSubtitleAt;

  // OCR aynı altyazıyı küçük yazım hatalarıyla yeniden okuyabilir:
  // remember -> reember / romomber, ARTHUR -> ARTHURB vb.
  // Exact key tek başına bunları yakalayamadığı için son işlenen
  // altyazının fuzzy karşılaştırma için sadeleştirilmiş halini de tutuyoruz.
  String? lastProcessedSubtitleFuzzyText;
  String? lastProcessedSubtitleSpeaker;

  // Kısa süreli çeviri önbelleği:
  // Aynı oyun + aynı konuşmacı + aynı İngilizce cümle kısa süre içinde
  // tekrar gelirse Groq'a yeni istek atmak yerine önceki çeviriyi kullanır.
  final Map<String, CachedTranslation> translationCache = {};

  static const Duration duplicateSubtitleWindow = Duration(seconds: 5);

  static const Duration translationCacheLifetime = Duration(minutes: 10);

  static const int maxTranslationCacheEntries = 150;

  static const String backendBaseUrl =
      'https://oyun-ceviri-backend-production-2af7.up.railway.app';

  // ==========================================================
  // PERFORMANS ÖLÇÜMÜ
  // ==========================================================
  int performanceRunId = 0;
  int? activePerformanceRunId;
  Stopwatch? activePerformanceTotalWatch;

  void logPerformance(String stage, {int? durationMs, String? extra}) {
    // Release build'de yüksek frekanslı PERF logları düşük/orta seviye
    // Android cihazlarda gereksiz I/O ve string üretimi oluşturmasın.
    if (!kDebugMode) {
      return;
    }

    final runId = activePerformanceRunId;

    final totalMs = activePerformanceTotalWatch?.elapsedMilliseconds;

    final durationText = durationMs == null ? '' : ' | aşama=${durationMs}ms';

    final totalText = totalMs == null ? '' : ' | toplam=${totalMs}ms';

    final extraText = extra == null || extra.trim().isEmpty ? '' : ' | $extra';

    debugPrint(
      '⏱ PERF #${runId ?? '-'} '
      '$stage'
      '$durationText'
      '$totalText'
      '$extraText',
    );
  }

  void ocrDebugPrint(String message) {
    if (kDebugMode) {
      debugPrint(message);
    }
  }

  void updateRecognizedTextIfChanged(String value) {
    if (!mounted || isCameraPageDisposing || recognizedText == value) {
      return;
    }

    setState(() {
      recognizedText = value;
    });
  }

  void updateAndroidAdaptivePerformance({
    required int ocrMs,
    required bool hasSubtitleRegionText,
    required bool usedFullResolutionRescue,
  }) {
    if (!Platform.isAndroid) {
      return;
    }

    androidOcrSampleCount++;

    if (androidOcrAverageMs <= 0) {
      androidOcrAverageMs = ocrMs.toDouble();
    } else {
      // EMA: ani tek kare sıçramaları yerine cihazın gerçek sürdürülebilir
      // OCR maliyetine göre karar ver.
      androidOcrAverageMs =
          (androidOcrAverageMs * 0.72) + (ocrMs.toDouble() * 0.28);
    }

    if (!androidHalfResolutionOcr &&
        androidOcrSampleCount >= androidHalfResolutionEnableAfterSamples &&
        androidOcrAverageMs >= androidHalfResolutionEnableAverageMs) {
      androidHalfResolutionOcr = true;
      androidHalfResolutionEmptyFrames = 0;

      ocrDebugPrint(
        'ANDROID ADAPTİF OCR: yarım çözünürlük etkinleştirildi '
        '(ortalama=${androidOcrAverageMs.toStringAsFixed(0)}ms).',
      );
    }

    final now = DateTime.now();

    if (hasSubtitleRegionText) {
      androidLastSubtitleRegionTextAt = now;
      androidHalfResolutionEmptyFrames = 0;
    } else if (androidHalfResolutionOcr) {
      if (usedFullResolutionRescue) {
        // Tam çözünürlüklü kontrol yapıldı; yeni rescue döngüsünü başlat.
        androidHalfResolutionEmptyFrames = 0;
      } else {
        androidHalfResolutionEmptyFrames++;
      }
    }

    final recentlySawSubtitle =
        androidLastSubtitleRegionTextAt != null &&
        now.difference(androidLastSubtitleRegionTextAt!) <
            const Duration(milliseconds: 1400);

    // Altyazı varken daha agresif tara. Boş sahnede CPU/GPU/termal yükü
    // azalt. OCR zaten yavaşsa kendi maliyetinin biraz üstünde boşluk bırak.
    final activityTargetMs = hasSubtitleRegionText
        ? 155
        : (recentlySawSubtitle ? 205 : 310);

    final loadTargetMs = math.max(
      activityTargetMs,
      (androidOcrAverageMs * 1.22).round(),
    );

    final clampedTargetMs = loadTargetMs
        .clamp(androidMinFrameIntervalMs, androidMaxFrameIntervalMs)
        .toInt();

    androidAdaptiveFrameIntervalMs =
        ((androidAdaptiveFrameIntervalMs * 0.68) +
                (clampedTargetMs * 0.32))
            .round()
            .clamp(androidMinFrameIntervalMs, androidMaxFrameIntervalMs)
            .toInt();
  }

  bool get shouldUseAndroidFullResolutionRescue =>
      Platform.isAndroid &&
      androidHalfResolutionOcr &&
      androidHalfResolutionEmptyFrames >=
          androidFullResolutionRescueAfterEmptyFrames;

  Uint8List downscaleNv21ByTwo(
    Uint8List source,
    int sourceWidth,
    int sourceHeight,
  ) {
    final targetWidth = sourceWidth ~/ 2;
    final targetHeight = sourceHeight ~/ 2;

    final sourceYSize = sourceWidth * sourceHeight;
    final targetYSize = targetWidth * targetHeight;
    final target = Uint8List(targetYSize + (targetYSize ~/ 2));

    var out = 0;

    // Luma: nearest-neighbour 2x küçültme. OCR için keskin kenarları
    // korur ve image paketine dönüştürme maliyetinden çok daha hafiftir.
    for (var y = 0; y < targetHeight; y++) {
      final sourceRow = (y * 2) * sourceWidth;

      for (var x = 0; x < targetWidth; x++) {
        target[out++] = source[sourceRow + (x * 2)];
      }
    }

    // NV21 chroma bölümü VU çiftleri halinde tutulur. Her hedef VU çifti
    // kaynak chroma düzlemindeki her ikinci satır / her ikinci çiftten alınır.
    final targetChromaRows = targetHeight ~/ 2;
    final targetChromaPairsPerRow = targetWidth ~/ 2;

    for (var row = 0; row < targetChromaRows; row++) {
      final sourceChromaRow = row * 2;
      final sourceRowOffset =
          sourceYSize + (sourceChromaRow * sourceWidth);

      for (var pair = 0; pair < targetChromaPairsPerRow; pair++) {
        final sourcePairOffset = sourceRowOffset + (pair * 4);

        target[out++] = source[sourcePairOffset];
        target[out++] = source[sourcePairOffset + 1];
      }
    }

    return target;
  }

  // ==========================================================
  // OYUN BAZLI AYARLANABİLİR TARAMA ALANI
  // ==========================================================
  // Varsayılan değerler mevcut çalışan bölgeyi korur.
  // Kullanıcı alanı değiştirdiğinde oranlar yalnızca o oyun için
  // SharedPreferences'a kaydedilir.
  static const double defaultScanLeftFactor = 0.0;
  static const double defaultScanRightFactor = 0.95;
  static const double defaultScanTopFactor = 0.48;
  static const double defaultScanBottomFactor = 0.82;

  static const double minScanWidthFactor = 0.20;
  static const double minScanHeightFactor = 0.10;

  double scanLeftFactor = defaultScanLeftFactor;

  double scanRightFactor = defaultScanRightFactor;

  double scanTopFactor = defaultScanTopFactor;

  double scanBottomFactor = defaultScanBottomFactor;

  bool isEditingScanArea = false;
  bool isSavingScanArea = false;

  // ==========================================================
  // OYUN BAZLI KAMERA ZOOM
  // ==========================================================
  double minCameraZoom = 1.0;
  double maxCameraZoom = 1.0;
  double currentCameraZoom = 1.0;
  double desiredCameraZoom = 1.0;

  bool isCameraZoomReady = false;

  Timer? cameraZoomDebounceTimer;

  @override
  void initState() {
    super.initState();

    // Yalnızca canlı çeviri ekranında yatay kullanım açıktır.
    unawaited(_enableTranslationOrientations());

    translator = OnDeviceScreenTranslator();

    initializePage();
  }

  Future<void> _enableTranslationOrientations() async {
    await SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  Future<void> _restorePortraitOrientation() async {
    await SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
    ]);
  }

  Future<void> initializePage() async {
    await GameVoiceStore.loadFromStorage();
    await GameAiVoiceStore.loadFromStorage();
    await CharacterProfileStore.loadFromStorage();
    await loadCameraIntroPreference();
    await loadScanAreaForGame();
    await loadCameraZoomForGame();

    final premiumActive = await AppStoreSubscriptionController.instance
        .ensurePremiumAccess();

    if (!mounted) return;

    setState(() {
      isPremiumUser = premiumActive;
    });

    if (!premiumActive) {
      await loadDemoUsage();

      if (demoRemainingSeconds <= 0) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          handleDemoExpired();
        });
        return;
      }
    } else {
      debugPrint(
        'PREMIUM KULLANICI: '
        '5 dakikalık demo sayacı devre dışı.',
      );
    }

    initializeTts();
    initializeTranslator();
    initializeCamera();
  }

  Future<void> loadCameraIntroPreference() async {
    final prefs = await SharedPreferences.getInstance();
    final seen = prefs.getBool(_cameraIntroSeenKey) ?? false;

    if (!mounted) return;

    setState(() {
      showCameraIntro = !seen;
      isCameraIntroLoaded = true;
    });
  }

  Future<void> dismissCameraIntro() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_cameraIntroSeenKey, true);

    if (!mounted) return;

    setState(() {
      showCameraIntro = false;
    });
  }

  Future<void> startTranslationSession() async {
    if (!mounted ||
        isCameraPageDisposing ||
        isLoading ||
        cameraError != null ||
        isTranslationRunning ||
        isStartingTranslation) {
      return;
    }

    if (isEditingScanArea) {
      await saveScanAreaForGame();
      if (!mounted) return;
    }

    setState(() {
      isStartingTranslation = true;
      isTranslationRunning = true;
      recognizedText = 'Altyazı bekleniyor...';
      translatedText = 'Türkçe çeviri bekleniyor...';
    });

    // Her yeni canlı çeviri oturumunda Android kendi cihaz hızını ilk birkaç
    // OCR karesinde yeniden ölçer. iOS akışı değişmeden kalır.
    if (Platform.isAndroid) {
      androidAdaptiveFrameIntervalMs = 220;
      androidOcrAverageMs = 0.0;
      androidOcrSampleCount = 0;
      androidHalfResolutionOcr = false;
      androidHalfResolutionEmptyFrames = 0;
      androidLastSubtitleRegionTextAt = null;
    }

    try {
      await startOcr();

      if (!mounted) return;

      startDemoUsageTimer();

      debugPrint('ÇEVİRİ OTURUMU BAŞLADI: kullanıcı başlat düğmesine dokundu.');
    } catch (e) {
      debugPrint('ÇEVİRİ OTURUMU BAŞLATMA HATASI: $e');

      if (!mounted) return;

      setState(() {
        isTranslationRunning = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Çeviri başlatılamadı. Lütfen tekrar dene.'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isStartingTranslation = false;
        });
      }
    }
  }

  Future<void> loadDemoUsage() async {
    final used = await FreeTranslationTrialStore.loadUsedSeconds();

    if (!mounted) return;

    setState(() {
      demoUsedSeconds = used;
      isDemoUsageLoaded = true;
    });

    debugPrint(
      'ÜCRETSİZ DEMO YÜKLENDİ: '
      '$demoRemainingLabel kaldı.',
    );
  }

  void startDemoUsageTimer() {
    if (!mounted ||
        isCameraPageDisposing ||
        isPremiumUser ||
        !isDemoUsageLoaded ||
        demoRemainingSeconds <= 0 ||
        demoUsageTimer != null) {
      return;
    }

    debugPrint(
      'ÜCRETSİZ DEMO SAYAÇ BAŞLADI: '
      '$demoRemainingLabel kaldı.',
    );

    demoUsageTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || isCameraPageDisposing) {
        return;
      }

      final nextUsed = (demoUsedSeconds + 1)
          .clamp(0, FreeTranslationTrialStore.totalSeconds)
          .toInt();

      setState(() {
        demoUsedSeconds = nextUsed;
      });

      if (nextUsed % 5 == 0 || demoRemainingSeconds <= 0) {
        unawaited(FreeTranslationTrialStore.saveUsedSeconds(nextUsed));
      }

      if (demoRemainingSeconds <= 0) {
        handleDemoExpired();
      }
    });
  }

  Future<void> handleDemoExpired() async {
    if (demoExpiryNavigationStarted || !mounted) {
      return;
    }

    demoExpiryNavigationStarted = true;
    if (tvRelayEnabled) TvLinkHub.instance.client.clear();
    demoUsageTimer?.cancel();
    demoUsageTimer = null;

    demoUsedSeconds = FreeTranslationTrialStore.totalSeconds;

    await FreeTranslationTrialStore.saveUsedSeconds(demoUsedSeconds);

    if (!mounted) return;

    await Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const PremiumPage(trialExpired: true),
      ),
    );
  }

  Future<void> loadScanAreaForGame() async {
    final area = await GameScanAreaStore.load(widget.game.id);

    if (!mounted) return;

    setState(() {
      scanLeftFactor = area.left;

      scanRightFactor = area.right;

      scanTopFactor = area.top;

      scanBottomFactor = area.bottom;
    });

    debugPrint(
      'TARAMA ALANI YÜKLENDİ: '
      'game=${widget.game.id} '
      'left=${area.left.toStringAsFixed(3)} '
      'right=${area.right.toStringAsFixed(3)} '
      'top=${area.top.toStringAsFixed(3)} '
      'bottom=${area.bottom.toStringAsFixed(3)}',
    );
  }

  Future<void> loadCameraZoomForGame() async {
    final savedZoom = await GameCameraZoomStore.load(widget.game.id);

    desiredCameraZoom = savedZoom > 0 ? savedZoom : 1.0;

    debugPrint(
      'KAMERA ZOOM YÜKLENDİ: '
      'game=${widget.game.id} '
      'zoom=${desiredCameraZoom.toStringAsFixed(2)}x',
    );
  }

  Future<void> configureCameraZoom(CameraController controller) async {
    try {
      final minZoom = await controller.getMinZoomLevel();

      final maxZoom = await controller.getMaxZoomLevel();

      final safeMax = maxZoom < minZoom ? minZoom : maxZoom;

      final targetZoom = desiredCameraZoom.clamp(minZoom, safeMax).toDouble();

      await controller.setZoomLevel(targetZoom);

      desiredCameraZoom = targetZoom;

      if (!mounted) return;

      setState(() {
        minCameraZoom = minZoom;

        maxCameraZoom = safeMax;

        currentCameraZoom = targetZoom;

        isCameraZoomReady = true;
      });

      debugPrint(
        'KAMERA ZOOM HAZIR: '
        'min=${minZoom.toStringAsFixed(2)}x '
        'max=${safeMax.toStringAsFixed(2)}x '
        'aktif=${targetZoom.toStringAsFixed(2)}x',
      );
    } on CameraException catch (e) {
      debugPrint(
        'KAMERA ZOOM DESTEKLENMEDİ: '
        '${e.code} / ${e.description ?? ''}',
      );

      if (!mounted) return;

      setState(() {
        minCameraZoom = 1.0;
        maxCameraZoom = 1.0;
        currentCameraZoom = 1.0;
        desiredCameraZoom = 1.0;
        isCameraZoomReady = false;
      });
    } catch (e) {
      debugPrint('KAMERA ZOOM HATASI: $e');
    }
  }

  void previewCameraZoom(double value) {
    final controller = cameraController;

    if (controller == null ||
        !controller.value.isInitialized ||
        !isCameraZoomReady ||
        isCameraPageDisposing) {
      return;
    }

    final safeZoom = value.clamp(minCameraZoom, maxCameraZoom).toDouble();

    desiredCameraZoom = safeZoom;

    if (mounted) {
      setState(() {
        currentCameraZoom = safeZoom;
      });
    }

    // Slider hareket ederken zoom'u anında kameraya uygula.
    // Kaydetme işlemi yalnızca kullanıcı slider'ı bıraktığında yapılır.
    unawaited(
      controller.setZoomLevel(safeZoom).catchError((Object e) {
        debugPrint('KAMERA ZOOM CANLI ÖNİZLEME HATASI: $e');
      }),
    );
  }

  double _zoomSliderPositionFromLevel(double zoomLevel) {
    final range = maxCameraZoom - minCameraZoom;

    if (!isCameraZoomReady || range <= 0.0001) {
      return 0.0;
    }

    final normalized =
        ((zoomLevel - minCameraZoom) / range).clamp(0.0, 1.0).toDouble();

    // Kare kök ters dönüşümü:
    // düşük zoom değerlerinde daha geniş slider hareketi gerekir,
    // böylece 1x–3x aralığı çok daha hassas kontrol edilir.
    return math.sqrt(normalized);
  }

  double _zoomLevelFromSliderPosition(double position) {
    final safePosition = position.clamp(0.0, 1.0).toDouble();
    final range = maxCameraZoom - minCameraZoom;

    if (!isCameraZoomReady || range <= 0.0001) {
      return minCameraZoom;
    }

    // Quadratic curve: slider'ın ilk yarısı düşük zoom seviyelerine
    // ayrılır. Kullanıcı küçük bir hareket yaptığında kamera bir anda
    // yüksek zoom'a sıçramaz.
    final curved = safePosition * safePosition;

    return (minCameraZoom + (range * curved))
        .clamp(minCameraZoom, maxCameraZoom)
        .toDouble();
  }

  Future<void> commitCameraZoom(double value) async {
    final controller = cameraController;

    if (controller == null ||
        !controller.value.isInitialized ||
        !isCameraZoomReady ||
        isCameraPageDisposing) {
      return;
    }

    cameraZoomDebounceTimer?.cancel();

    final safeZoom = value.clamp(minCameraZoom, maxCameraZoom).toDouble();

    try {
      await controller.setZoomLevel(safeZoom);

      desiredCameraZoom = safeZoom;

      if (mounted) {
        setState(() {
          currentCameraZoom = safeZoom;
        });
      }

      await GameCameraZoomStore.save(widget.game.id, safeZoom);

      debugPrint(
        'KAMERA ZOOM KAYDEDİLDİ: '
        'game=${widget.game.id} '
        'zoom=${safeZoom.toStringAsFixed(2)}x',
      );

      // Zoom değişince görüntü geometrisi de değişir.
      // Kamera yeni kadrajın altyazı alanına tekrar odaklansın.
      await focusAndExposeOnScanArea(reason: 'zoom kaydedildi');
    } on CameraException catch (e) {
      debugPrint(
        'KAMERA ZOOM KAYDETME HATASI: '
        '${e.code} / ${e.description ?? ''}',
      );
    } catch (e) {
      debugPrint('KAMERA ZOOM KAYDETME HATASI: $e');
    }
  }

  Future<void> saveScanAreaForGame() async {
    if (isSavingScanArea) {
      return;
    }

    if (mounted) {
      setState(() {
        isSavingScanArea = true;
      });
    }

    try {
      final area = SubtitleScanArea(
        left: scanLeftFactor,
        right: scanRightFactor,
        top: scanTopFactor,
        bottom: scanBottomFactor,
      );

      await GameScanAreaStore.save(widget.game.id, area);

      debugPrint(
        'TARAMA ALANI KAYDEDİLDİ: '
        'game=${widget.game.id} '
        'left=${area.left.toStringAsFixed(3)} '
        'right=${area.right.toStringAsFixed(3)} '
        'top=${area.top.toStringAsFixed(3)} '
        'bottom=${area.bottom.toStringAsFixed(3)}',
      );

      // Alan değiştiyse kamera da yeni altyazı merkezine
      // yeniden kilitlensin.
      await focusAndExposeOnScanArea(reason: 'tarama alanı kaydedildi');

      if (!mounted) return;

      setState(() {
        isEditingScanArea = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tarama alanı bu oyun için kaydedildi.'),
          duration: Duration(milliseconds: 1400),
        ),
      );
    } catch (e) {
      debugPrint('TARAMA ALANI KAYDETME HATASI: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tarama alanı kaydedilemedi.')),
      );
    } finally {
      if (mounted) {
        setState(() {
          isSavingScanArea = false;
        });
      }
    }
  }

  void startEditingScanArea() {
    if (!mounted) return;

    setState(() {
      isEditingScanArea = true;
    });
  }

  double clampFactor(double value, double min, double max) {
    return value.clamp(min, max).toDouble();
  }

  void moveScanArea(DragUpdateDetails details, Size size) {
    if (!isEditingScanArea || size.width <= 0 || size.height <= 0) {
      return;
    }

    final dx = details.delta.dx / size.width;

    final dy = details.delta.dy / size.height;

    final areaWidth = scanRightFactor - scanLeftFactor;

    final areaHeight = scanBottomFactor - scanTopFactor;

    final newLeft = clampFactor(scanLeftFactor + dx, 0.0, 1.0 - areaWidth);

    final newTop = clampFactor(scanTopFactor + dy, 0.0, 1.0 - areaHeight);

    setState(() {
      scanLeftFactor = newLeft;

      scanRightFactor = newLeft + areaWidth;

      scanTopFactor = newTop;

      scanBottomFactor = newTop + areaHeight;
    });
  }

  void resizeScanArea(
    DragUpdateDetails details,
    Size size, {
    required bool resizeLeft,
    required bool resizeTop,
  }) {
    if (!isEditingScanArea || size.width <= 0 || size.height <= 0) {
      return;
    }

    final dx = details.delta.dx / size.width;

    final dy = details.delta.dy / size.height;

    var left = scanLeftFactor;

    var right = scanRightFactor;

    var top = scanTopFactor;

    var bottom = scanBottomFactor;

    if (resizeLeft) {
      left = clampFactor(left + dx, 0.0, right - minScanWidthFactor);
    } else {
      right = clampFactor(right + dx, left + minScanWidthFactor, 1.0);
    }

    if (resizeTop) {
      top = clampFactor(top + dy, 0.0, bottom - minScanHeightFactor);
    } else {
      bottom = clampFactor(bottom + dy, top + minScanHeightFactor, 1.0);
    }

    setState(() {
      scanLeftFactor = left;
      scanRightFactor = right;
      scanTopFactor = top;
      scanBottomFactor = bottom;
    });
  }

  Future<void> initializeTts() async {
    try {
      await flutterTts.setLanguage('tr-TR');
      await flutterTts.setSpeechRate(0.48);
      await flutterTts.setVolume(1.0);
      await flutterTts.setPitch(1.0);
      await flutterTts.awaitSpeakCompletion(true);

      // Canlı çeviri ekranında Android TTS motoruna uygulanmış
      // başlangıç ayarlarını cache'e kaydet.
      lastAppliedTtsVoiceKey = null;
      lastAppliedTtsSpeechRate = 0.48;
      lastAppliedTtsPitch = 1.0;
      lastAppliedTtsVolume = 1.0;

      flutterTts.setStartHandler(() {
        if (!mounted) return;
        setState(() => isSpeaking = true);
      });

      flutterTts.setCompletionHandler(() {
        if (!mounted) return;
        setState(() => isSpeaking = false);
      });

      flutterTts.setCancelHandler(() {
        if (!mounted) return;
        setState(() => isSpeaking = false);
      });

      flutterTts.setErrorHandler((message) {
        debugPrint('TTS HATASI: $message');

        if (!mounted) return;
        setState(() => isSpeaking = false);
      });

      if (!mounted) return;

      setState(() {
        isTtsReady = true;
      });

      await loadTurkishVoices();
    } catch (e, stackTrace) {
      debugPrint('TTS BAŞLATMA HATASI: $e');
      debugPrint('$stackTrace');

      if (!mounted) return;

      setState(() {
        isTtsReady = false;
      });
    }
  }

  Future<void> loadTurkishVoices() async {
    if (isLoadingVoices) return;

    if (mounted) {
      setState(() {
        isLoadingVoices = true;
      });
    }

    try {
      final dynamic rawVoices = await flutterTts.getVoices;

      final List<TtsVoiceOption> foundVoices = [];

      if (rawVoices is List) {
        for (final dynamic voice in rawVoices) {
          if (voice is! Map) continue;

          final String name = (voice['name'] ?? '').toString().trim();

          final String locale = (voice['locale'] ?? '').toString().trim();

          final normalizedLocale = locale.toLowerCase().replaceAll('_', '-');

          if (normalizedLocale.startsWith('tr')) {
            foundVoices.add(
              TtsVoiceOption(
                name: name.isEmpty ? 'İsimsiz Türkçe ses' : name,
                locale: locale.isEmpty ? 'tr-TR' : locale,
              ),
            );
          }
        }
      }

      final unique = <String, TtsVoiceOption>{};

      for (final voice in foundVoices) {
        unique[voice.key] = voice;
      }

      final voices = unique.values.toList()
        ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

      if (!mounted) return;

      setState(() {
        turkishVoices = voices;
        isLoadingVoices = false;
      });

      debugPrint('TÜRKÇE SES SAYISI: ${voices.length}');

      for (int i = 0; i < voices.length; i++) {
        debugPrint('SES ${i + 1}: ${voices[i].name} / ${voices[i].locale}');
      }
    } catch (e, stackTrace) {
      debugPrint('SES LİSTESİ HATASI: $e');
      debugPrint('$stackTrace');

      if (!mounted) return;

      setState(() {
        turkishVoices = [];
        isLoadingVoices = false;
      });
    }
  }

  Future<CharacterProfile> resolveCharacterProfile(String? speaker) async {
    if (speaker == null || speaker.trim().isEmpty) {
      return const CharacterProfile(
        found: false,
        matchedName: null,
        gender: 'unknown',
      );
    }

    final normalizedSpeaker = GameVoiceStore.normalizeSpeaker(speaker);

    final cached = CharacterProfileStore.get(
      gameId: widget.game.id,
      speaker: normalizedSpeaker,
    );

    if (cached != null &&
        cached.found &&
        (cached.gender == 'male' || cached.gender == 'female')) {
      return cached;
    }

    CharacterProfile? lastProfile;

    for (var attempt = 1; attempt <= 3; attempt++) {
      try {
        final uri = Uri.parse('$backendBaseUrl/characters/profile').replace(
          queryParameters: {
            'name': speaker.trim(),
            'gameId': widget.game.id.toString(),
          },
        );

        final response = await http
            .get(uri)
            .timeout(const Duration(seconds: 8));

        if (response.statusCode != 200) {
          debugPrint(
            'KARAKTER PROFİL HTTP HATASI '
            '($attempt/3): '
            '${response.statusCode}',
          );

          await Future.delayed(const Duration(milliseconds: 350));
          continue;
        }

        final dynamic decoded = jsonDecode(response.body);

        if (decoded is! Map) {
          await Future.delayed(const Duration(milliseconds: 350));
          continue;
        }

        final data = Map<String, dynamic>.from(decoded);

        if (data['found'] == true && data['character'] is Map) {
          final character = Map<String, dynamic>.from(data['character'] as Map);

          final profile = CharacterProfile(
            found: true,
            matchedName: character['name']?.toString(),
            gender:
                character['gender']?.toString().toLowerCase().trim() ??
                'unknown',
          );

          lastProfile = profile;

          if (profile.gender == 'male' || profile.gender == 'female') {
            await CharacterProfileStore.save(
              gameId: widget.game.id,
              speaker: normalizedSpeaker,
              profile: profile,
            );

            debugPrint(
              'KARAKTER PROFİLİ: '
              '$normalizedSpeaker -> '
              '${profile.matchedName} / '
              '${profile.gender}',
            );

            return profile;
          }
        } else {
          lastProfile = const CharacterProfile(
            found: false,
            matchedName: null,
            gender: 'unknown',
          );
        }
      } catch (e) {
        debugPrint(
          'KARAKTER PROFİL BAĞLANTI '
          'HATASI ($attempt/3): $e',
        );
      }

      if (attempt < 3) {
        await Future.delayed(const Duration(milliseconds: 350));
      }
    }

    debugPrint(
      'KARAKTER PROFİLİ BULUNAMADI: '
      '$normalizedSpeaker',
    );

    // Başarısız/unknown sonuç artık kalıcı
    // önbelleğe yazılmıyor.
    return lastProfile ??
        const CharacterProfile(
          found: false,
          matchedName: null,
          gender: 'unknown',
        );
  }

  CharacterProfile getCachedCharacterProfileOrUnknown(String speaker) {
    final normalizedSpeaker = GameVoiceStore.normalizeSpeaker(speaker);

    final cached = CharacterProfileStore.get(
      gameId: widget.game.id,
      speaker: normalizedSpeaker,
    );

    if (cached != null &&
        cached.found &&
        (cached.gender == 'male' || cached.gender == 'female')) {
      return cached;
    }

    return const CharacterProfile(
      found: false,
      matchedName: null,
      gender: 'unknown',
    );
  }

  Future<void> warmCharacterProfileInBackground(String speaker) async {
    final normalizedSpeaker = GameVoiceStore.normalizeSpeaker(speaker);

    final cached = CharacterProfileStore.get(
      gameId: widget.game.id,
      speaker: normalizedSpeaker,
    );

    if (cached != null &&
        cached.found &&
        (cached.gender == 'male' || cached.gender == 'female')) {
      return;
    }

    final now = DateTime.now();

    final negativeUntil = characterProfileNegativeCacheUntil[normalizedSpeaker];

    if (negativeUntil != null && now.isBefore(negativeUntil)) {
      debugPrint(
        'KARAKTER PROFİL ARKA PLAN CACHE: '
        '$normalizedSpeaker -> unknown',
      );
      return;
    }

    if (characterProfileLookupsInFlight.containsKey(normalizedSpeaker)) {
      return;
    }

    debugPrint(
      'KARAKTER PROFİL ARKA PLAN BAŞLADI: '
      '$normalizedSpeaker',
    );

    final lookupFuture = resolveCharacterProfile(speaker);

    characterProfileLookupsInFlight[normalizedSpeaker] = lookupFuture;

    try {
      final profile = await lookupFuture;

      if (profile.found &&
          (profile.gender == 'male' || profile.gender == 'female')) {
        characterProfileNegativeCacheUntil.remove(normalizedSpeaker);

        debugPrint(
          'KARAKTER PROFİL ARKA PLAN HAZIR: '
          '$normalizedSpeaker -> '
          '${profile.matchedName ?? normalizedSpeaker} / '
          '${profile.gender}',
        );
      } else {
        characterProfileNegativeCacheUntil[normalizedSpeaker] = DateTime.now()
            .add(characterProfileNegativeCacheDuration);

        debugPrint(
          'KARAKTER PROFİL ARKA PLAN UNKNOWN: '
          '$normalizedSpeaker',
        );
      }
    } catch (e) {
      characterProfileNegativeCacheUntil[normalizedSpeaker] = DateTime.now()
          .add(const Duration(minutes: 2));

      debugPrint(
        'KARAKTER PROFİL ARKA PLAN HATASI: '
        '$normalizedSpeaker -> $e',
      );
    } finally {
      characterProfileLookupsInFlight.remove(normalizedSpeaker);
    }
  }

  String voiceGender(TtsVoiceOption voice) {
    final name = voice.name.toLowerCase();

    // iOS Türkçe sistem sesleri
    if (name.contains('cem')) return 'male';
    if (name.contains('yelda')) return 'female';

    // Google Android Türkçe TTS:
    // ama + tmc = erkek
    // cfs + efu + mfm = kadın
    // tr-TR-language, cfs'in varsayılan
    // kadın sesine karşılık gelebilir.
    if (name.contains('tr-tr-x-ama') || name.contains('tr-tr-x-tmc')) {
      return 'male';
    }

    if (name.contains('tr-tr-x-cfs') ||
        name.contains('tr-tr-x-efu') ||
        name.contains('tr-tr-x-mfm') ||
        name == 'tr-tr-language') {
      return 'female';
    }

    return 'unknown';
  }

  String voiceFamily(TtsVoiceOption voice) {
    final name = voice.name.toLowerCase();

    for (final family in ['ama', 'cfs', 'efu', 'mfm', 'tmc']) {
      if (name.contains('x-$family')) {
        return family;
      }
    }

    if (name == 'tr-tr-language') {
      return 'cfs';
    }

    return name;
  }

  int voicePreferenceScore(TtsVoiceOption voice) {
    final name = voice.name.toLowerCase();

    // Aynı sesin local/network kopyası varsa
    // network sürümünü önce deniyoruz.
    if (name.endsWith('-network')) {
      return 0;
    }

    if (name.endsWith('-local')) {
      return 1;
    }

    return 2;
  }

  List<TtsVoiceOption> distinctVoicesForGender(String gender) {
    final matching =
        turkishVoices.where((voice) => voiceGender(voice) == gender).toList()
          ..sort(
            (a, b) =>
                voicePreferenceScore(a).compareTo(voicePreferenceScore(b)),
          );

    final result = <TtsVoiceOption>[];

    final seenFamilies = <String>{};

    for (final voice in matching) {
      final family = voiceFamily(voice);

      if (seenFamilies.add(family)) {
        result.add(voice);
      }
    }

    return result;
  }

  Set<String> usedVoiceFamilies(int gameId) {
    final result = <String>{};

    final assignments = GameVoiceStore.assignmentsForGame(gameId);

    for (final voiceKey in assignments.values) {
      for (final voice in turkishVoices) {
        if (voice.key == voiceKey) {
          result.add(voiceFamily(voice));
          break;
        }
      }
    }

    return result;
  }

  double pitchForCharacter(CharacterProfile profile) {
    // Artık gerçek erkek/kadın ses havuzu
    // seçildiği için sesi yapay biçimde
    // aşırı kalınlaştırmıyoruz.
    switch (profile.gender) {
      case 'male':
        return 0.97;
      case 'female':
        return 1.03;
      default:
        return 1.0;
    }
  }

  bool isGenericSpeakerLabel(String? speaker) {
    if (speaker == null || speaker.trim().isEmpty) {
      return false;
    }

    final normalized = GameVoiceStore.normalizeSpeaker(speaker);

    const genericLabels = <String>{
      'UNKNOWN',
      'ANONYMOUS',
      'ANONIM',
      'ANONİM',
      'SPEAKER',
      'VOICE',
      'RADIO',
      'RADIO VOICE',
      'GUARD',
      'SOLDIER',
      'ENEMY',
      'ALLY',
      'MAN',
      'WOMAN',
      'MALE VOICE',
      'FEMALE VOICE',
      'CROWD',
      'NPC',
      'NARRATOR',
      'ANNOUNCER',
      'OPERATOR',
    };

    return genericLabels.contains(normalized);
  }

  Future<TtsVoiceOption?> getFallbackVoiceForUnknownSpeaker() async {
    if (turkishVoices.isEmpty) {
      await loadTurkishVoices();
    }

    if (turkishVoices.isEmpty) {
      return null;
    }

    // Android'in genel Türkçe sesi varsa bilinmeyen/geçici
    // konuşmacılar için onu kullan. Bu seçim hiçbir karaktere
    // kaydedilmez; gerçek karakter daha sonra tanındığında kendi
    // kalıcı sesine geri döner.
    for (final voice in turkishVoices) {
      if (voice.name.toLowerCase().trim() == 'tr-tr-language') {
        return voice;
      }
    }

    final candidates = List<TtsVoiceOption>.from(turkishVoices)
      ..sort(
        (a, b) => voicePreferenceScore(a).compareTo(voicePreferenceScore(b)),
      );

    return candidates.first;
  }

  Future<TtsVoiceOption?> getOrAssignVoiceForSpeaker(
    String? speaker,
    CharacterProfile profile,
  ) async {
    if (speaker == null || speaker.trim().isEmpty) {
      return null;
    }

    if (turkishVoices.isEmpty) {
      await loadTurkishVoices();
    }

    if (turkishVoices.isEmpty) {
      return null;
    }

    final normalizedSpeaker = GameVoiceStore.normalizeSpeaker(speaker);

    final existingVoiceKey = GameVoiceStore.getVoiceKey(
      gameId: widget.game.id,
      speaker: normalizedSpeaker,
    );

    TtsVoiceOption? existingVoice;

    if (existingVoiceKey != null) {
      for (final voice in turkishVoices) {
        if (voice.key == existingVoiceKey) {
          existingVoice = voice;
          break;
        }
      }
    }

    // Kullanıcı elle seçim yaptıysa
    // uygulama onu korur.
    if (existingVoice != null &&
        GameVoiceStore.isManualOverride(
          gameId: widget.game.id,
          speaker: normalizedSpeaker,
        )) {
      return existingVoice;
    }

    final gender = profile.gender;

    // Backend geçici olarak cevap vermezse veya karakter
    // profili "unknown" gelirse daha önce doğru atanmış sesi
    // ASLA değiştirme.
    if (gender != 'male' && gender != 'female') {
      if (existingVoice != null &&
          existingVoice.name.toLowerCase() != 'tr-tr-language') {
        debugPrint(
          'PROFİL UNKNOWN - MEVCUT SES KORUNDU: '
          '$normalizedSpeaker -> ${existingVoice.name}',
        );

        return existingVoice;
      }

      // Cinsiyet doğrulanmadan yeni erkek/kadın sesi atama.
      // Böylece aynı karakter art arda erkek/kadın arasında
      // zıplamaz.
      debugPrint(
        'PROFİL UNKNOWN - YENİ SES ATANMADI: '
        '$normalizedSpeaker',
      );

      return null;
    }

    // tr-TR-language otomatik atamada
    // ASLA kullanılmayacak.
    final automaticVoices = turkishVoices
        .where((voice) => voice.name.toLowerCase() != 'tr-tr-language')
        .toList();

    if (automaticVoices.isEmpty) {
      return null;
    }

    // Mevcut otomatik atama ancak
    // karakterin doğrulanmış cinsiyetiyle
    // uyumluysa korunur.
    if (existingVoice != null &&
        (gender == 'male' || gender == 'female') &&
        voiceGender(existingVoice) == gender &&
        existingVoice.name.toLowerCase() != 'tr-tr-language') {
      return existingVoice;
    }

    List<TtsVoiceOption> candidateVoices;

    if (gender == 'male') {
      candidateVoices = automaticVoices
          .where((voice) => voiceGender(voice) == 'male')
          .toList();
    } else if (gender == 'female') {
      candidateVoices = automaticVoices
          .where((voice) => voiceGender(voice) == 'female')
          .toList();
    } else {
      // Profil bulunamadıysa generic
      // tr-TR-language yerine yalnızca
      // gerçek isimli TTS sesleri kullan.
      candidateVoices = List<TtsVoiceOption>.from(automaticVoices);
    }

    // Cinsiyet doğrulanmışsa karşı cinsiyete
    // kesinlikle düşme.
    if (candidateVoices.isEmpty && (gender == 'male' || gender == 'female')) {
      debugPrint('UYGUN $gender SES BULUNAMADI.');
      return null;
    }

    if (candidateVoices.isEmpty) {
      return null;
    }

    candidateVoices.sort(
      (a, b) => voicePreferenceScore(a).compareTo(voicePreferenceScore(b)),
    );

    final usedFamilies = usedVoiceFamilies(widget.game.id);

    TtsVoiceOption? selectedVoice;

    for (final voice in candidateVoices) {
      if (!usedFamilies.contains(voiceFamily(voice))) {
        selectedVoice = voice;
        break;
      }
    }

    selectedVoice ??= candidateVoices.first;

    await GameVoiceStore.assignVoice(
      gameId: widget.game.id,
      speaker: normalizedSpeaker,
      voiceKey: selectedVoice.key,
      manual: false,
    );

    debugPrint(
      'OTOMATİK SES ATANDI: '
      '$normalizedSpeaker / '
      '$gender -> '
      '${selectedVoice.name}',
    );

    return selectedVoice;
  }

  bool ttsDoubleChanged(
    double? previous,
    double next, {
    double epsilon = 0.0005,
  }) {
    if (previous == null) {
      return true;
    }

    return (previous - next).abs() > epsilon;
  }

  Future<void> applyVoice(
    TtsVoiceOption? voice, {
    required CharacterProfile profile,
    required SpeechEmotion emotion,
  }) async {
    final basePitch = pitchForCharacter(profile);

    final finalPitch = (basePitch * emotion.pitchMultiplier)
        .clamp(0.75, 1.30)
        .toDouble();

    try {
      if (voice == null) {
        // Profil veya uygun ses çözülemediyse Android'in
        // varsayılan sesine dönüp karakter sesini bozma.
        debugPrint('SES DEĞİŞTİRİLMEDİ: Uygun karakter sesi henüz yok.');
        return;
      }

      final voiceChanged = lastAppliedTtsVoiceKey != voice.key;

      final rateChanged = ttsDoubleChanged(
        lastAppliedTtsSpeechRate,
        emotion.speechRate,
      );

      final pitchChanged = ttsDoubleChanged(lastAppliedTtsPitch, finalPitch);

      final volumeChanged = ttsDoubleChanged(
        lastAppliedTtsVolume,
        emotion.volume,
      );

      if (voiceChanged) {
        await flutterTts.setVoice({'name': voice.name, 'locale': voice.locale});

        lastAppliedTtsVoiceKey = voice.key;
      }

      if (rateChanged) {
        await flutterTts.setSpeechRate(emotion.speechRate);

        lastAppliedTtsSpeechRate = emotion.speechRate;
      }

      if (pitchChanged) {
        await flutterTts.setPitch(finalPitch);

        lastAppliedTtsPitch = finalPitch;
      }

      if (volumeChanged) {
        await flutterTts.setVolume(emotion.volume);

        lastAppliedTtsVolume = emotion.volume;
      }

      final changedParts = <String>[];

      if (voiceChanged) {
        changedParts.add('voice');
      }

      if (rateChanged) {
        changedParts.add('rate');
      }

      if (pitchChanged) {
        changedParts.add('pitch');
      }

      if (volumeChanged) {
        changedParts.add('volume');
      }

      final cacheStatus = changedParts.isEmpty
          ? 'CACHE HIT - AYAR GÖNDERİLMEDİ'
          : 'GÜNCELLENDİ: '
                '${changedParts.join(',')}';

      debugPrint(
        'TTS AYAR CACHE: '
        '$cacheStatus',
      );

      debugPrint(
        'SES PROFİLİ: '
        '${profile.gender} / '
        'duygu=${emotion.label} / '
        'rate=${emotion.speechRate} / '
        'pitch=$finalPitch / '
        'volume=${emotion.volume}',
      );
    } catch (e) {
      debugPrint('SES SEÇME / DUYGU UYGULAMA HATASI: $e');

      // Bir platform çağrısı hata verirse cache'i sıfırlıyoruz.
      // Böylece sonraki konuşmada tüm ayarlar yeniden uygulanır
      // ve TTS motoru yanlış bir cache varsayımıyla devam etmez.
      lastAppliedTtsVoiceKey = null;
      lastAppliedTtsSpeechRate = null;
      lastAppliedTtsPitch = null;
      lastAppliedTtsVolume = null;

      // Hata halinde varsayılan sese dönmeyip o ana kadar
      // seçilmiş karakter sesini koruyoruz.
    }
  }

  Future<void> showTurkishVoicesDialog() async {
    if (isLoadingVoices) return;

    if (turkishVoices.isEmpty) {
      await loadTurkishVoices();
    }

    if (!mounted) return;

    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF15151A),
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        return SafeArea(
          child: FractionallySizedBox(
            heightFactor: 0.72,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(
                20,
                4,
                20,
                20,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Cihazdaki Türkçe Sesler',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${turkishVoices.length} Türkçe ses bulundu.',
                    style: const TextStyle(
                      color: Colors.white54,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: turkishVoices.isEmpty
                        ? const Center(
                            child: Text(
                              'Türkçe ses bulunamadı.',
                            ),
                          )
                        : ListView.separated(
                            itemCount: turkishVoices.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 10),
                            itemBuilder: (context, index) {
                              final voice =
                                  turkishVoices[index];

                              return Container(
                                padding:
                                    const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color:
                                      const Color(0xFF1D1D23),
                                  borderRadius:
                                      BorderRadius.circular(14),
                                  border: Border.all(
                                    color: Colors.white10,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons
                                          .record_voice_over_rounded,
                                      color:
                                          Color(0xFF9B87FF),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Ses ${index + 1}',
                                            style:
                                                const TextStyle(
                                              color:
                                                  Colors.white38,
                                              fontSize: 12,
                                            ),
                                          ),
                                          Text(
                                            voice.name,
                                            style:
                                                const TextStyle(
                                              fontSize: 15,
                                              fontWeight:
                                                  FontWeight.w600,
                                            ),
                                          ),
                                          Text(
                                            voice.locale,
                                            style:
                                                const TextStyle(
                                              color:
                                                  Colors.white54,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> initializeTranslator() async {
    try {
      if (mounted) {
        setState(() {
          translatedText = 'Çeviri modeli hazırlanıyor...';
        });
      }

      await translator.prepare();

      if (!mounted) return;

      setState(() {
        isTranslatorReady = true;
        translatedText = 'Türkçe çeviri bekleniyor...';
      });
    } catch (e, stackTrace) {
      debugPrint('ÇEVİRİ MODEL HATASI: $e');
      debugPrint('$stackTrace');

      if (!mounted) return;

      setState(() {
        isTranslatorReady = false;
        translatedText = 'Çeviri için internet bağlantısını açık tut.';
      });
    }
  }

  Future<void> focusAndExposeOnScanArea({String reason = 'otomatik'}) async {
    final controller = cameraController;

    if (controller == null ||
        !controller.value.isInitialized ||
        isCameraPageDisposing) {
      return;
    }

    final focusX = (scanLeftFactor + scanRightFactor) / 2.0;

    final focusY = (scanTopFactor + scanBottomFactor) / 2.0;

    final point = Offset(
      focusX.clamp(0.0, 1.0).toDouble(),
      focusY.clamp(0.0, 1.0).toDouble(),
    );

    try {
      // Monitör sabit bir yüzey olduğu için sürekli rastgele
      // odak aramak yerine önce AUTO modunu etkinleştirip
      // doğrudan altyazı bölgesinin merkezini hedefliyoruz.
      await controller.setFocusMode(FocusMode.auto);

      await controller.setExposureMode(ExposureMode.auto);

      await controller.setFocusPoint(point);

      await controller.setExposurePoint(point);

      debugPrint(
        'KAMERA ODAK/POZLAMA: '
        '$reason | '
        'x=${point.dx.toStringAsFixed(3)} '
        'y=${point.dy.toStringAsFixed(3)}',
      );
    } on CameraException catch (e) {
      // Bazı üretici kamera sürücüleri focus/exposure point
      // desteğini eksik verebilir. Böyle bir cihazda OCR ve kamera
      // çalışmaya devam etsin; sadece bu optimizasyonu atla.
      debugPrint(
        'KAMERA ODAK/POZLAMA DESTEKLENMEDİ: '
        '${e.code} / ${e.description ?? ''}',
      );
    } catch (e) {
      debugPrint('KAMERA ODAK/POZLAMA HATASI: $e');
    }
  }

  Future<void> initializeCamera() async {
    try {
      final cameras = await availableCameras();

      if (cameras.isEmpty) {
        setState(() {
          cameraError = 'Bu cihazda kullanılabilir kamera bulunamadı.';
          isLoading = false;
        });

        return;
      }

      CameraDescription selectedCamera = cameras.first;

      for (final camera in cameras) {
        if (camera.lensDirection == CameraLensDirection.back) {
          selectedCamera = camera;
          break;
        }
      }

      final controller = CameraController(
        selectedCamera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid
            ? ImageFormatGroup.nv21
            : ImageFormatGroup.bgra8888,
      );

      await controller.initialize();

      if (!mounted) {
        await controller.dispose();
        return;
      }

      activeCameraDescription = selectedCamera;

      setState(() {
        cameraController = controller;
        isLoading = false;
      });

      await configureCameraZoom(controller);

      // Preview'ın ölçüleri ve kamera oturumu yerleşsin.
      // Ardından o oyun için kayıtlı mor tarama alanının tam
      // merkezine autofocus + auto exposure uygula.
      await Future<void>.delayed(const Duration(milliseconds: 250));

      await focusAndExposeOnScanArea(reason: 'kamera açılışı');

      // OCR burada otomatik başlamaz. Kullanıcı önce kamera/zoom/tarama
      // alanını ayarlayabilir; canlı çeviri yalnızca aşağıdaki başlat
      // düğmesine dokununca devreye girer.
      debugPrint('KAMERA HAZIR: Çeviri kullanıcı başlatana kadar bekliyor.');
    } on CameraException catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;

        if (e.code == 'CameraAccessDenied') {
          cameraError = 'Kamera izni verilmedi.';
        } else {
          cameraError = 'Kamera açılamadı: ${e.description ?? e.code}';
        }
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        cameraError = 'Kamera hatası: $e';
      });
    }
  }

  Future<void> startOcr() async {
    ocrTimer?.cancel();
    ocrTimer = null;

    if (!isTranslationRunning) {
      return;
    }

    final controller = cameraController;

    if (controller == null ||
        !controller.value.isInitialized ||
        isCameraPageDisposing) {
      return;
    }

    try {
      if (controller.value.isStreamingImages) {
        return;
      }

      isUsingPhotoOcrFallback = false;
      liveFrameConversionFailureCount = 0;

      await controller.startImageStream((CameraImage image) {
        if (isCameraPageDisposing ||
            !mounted ||
            !isTranslationRunning ||
            isUsingPhotoOcrFallback) {
          return;
        }

        final now = DateTime.now();

        final previous = lastLiveFrameAcceptedAt;

        if (previous != null && now.difference(previous) < liveFrameInterval) {
          return;
        }

        // OCR sadece başka bir OCR karesi işlenirken bekler.
        // Çeviri artık OCR'ı BLOKLAMAZ.
        if (isProcessingImage) {
          return;
        }

        lastLiveFrameAcceptedAt = now;

        unawaited(processLiveCameraImage(image));
      });

      ocrDebugPrint(
        'CANLI OCR AKIŞI BAŞLADI: '
        '${Platform.isAndroid ? "Android CameraX NV21" : "iOS BGRA8888"} '
        '/ aralık=${liveFrameInterval.inMilliseconds}ms',
      );
    } catch (e, stackTrace) {
      debugPrint('CANLI OCR BAŞLATILAMADI: $e');
      debugPrint('$stackTrace');

      await activatePhotoOcrFallback('canlı kamera akışı başlatılamadı');
    }
  }

  Future<void> activatePhotoOcrFallback(String reason) async {
    if (isUsingPhotoOcrFallback || isCameraPageDisposing) {
      return;
    }

    isUsingPhotoOcrFallback = true;

    final controller = cameraController;

    try {
      if (controller != null && controller.value.isStreamingImages) {
        await controller.stopImageStream();
      }
    } catch (e) {
      debugPrint('OCR YEDEK MOD STREAM DURDURMA NOTU: $e');
    }

    ocrTimer?.cancel();

    // Yalnızca canlı NV21 akışı gerçekten çalışmazsa devreye girer.
    // Bu yol daha yavaştır ama uygulamanın tamamen işlevsiz kalmasını önler.
    ocrTimer = Timer.periodic(const Duration(milliseconds: 700), (_) {
      if (isTranslationRunning) {
        scanCurrentFrame();
      }
    });

    debugPrint(
      'OCR YEDEK MODU AKTİF: '
      'takePicture / neden=$reason',
    );

    unawaited(scanCurrentFrame());
  }

  void noteAndroidVisibleSubtitleEmptyFrame() {
    if (!Platform.isAndroid) {
      return;
    }

    androidVisibleSubtitleEmptyFrames++;

    final lastSeen = androidVisibleSubtitleLastSeenAt;

    if (lastSeen == null) {
      return;
    }

    final oldEnough =
        DateTime.now().difference(lastSeen) >=
        androidVisibleSubtitleReleaseDelay;

    if (androidVisibleSubtitleEmptyFrames >=
            androidVisibleSubtitleEmptyFramesToRelease &&
        oldEnough) {
      debugPrint(
        'ANDROID ALTYAZI KİLİDİ AÇILDI: '
        'altyazı ekrandan kayboldu.',
      );

      androidVisibleSubtitleFingerprint = null;

      androidVisibleSubtitleLastSeenAt = null;

      androidVisibleSubtitleEmptyFrames = 0;
    }
  }

  bool shouldQueueAndroidVisibleSubtitle(String sourceText) {
    if (!Platform.isAndroid) {
      return true;
    }

    final incoming = normalizeSubtitleForFuzzyDuplicate(sourceText);

    if (incoming.isEmpty) {
      return false;
    }

    final previous = androidVisibleSubtitleFingerprint;

    androidVisibleSubtitleEmptyFrames = 0;

    final now = DateTime.now();

    if (previous == null || previous.isEmpty) {
      androidVisibleSubtitleFingerprint = incoming;

      androidVisibleSubtitleLastSeenAt = now;

      debugPrint(
        'ANDROID ALTYAZI KİLİDİ: '
        'yeni altyazı kabul edildi.',
      );

      return true;
    }

    final maxLength = incoming.length > previous.length
        ? incoming.length
        : previous.length;

    final similarity = fuzzySubtitleSimilarity(previous, incoming);

    // Kısa cümlelerde yanlış pozitif riskini azaltmak için exact eşleşme;
    // normal altyazılarda OCR'ın 1-2 harflik oynamalarını fuzzy olarak
    // aynı ekrandaki cümle sayıyoruz.
    final sameVisibleSubtitle =
        incoming == previous || (maxLength >= 10 && similarity >= 0.84);

    if (sameVisibleSubtitle) {
      androidVisibleSubtitleLastSeenAt = now;

      ocrDebugPrint(
        'ANDROID AYNI EKRAN ALTYAZISI ATLADI '
        '(benzerlik=${(similarity * 100).toStringAsFixed(0)}%): '
        '$sourceText',
      );

      return false;
    }

    // Farklı bir cümle geldi: eski kilidi beklemeden yeni cümleyi kabul et.
    androidVisibleSubtitleFingerprint = incoming;

    androidVisibleSubtitleLastSeenAt = now;

    ocrDebugPrint(
      'ANDROID ALTYAZI KİLİDİ: '
      'yeni/farklı altyazıya geçildi '
      '(benzerlik=${(similarity * 100).toStringAsFixed(0)}%).',
    );

    return true;
  }

  void queueTranslation(String sourceText) {
    final cleaned = sourceText.trim();

    if (cleaned.isEmpty || isCameraPageDisposing) {
      return;
    }

    pendingTranslationSource = cleaned;

    if (translationDrainRunning) {
      ocrDebugPrint('ÇEVİRİ KUYRUĞU: yeni altyazı beklemeye alındı.');
      return;
    }

    unawaited(drainTranslationQueue());
  }

  Future<void> drainTranslationQueue() async {
    if (translationDrainRunning) {
      return;
    }

    translationDrainRunning = true;

    try {
      while (!isCameraPageDisposing) {
        final next = pendingTranslationSource;

        if (next == null || next.trim().isEmpty) {
          break;
        }

        pendingTranslationSource = null;

        await translateRecognizedText(next);
      }
    } finally {
      translationDrainRunning = false;

      // Tam finally anında yeni bir altyazı gelmiş olabilir.
      if (!isCameraPageDisposing && pendingTranslationSource != null) {
        unawaited(drainTranslationQueue());
      }
    }
  }

  InputImageRotation? liveInputImageRotation() {
    final camera = activeCameraDescription;

    final controller = cameraController;

    if (camera == null || controller == null) {
      return null;
    }

    final sensorOrientation = camera.sensorOrientation;

    if (Platform.isIOS) {
      return InputImageRotationValue.fromRawValue(sensorOrientation);
    }

    final deviceRotation =
        _deviceOrientations[controller.value.deviceOrientation];

    if (deviceRotation == null) {
      return null;
    }

    int rotationCompensation;

    if (camera.lensDirection == CameraLensDirection.front) {
      rotationCompensation = (sensorOrientation + deviceRotation) % 360;
    } else {
      rotationCompensation = (sensorOrientation - deviceRotation + 360) % 360;
    }

    return InputImageRotationValue.fromRawValue(rotationCompensation);
  }

  Uint8List convertYuv420ToNv21(CameraImage image) {
    final width = image.width;
    final height = image.height;

    final ySize = width * height;

    final nv21 = Uint8List(ySize + (ySize ~/ 2));

    final yPlane = image.planes[0];

    final yPixelStride = yPlane.bytesPerPixel ?? 1;

    var outputIndex = 0;

    for (var row = 0; row < height; row++) {
      final rowOffset = row * yPlane.bytesPerRow;

      for (var col = 0; col < width; col++) {
        final sourceIndex = rowOffset + col * yPixelStride;

        if (sourceIndex < yPlane.bytes.length) {
          nv21[outputIndex++] = yPlane.bytes[sourceIndex];
        } else {
          nv21[outputIndex++] = 0;
        }
      }
    }

    if (image.planes.length < 3) {
      return nv21;
    }

    final uPlane = image.planes[1];

    final vPlane = image.planes[2];

    final uPixelStride = uPlane.bytesPerPixel ?? 1;

    final vPixelStride = vPlane.bytesPerPixel ?? 1;

    for (var row = 0; row < height ~/ 2; row++) {
      final uRowOffset = row * uPlane.bytesPerRow;

      final vRowOffset = row * vPlane.bytesPerRow;

      for (var col = 0; col < width ~/ 2; col++) {
        final uIndex = uRowOffset + col * uPixelStride;

        final vIndex = vRowOffset + col * vPixelStride;

        final vValue = vIndex < vPlane.bytes.length
            ? vPlane.bytes[vIndex]
            : 128;

        final uValue = uIndex < uPlane.bytes.length
            ? uPlane.bytes[uIndex]
            : 128;

        if (outputIndex < nv21.length) {
          nv21[outputIndex++] = vValue;
        }

        if (outputIndex < nv21.length) {
          nv21[outputIndex++] = uValue;
        }
      }
    }

    return nv21;
  }

  InputImage? inputImageFromLiveFrame(CameraImage image) {
    final rotation = liveInputImageRotation();

    if (rotation == null) {
      debugPrint(
        'CANLI KARE ATLADI: '
        'kamera rotasyonu çözülemedi.',
      );
      return null;
    }

    if (!hasLoggedLiveFrameFormat) {
      hasLoggedLiveFrameFormat = true;

      debugPrint(
        'CANLI KARE FORMAT: '
        'platform=${Platform.operatingSystem} | '
        'group=${image.format.group} | '
        'raw=${image.format.raw} | '
        'planes=${image.planes.length} | '
        'size=${image.width}x${image.height} | '
        'bytes=${image.planes.isEmpty ? 0 : image.planes.first.bytes.length}',
      );
    }

    if (Platform.isAndroid) {
      // camera_android_camerax NV21 istendiğinde CameraX bazı sürümlerde
      // image.format.group değerini yuv420 olarak raporlayabilir; ancak
      // plugin tek plane içindeki veriyi gerçek NV21 olarak döndürür.
      //
      // google_mlkit_commons Android tarafında fromBytes için NV21 ister.
      // Bu nedenle format enum'una değil, tek-plane NV21 sözleşmesine
      // güveniyoruz.
      if (image.planes.length != 1) {
        debugPrint(
          'ANDROID CANLI KARE UYUMSUZ: '
          '${image.planes.length} plane geldi; NV21 tek plane bekleniyordu.',
        );
        return null;
      }

      final plane = image.planes.first;

      final minimumNv21Bytes = image.width * image.height * 3 ~/ 2;

      if (plane.bytes.length < minimumNv21Bytes) {
        debugPrint(
          'ANDROID CANLI KARE UYUMSUZ: '
          'NV21 byte sayısı yetersiz '
          '(${plane.bytes.length} < $minimumNv21Bytes).',
        );
        return null;
      }

      return InputImage.fromBytes(
        bytes: plane.bytes,
        metadata: InputImageMetadata(
          size: Size(image.width.toDouble(), image.height.toDouble()),
          rotation: rotation,
          format: InputImageFormat.nv21,
          // Android native dönüştürücü bytesPerRow kullanmıyor;
          // yine de tutarlı metadata için gerçek satır bilgisini ver.
          bytesPerRow: plane.bytesPerRow,
        ),
      );
    }

    if (Platform.isIOS && image.planes.length == 1) {
      final plane = image.planes.first;

      return InputImage.fromBytes(
        bytes: plane.bytes,
        metadata: InputImageMetadata(
          size: Size(image.width.toDouble(), image.height.toDouble()),
          rotation: rotation,
          format: InputImageFormat.bgra8888,
          bytesPerRow: plane.bytesPerRow,
        ),
      );
    }

    return null;
  }

  bool rotationSwapsDimensions(InputImageRotation rotation) {
    return rotation == InputImageRotation.rotation90deg ||
        rotation == InputImageRotation.rotation270deg;
  }

  String extractSubtitleRegionText(
    RecognizedText recognized,
    CameraImage image,
    InputImageRotation rotation,
  ) {
    final swap = Platform.isIOS ? false : rotationSwapsDimensions(rotation);

    final logicalWidth = (swap ? image.height : image.width).toDouble();

    final logicalHeight = (swap ? image.width : image.height).toDouble();

    final scanRect = Rect.fromLTRB(
      logicalWidth * scanLeftFactor,
      logicalHeight * scanTopFactor,
      logicalWidth * scanRightFactor,
      logicalHeight * scanBottomFactor,
    );

    final selectedLines = <MapEntry<Rect, String>>[];

    for (final block in recognized.blocks) {
      for (final line in block.lines) {
        final box = line.boundingBox;

        if (box.width <= 0 || box.height <= 0) {
          continue;
        }

        final center = box.center;

        final centerInside =
            center.dx >= scanRect.left &&
            center.dx <= scanRect.right &&
            center.dy >= scanRect.top &&
            center.dy <= scanRect.bottom;

        final intersection = box.intersect(scanRect);

        final overlapArea = intersection.width > 0 && intersection.height > 0
            ? intersection.width * intersection.height
            : 0.0;

        final lineArea = box.width * box.height;

        final overlapRatio = lineArea <= 0 ? 0.0 : overlapArea / lineArea;

        // Çerçevenin dışındaki yazı artık yalnızca merkezi içeri
        // düştü diye kabul edilmez. Satır kutusunun büyük bölümü gerçekten
        // tarama alanının içinde olmalı. Bu özellikle ekran kenarındaki UI,
        // görev metni ve menü yazılarının altyazıya karışmasını engeller.
        final belongsToScanRegion = centerInside && overlapRatio >= 0.75;

        if (!belongsToScanRegion) {
          continue;
        }

        final value = line.text.trim();

        if (value.isNotEmpty) {
          selectedLines.add(MapEntry(box, value));
        }
      }
    }

    if (selectedLines.isEmpty) {
      return '';
    }

    selectedLines.sort((a, b) {
      final verticalDifference = (a.key.top - b.key.top).abs();

      if (verticalDifference <= 14) {
        return a.key.left.compareTo(b.key.left);
      }

      return a.key.top.compareTo(b.key.top);
    });

    // Canlı OCR tam kareyi işlediği için scan alanında masaüstü
    // veya başka uygulama yazıları da görülebilir. "NAME: dialogue"
    // satırını çapa kabul edip yalnızca gerçek altyazı bloğunu seç.
    final speakerPattern = RegExp(
      r'^([A-Za-z0-9][A-Za-z0-9 _\-]{1,30})\s*[:;|：]\s*(.*)$',
    );

    final knownSpeakers = <String>{
      ...GameVoiceStore.assignmentsForGame(
        widget.game.id,
      ).keys.map(GameVoiceStore.normalizeSpeaker),
      ...GameAiVoiceStore.speakersForGame(
        widget.game.id,
      ).map(GameAiVoiceStore.normalizeSpeaker),
    };

    String bestKnownSpeakerForOcr(String rawSpeaker) {
      final normalized = GameVoiceStore.normalizeSpeaker(rawSpeaker);

      if (knownSpeakers.contains(normalized)) {
        return normalized;
      }

      if (knownSpeakers.isEmpty) {
        return normalized;
      }

      final scored = knownSpeakers.map((candidate) {
        return MapEntry(candidate, levenshteinDistance(normalized, candidate));
      }).toList()..sort((a, b) => a.value.compareTo(b.value));

      if (scored.isEmpty) {
        return normalized;
      }

      final best = scored.first;

      final secondDistance = scored.length >= 2 ? scored[1].value : 999;

      final lengthDifference = (normalized.length - best.key.length).abs();

      final safeMatch =
          best.value <= 1 &&
          lengthDifference <= 1 &&
          secondDistance > best.value;

      if (!safeMatch) {
        return normalized;
      }

      debugPrint(
        'KONUŞMACI ÇAPA OCR DÜZELTİLDİ: '
        '$normalized -> ${best.key}',
      );

      return best.key;
    }

    int? bestSpeakerIndex;
    double bestSpeakerScore = -999999;

    for (var index = 0; index < selectedLines.length; index++) {
      final entry = selectedLines[index];

      final match = speakerPattern.firstMatch(entry.value);

      if (match == null) {
        continue;
      }

      final rawSpeaker = match.group(1)?.trim() ?? '';

      final dialogue = match.group(2)?.trim() ?? '';

      if (rawSpeaker.isEmpty) {
        continue;
      }

      final normalizedSpeaker = bestKnownSpeakerForOcr(rawSpeaker);

      var score = 0.0;

      if (knownSpeakers.contains(normalizedSpeaker)) {
        score += 1000;
      }

      score += (entry.key.center.dy / logicalHeight) * 100;

      final wordCount = RegExp(r"[A-Za-z']+").allMatches(dialogue).length;

      if (wordCount >= 2) {
        score += 40;
      }

      if (dialogue.isNotEmpty) {
        score += 20;
      }

      if (score > bestSpeakerScore) {
        bestSpeakerScore = score;
        bestSpeakerIndex = index;
      }
    }

    if (bestSpeakerIndex != null) {
      final anchor = selectedLines[bestSpeakerIndex];

      final anchorMatch = speakerPattern.firstMatch(anchor.value);

      final rawAnchorSpeaker = anchorMatch?.group(1)?.trim() ?? '';

      final correctedAnchorSpeaker = bestKnownSpeakerForOcr(rawAnchorSpeaker);

      final firstDialogue = anchorMatch?.group(2)?.trim() ?? '';

      final normalizedAnchorLine = firstDialogue.isEmpty
          ? '${correctedAnchorSpeaker}:'
          : '${correctedAnchorSpeaker}: '
                '$firstDialogue';

      final subtitleLines = <String>[normalizedAnchorLine];

      bool endsLikeSentence(String value) {
        final cleaned = value.trim();

        return RegExp(r'''[.!?]["')\]]*$''').hasMatch(cleaned);
      }

      if (!endsLikeSentence(firstDialogue)) {
        var previousBox = anchor.key;

        final anchorHeight = anchor.key.height.clamp(12.0, 80.0);

        for (
          var index = bestSpeakerIndex + 1;
          index < selectedLines.length;
          index++
        ) {
          final candidate = selectedLines[index];

          final candidateText = candidate.value.trim();

          if (candidateText.isEmpty) {
            continue;
          }

          if (speakerPattern.hasMatch(candidateText)) {
            break;
          }

          final verticalGap = candidate.key.top - previousBox.bottom;

          final maxVerticalGap = anchorHeight * 1.65;

          if (verticalGap > maxVerticalGap) {
            break;
          }

          final horizontalOverlap =
              (candidate.key.right > anchor.key.left - 80 &&
              candidate.key.left < anchor.key.right + 80);

          if (!horizontalOverlap) {
            break;
          }

          final candidateWordCount = RegExp(
            r"[A-Za-z']+",
          ).allMatches(candidateText).length;

          if (firstDialogue.isNotEmpty && candidateWordCount < 2) {
            break;
          }

          subtitleLines.add(candidateText);

          previousBox = candidate.key;

          if (endsLikeSentence(candidateText)) {
            break;
          }

          if (subtitleLines.length >= 3) {
            break;
          }
        }
      }

      final result = subtitleLines.join('\n').trim();

      debugPrint(
        'ALTYAZI ÇAPASI BULUNDU: '
        '$result',
      );

      return result;
    }

    // Konuşmacı etiketi tamamen kaçarsa eski davranışı tamamen
    // kaybetmemek için yalnızca çok sözcüklü birkaç satırı bırak.
    final fallbackLines = selectedLines
        .where((entry) {
          final value = entry.value.trim();

          if (RegExp(r'[:;|：]').hasMatch(value)) {
            return false;
          }

          final words = RegExp(r"[A-Za-z']+").allMatches(value).length;

          return words >= 2;
        })
        .take(3)
        .map((entry) => entry.value)
        .toList();

    if (fallbackLines.isNotEmpty) {
      return fallbackLines.join('\n').trim();
    }

    return '';
  }

  String normalizeOcrForStabilityCompare(String value) {
    return value
        .toLowerCase()
        .replaceAll('0', 'o')
        .replaceAll(RegExp(r'[^a-z0-9]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  double ocrCandidateSimilarity(String first, String second) {
    final a = normalizeOcrForStabilityCompare(first);

    final b = normalizeOcrForStabilityCompare(second);

    if (a.isEmpty || b.isEmpty) {
      return 0.0;
    }

    if (a == b) {
      return 1.0;
    }

    final distance = levenshteinDistance(a, b);

    final maxLength = a.length > b.length ? a.length : b.length;

    if (maxLength == 0) {
      return 1.0;
    }

    return (1.0 - distance / maxLength).clamp(0.0, 1.0).toDouble();
  }

  bool tokenLooksSuspiciousForOcr(String token) {
    final cleaned = token.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

    if (cleaned.isEmpty) {
      return false;
    }

    // a / I gibi gerçek tek-harf kelimeleri normaldir.
    if (cleaned.length == 1) {
      return cleaned != 'a' && cleaned != 'i';
    }

    // Harf ve rakamın aynı kelimede karışması OCR için güçlü
    // bir şüphe işaretidir. (Örn. J0HN, 3OHN gibi speaker kısmı
    // daha önce fuzzy düzeltmeden geçer.)
    final hasLetter = RegExp(r'[a-z]').hasMatch(cleaned);

    final hasDigit = RegExp(r'[0-9]').hasMatch(cleaned);

    if (hasLetter && hasDigit) {
      return true;
    }

    // 4+ harfli ve hiç sesli harf içermeyen kelimeler çoğu oyun
    // altyazısında bltch / ARWR gibi OCR bozulmalarına işaret eder.
    if (cleaned.length >= 4 && !RegExp(r'[aeiouy]').hasMatch(cleaned)) {
      return true;
    }

    // Çok uzun tekrarlı karakter dizileri de OCR artefaktı olabilir.
    if (RegExp(r'(.)\1\1').hasMatch(cleaned)) {
      return true;
    }

    return false;
  }

  double scoreOcrCandidate(String text) {
    final trimmed = text.trim();

    if (trimmed.isEmpty) {
      return 0.0;
    }

    var score = 55.0;

    final speakerPattern = RegExp(
      r'^([A-Za-z0-9][A-Za-z0-9 _\-]{1,30})\s*[:;|：]\s*(.*)$',
    );

    final match = speakerPattern.firstMatch(trimmed);

    var dialogueText = trimmed;

    if (match != null) {
      final rawSpeaker = match.group(1)?.trim() ?? '';

      dialogueText = match.group(2)?.trim() ?? '';

      final normalizedSpeaker = GameVoiceStore.normalizeSpeaker(rawSpeaker);

      final knownSpeakers = GameVoiceStore.assignmentsForGame(
        widget.game.id,
      ).keys.map(GameVoiceStore.normalizeSpeaker).toSet();

      if (knownSpeakers.contains(normalizedSpeaker)) {
        score += 12.0;
      } else if (isGenericSpeakerLabel(normalizedSpeaker)) {
        score += 8.0;
      } else if (RegExp(r'^[A-Z][A-Z _\-]{1,30}$').hasMatch(rawSpeaker)) {
        score += 4.0;
      }

      if (RegExp(r'\d').hasMatch(rawSpeaker)) {
        score -= 8.0;
      }

      final speakerLetters = rawSpeaker.toLowerCase().replaceAll(
        RegExp(r'[^a-z]'),
        '',
      );

      if (speakerLetters.length >= 4 &&
          !RegExp(r'[aeiouy]').hasMatch(speakerLetters)) {
        score -= 10.0;
      }
    }

    final compact = dialogueText.replaceAll(RegExp(r'\s+'), '');

    if (compact.isEmpty) {
      return 0.0;
    }

    final letterCount = RegExp(r'[A-Za-z]').allMatches(compact).length;

    final alphaRatio = letterCount / compact.length;

    if (alphaRatio >= 0.82) {
      score += 15.0;
    } else if (alphaRatio >= 0.68) {
      score += 8.0;
    } else {
      score -= 12.0;
    }

    final words = RegExp(r"[A-Za-z0-9']+")
        .allMatches(dialogueText)
        .map((match) => match.group(0) ?? '')
        .where((word) => word.isNotEmpty)
        .toList();

    if (words.length >= 4) {
      score += 15.0;
    } else if (words.length >= 2) {
      score += 8.0;
    }

    final endsWithPunctuation = RegExp(
      r'''[.!?]["')\]]*$''',
    ).hasMatch(dialogueText.trim());

    if (endsWithPunctuation) {
      score += 8.0;

      // "Go!", "Run!", "Get down!" gibi kısa ama tamamlanmış
      // altyazılar stabilizasyon yüzünden gereksiz beklemesin.
      if (words.length <= 2) {
        score += 15.0;
      }
    }

    var suspiciousTokens = 0;

    for (final word in words) {
      if (tokenLooksSuspiciousForOcr(word)) {
        suspiciousTokens++;
      }
    }

    score -= suspiciousTokens * 10.0;

    // Çok fazla şüpheli token varsa tek-kare OCR'a güvenmiyoruz.
    if (suspiciousTokens >= 2) {
      score -= 6.0;
    }

    return score.clamp(0.0, 100.0).toDouble();
  }

  void clearPendingOcrCandidate() {
    pendingOcrCandidate = null;
    pendingOcrCandidateScore = 0.0;
    pendingOcrCandidateAt = null;
  }

  String? stabilizeLiveOcrText(String rawText) {
    final now = DateTime.now();

    final text = rawText.trim();

    final pending = pendingOcrCandidate;

    final pendingAt = pendingOcrCandidateAt;

    // Metin bir anda kaybolduysa ve elimizde yalnızca tek şüpheli
    // kare kaldıysa onu sonsuza kadar çöpe atmıyoruz. Maksimum
    // bekleme dolduğunda son çare olarak çeviriye gönderiyoruz.
    if (text.isEmpty) {
      if (pending != null &&
          pendingAt != null &&
          now.difference(pendingAt) >= maxOcrStabilizationWait) {
        final fallback = pending;

        final fallbackScore = pendingOcrCandidateScore;

        clearPendingOcrCandidate();

        ocrDebugPrint(
          'OCR STABİLİZASYON: '
          'TEK KARE ZAMAN AŞIMI -> '
          'çeviriye gönderiliyor '
          '(skor=${fallbackScore.toStringAsFixed(1)})',
        );

        return fallback;
      }

      return null;
    }

    final score = scoreOcrCandidate(text);

    // Eğer yeni kare temizse gecikme eklemiyoruz.
    if (score >= immediateOcrConfidenceScore) {
      if (pending != null) {
        final similarity = ocrCandidateSimilarity(pending, text);

        ocrDebugPrint(
          'OCR STABİLİZASYON: '
          'TEMİZ KARE GELDİ '
          '(skor=${score.toStringAsFixed(1)}, '
          'öncekiBenzerlik=${(similarity * 100).toStringAsFixed(0)}%)',
        );
      } else {
        ocrDebugPrint(
          'OCR STABİLİZASYON: '
          'YÜKSEK GÜVEN -> HEMEN '
          '(skor=${score.toStringAsFixed(1)})',
        );
      }

      clearPendingOcrCandidate();

      return text;
    }

    if (pending == null || pendingAt == null) {
      pendingOcrCandidate = text;

      pendingOcrCandidateScore = score;

      pendingOcrCandidateAt = now;

      ocrDebugPrint(
        'OCR STABİLİZASYON: '
        'ŞÜPHELİ KARE BEKLETİLDİ '
        '(skor=${score.toStringAsFixed(1)})',
      );

      return null;
    }

    final similarity = ocrCandidateSimilarity(pending, text);

    final pendingAge = now.difference(pendingAt);

    if (similarity >= ocrCandidateSimilarityThreshold) {
      final selected = score >= pendingOcrCandidateScore ? text : pending;

      final selectedScore = score >= pendingOcrCandidateScore
          ? score
          : pendingOcrCandidateScore;

      clearPendingOcrCandidate();

      ocrDebugPrint(
        'OCR STABİLİZASYON: '
        'İKİ KAREYLE DOĞRULANDI '
        '(benzerlik=${(similarity * 100).toStringAsFixed(0)}%, '
        'seçilenSkor=${selectedScore.toStringAsFixed(1)})',
      );

      return selected;
    }

    // Önceki şüpheli kare yeterince uzun beklediyse onu kaybetme.
    // Yeni farklı metni de bir sonraki kareyle doğrulamak için
    // pending olarak sakla.
    if (pendingAge >= maxOcrStabilizationWait) {
      final fallback = pending;

      final fallbackScore = pendingOcrCandidateScore;

      pendingOcrCandidate = text;

      pendingOcrCandidateScore = score;

      pendingOcrCandidateAt = now;

      ocrDebugPrint(
        'OCR STABİLİZASYON: '
        'ÖNCEKİ KARE MAKS BEKLEMEYİ DOLDURDU '
        '(skor=${fallbackScore.toStringAsFixed(1)}), '
        'yeni aday beklemeye alındı.',
      );

      return fallback;
    }

    // Aynı subtitle içinde kamera netleşirken daha iyi bir varyant
    // geldiyse bekleyen adayı yükselt.
    if (score > pendingOcrCandidateScore) {
      pendingOcrCandidate = text;

      pendingOcrCandidateScore = score;

      // İlk bekleme başlangıcını koruyoruz; gecikme uzamasın.
      ocrDebugPrint(
        'OCR STABİLİZASYON: '
        'DAHA İYİ ŞÜPHELİ ADAY BULUNDU '
        '(skor=${score.toStringAsFixed(1)}, '
        'benzerlik=${(similarity * 100).toStringAsFixed(0)}%)',
      );
    } else {
      ocrDebugPrint(
        'OCR STABİLİZASYON: '
        'ŞÜPHELİ ADAY DOĞRULANMAYI BEKLİYOR '
        '(skor=${score.toStringAsFixed(1)}, '
        'benzerlik=${(similarity * 100).toStringAsFixed(0)}%)',
      );
    }

    return null;
  }

  int nativeRotationDegrees(InputImageRotation rotation) {
    switch (rotation) {
      case InputImageRotation.rotation0deg:
        return 0;
      case InputImageRotation.rotation90deg:
        return 90;
      case InputImageRotation.rotation180deg:
        return 180;
      case InputImageRotation.rotation270deg:
        return 270;
    }
  }

  Future<RecognizedText> recognizeAndroidFrameNatively(
    CameraImage image,
    InputImageRotation rotation, {
    bool forceFullResolution = false,
  }) async {
    Uint8List nv21Bytes;

    final sourceWidth = image.width;
    final sourceHeight = image.height;

    var processedWidth = sourceWidth;
    var processedHeight = sourceHeight;

    if (image.planes.length == 1) {
      nv21Bytes = image.planes.first.bytes;
    } else {
      // Bazı Android cihaz/CameraX kombinasyonları YUV420 döndürürse
      // mevcut güvenli dönüştürücüyü kullan.
      nv21Bytes = convertYuv420ToNv21(image);
    }

    final minimumNv21Bytes = sourceWidth * sourceHeight * 3 ~/ 2;

    final canDownscale =
        androidHalfResolutionOcr &&
        !forceFullResolution &&
        sourceWidth >= 640 &&
        sourceHeight >= 360 &&
        sourceWidth.isEven &&
        sourceHeight.isEven &&
        nv21Bytes.length >= minimumNv21Bytes &&
        (image.planes.length != 1 ||
            image.planes.first.bytesPerRow == sourceWidth);

    if (canDownscale) {
      nv21Bytes = downscaleNv21ByTwo(
        nv21Bytes,
        sourceWidth,
        sourceHeight,
      );

      processedWidth = sourceWidth ~/ 2;
      processedHeight = sourceHeight ~/ 2;
    }

    final response = await _nativeAndroidOcrChannel
        .invokeMapMethod<String, dynamic>('recognizeNv21', <String, dynamic>{
          'bytes': nv21Bytes,
          'width': processedWidth,
          'height': processedHeight,
          'rotation': nativeRotationDegrees(rotation),
        });

    if (response == null) {
      throw PlatformException(
        code: 'NativeOcrEmptyResponse',
        message: 'Android native OCR boş yanıt döndürdü.',
      );
    }

    if (response['busy'] == true) {
      return RecognizedText(text: '', blocks: const <TextBlock>[]);
    }

    final fullText = (response['text'] ?? '').toString();

    final rawLines = response['lines'];

    final lines = <TextLine>[];

    if (rawLines is List) {
      for (final rawLine in rawLines) {
        if (rawLine is! Map) {
          continue;
        }

        final map = Map<dynamic, dynamic>.from(rawLine);

        final value = (map['text'] ?? '').toString().trim();

        if (value.isEmpty) {
          continue;
        }

        final scaleX = sourceWidth / processedWidth;
        final scaleY = sourceHeight / processedHeight;

        final rawLeft = (map['left'] as num?)?.toDouble() ?? 0.0;
        final rawTop = (map['top'] as num?)?.toDouble() ?? 0.0;
        final rawRight =
            (map['right'] as num?)?.toDouble() ?? rawLeft;
        final rawBottom =
            (map['bottom'] as num?)?.toDouble() ?? rawTop;

        // Native OCR yarım çözünürlükte çalışmış olsa bile geri kalan
        // tarama alanı matematiği orijinal kamera koordinatlarını kullanır.
        final left = rawLeft * scaleX;
        final top = rawTop * scaleY;
        final right = rawRight * scaleX;
        final bottom = rawBottom * scaleY;

        final box = Rect.fromLTRB(left, top, right, bottom);

        lines.add(
          TextLine(
            text: value,
            elements: const <TextElement>[],
            boundingBox: box,
            recognizedLanguages: const <String>[],
            cornerPoints: <math.Point<int>>[
              math.Point<int>(left.round(), top.round()),
              math.Point<int>(right.round(), top.round()),
              math.Point<int>(right.round(), bottom.round()),
              math.Point<int>(left.round(), bottom.round()),
            ],
            confidence: null,
            angle: null,
          ),
        );
      }
    }

    if (lines.isEmpty) {
      return RecognizedText(text: fullText, blocks: const <TextBlock>[]);
    }

    var blockLeft = lines.first.boundingBox.left;

    var blockTop = lines.first.boundingBox.top;

    var blockRight = lines.first.boundingBox.right;

    var blockBottom = lines.first.boundingBox.bottom;

    for (final line in lines.skip(1)) {
      blockLeft = blockLeft < line.boundingBox.left
          ? blockLeft
          : line.boundingBox.left;

      blockTop = blockTop < line.boundingBox.top
          ? blockTop
          : line.boundingBox.top;

      blockRight = blockRight > line.boundingBox.right
          ? blockRight
          : line.boundingBox.right;

      blockBottom = blockBottom > line.boundingBox.bottom
          ? blockBottom
          : line.boundingBox.bottom;
    }

    final blockBox = Rect.fromLTRB(
      blockLeft,
      blockTop,
      blockRight,
      blockBottom,
    );

    final block = TextBlock(
      text: fullText,
      lines: lines,
      boundingBox: blockBox,
      recognizedLanguages: const <String>[],
      cornerPoints: <math.Point<int>>[
        math.Point<int>(blockLeft.round(), blockTop.round()),
        math.Point<int>(blockRight.round(), blockTop.round()),
        math.Point<int>(blockRight.round(), blockBottom.round()),
        math.Point<int>(blockLeft.round(), blockBottom.round()),
      ],
    );

    return RecognizedText(text: fullText, blocks: <TextBlock>[block]);
  }

  Future<void> processLiveCameraImage(CameraImage image) async {
    if (isCameraPageDisposing || !mounted || isProcessingImage) {
      return;
    }

    isProcessingImage = true;

    final runId = ++performanceRunId;

    final totalWatch = Stopwatch()..start();

    activePerformanceRunId = runId;

    activePerformanceTotalWatch = totalWatch;

    logPerformance('CANLI TARAMA BAŞLADI');

    try {
      final inputWatch = Stopwatch()..start();

      final rotation = liveInputImageRotation();

      if (rotation == null) {
        inputWatch.stop();

        logPerformance(
          'CANLI KARE HAZIRLAMA',
          durationMs: inputWatch.elapsedMilliseconds,
          extra: 'rotasyon çözülemedi',
        );

        return;
      }

      inputWatch.stop();

      logPerformance(
        'CANLI KARE HAZIRLAMA',
        durationMs: inputWatch.elapsedMilliseconds,
        extra:
            '${image.width}x'
            '${image.height} / '
            '${image.planes.length} plane / '
            '${Platform.isAndroid ? "NATIVE-ANDROID" : "FLUTTER-MLKIT"}',
      );

      final ocrWatch = Stopwatch()..start();

      late final RecognizedText result;

      final usedFullResolutionRescue =
          Platform.isAndroid && shouldUseAndroidFullResolutionRescue;

      if (Platform.isAndroid) {
        // Android release'de google_mlkit_commons InputImageConverter
        // tamamen bypass edilir. Yavaş cihazlarda adaptive mode NV21'i
        // 1/2 lineer çözünürlükte native ML Kit'e yollar; aralıklı tam
        // çözünürlük rescue kareleri küçük yazıları kaçırmayı önler.
        result = await recognizeAndroidFrameNatively(
          image,
          rotation,
          forceFullResolution: usedFullResolutionRescue,
        );
      } else {
        final inputImage = inputImageFromLiveFrame(image);

        if (inputImage == null) {
          throw PlatformException(
            code: 'InputImageBuildError',
            message: 'iOS canlı OCR karesi hazırlanamadı.',
          );
        }

        result = await textRecognizer.processImage(inputImage);
      }

      liveFrameConversionFailureCount = 0;

      ocrWatch.stop();

      if (isCameraPageDisposing || !mounted) {
        return;
      }

      logPerformance(
        'OCR',
        durationMs: ocrWatch.elapsedMilliseconds,
        extra: Platform.isAndroid ? 'native Kotlin ML Kit' : 'Flutter ML Kit',
      );

      final regionWatch = Stopwatch()..start();

      final text = extractSubtitleRegionText(result, image, rotation);

      regionWatch.stop();

      updateAndroidAdaptivePerformance(
        ocrMs: ocrWatch.elapsedMilliseconds,
        hasSubtitleRegionText: text.trim().isNotEmpty,
        usedFullResolutionRescue: usedFullResolutionRescue,
      );

      logPerformance(
        'SCAN BÖLGESİ FİLTRE',
        durationMs: regionWatch.elapsedMilliseconds,
        extra: Platform.isAndroid
            ? 'interval=${androidAdaptiveFrameIntervalMs}ms / '
                '${androidHalfResolutionOcr && !usedFullResolutionRescue ? "half-res" : "full-res"}'
            : null,
      );

      ocrDebugPrint(
        'OCR HAM METİN (SCAN BÖLGESİ):\n'
        '$text',
      );

      final stabilizedText = stabilizeLiveOcrText(text);

      if (stabilizedText == null || stabilizedText.trim().isEmpty) {
        if (text.trim().isEmpty) {
          noteAndroidVisibleSubtitleEmptyFrame();
        } else if (Platform.isAndroid) {
          // OCR hâlâ bir şey görüyor ama stabilizasyon bekliyor.
          // Bunu "altyazı kayboldu" saymıyoruz.
          androidVisibleSubtitleEmptyFrames = 0;
        }

        updateRecognizedTextIfChanged(
          text.trim().isEmpty
              ? 'Tarama alanında metin algılanmadı...'
              : 'OCR doğrulanıyor...',
        );

        return;
      }

      ocrDebugPrint(
        'OCR STABİL METİN:\n'
        '$stabilizedText',
      );

      updateRecognizedTextIfChanged(stabilizedText);

      if (shouldQueueAndroidVisibleSubtitle(stabilizedText)) {
        queueTranslation(stabilizedText);
      }
    } catch (e, stackTrace) {
      debugPrint('CANLI OCR HATASI: $e');
      debugPrint('$stackTrace');

      final isInputImageConverterError =
          e is PlatformException &&
          (e.code == 'InputImageConverterError' ||
              e.message?.contains('InputImageConverter') == true);

      if (Platform.isAndroid) {
        // Native bridge hata verirse kullanıcıya gerçek hatayı gösteriyoruz.
        // Eski Flutter InputImageConverter yoluna geri dönmüyoruz.
        liveFrameConversionFailureCount++;

        if (liveFrameConversionFailureCount >= 3) {
          debugPrint(
            'ANDROID NATIVE OCR: '
            '3 ardışık hata oluştu.',
          );
        }
      }

      updateRecognizedTextIfChanged(
        isInputImageConverterError
            ? 'Android OCR dönüştürücü hatası giderilemedi.'
            : 'OCR hatası:\n$e',
      );
    } finally {
      totalWatch.stop();

      logPerformance(
        'CANLI TARAMA BİTTİ',
        durationMs: totalWatch.elapsedMilliseconds,
      );

      isProcessingImage = false;

      if (activePerformanceRunId == runId) {
        activePerformanceRunId = null;

        activePerformanceTotalWatch = null;
      }
    }
  }

  Future<File> cropSubtitleRegion(XFile originalImage) async {
    final originalFile = File(originalImage.path);

    final bytes = await originalFile.readAsBytes();

    img.Image? decoded = img.decodeImage(bytes);

    if (decoded == null) {
      throw Exception('Kamera görüntüsü çözümlenemedi.');
    }

    decoded = img.bakeOrientation(decoded);

    final imageWidth = decoded.width;

    final imageHeight = decoded.height;

    int cropX = (imageWidth * scanLeftFactor).round();

    int cropY = (imageHeight * scanTopFactor).round();

    int cropRight = (imageWidth * scanRightFactor).round();

    int cropBottom = (imageHeight * scanBottomFactor).round();

    cropX = cropX.clamp(0, imageWidth - 1);

    cropY = cropY.clamp(0, imageHeight - 1);

    cropRight = cropRight.clamp(cropX + 1, imageWidth);

    cropBottom = cropBottom.clamp(cropY + 1, imageHeight);

    final cropped = img.copyCrop(
      decoded,
      x: cropX,
      y: cropY,
      width: cropRight - cropX,
      height: cropBottom - cropY,
    );

    final croppedPath = '${originalImage.path}_subtitle.jpg';

    final croppedFile = File(croppedPath);

    await croppedFile.writeAsBytes(
      img.encodeJpg(cropped, quality: 95),
      flush: true,
    );

    return croppedFile;
  }

  bool looksLikeStandaloneSpeaker(String line) {
    final value = line.trim();

    if (value.length < 2 || value.length > 28) {
      return false;
    }

    // Standalone character labels in games are usually short and
    // uppercase: JOHN, ARTHUR MORGAN, SADIE ADLER.
    if (!RegExp(
      r'^[A-Z][A-Z0-9_\-]*(?:\s+[A-Z][A-Z0-9_\-]*){0,2}$',
    ).hasMatch(value)) {
      return false;
    }

    // Prevent obvious all-caps dialogue commands from being treated
    // as character names.
    const blocked = <String>{
      'RUN',
      'GO',
      'STOP',
      'HELP',
      'HURRY',
      'MOVE',
      'WAIT',
      'LOOK OUT',
      'WATCH OUT',
      'GET OUT',
      'COME ON',
      'OH NO',
      'NO',
      'YES',
    };

    return !blocked.contains(value);
  }

  List<DialogueSegment> parseDialogueSegments(String rawText) {
    final lines = rawText
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList();

    final segments = <DialogueSegment>[];

    // OCR ':' karakterini bazen ';', '|', '：' gibi okuyabiliyor.
    final speakerWithSeparatorPattern = RegExp(
      r'^([A-Za-z][A-Za-z0-9 _\-]{1,30})\s*[:;|：]\s*(.*)$',
    );

    DialogueSegment? currentSegment;
    String? pendingStandaloneSpeaker;

    for (var index = 0; index < lines.length; index++) {
      final line = lines[index];

      final match = speakerWithSeparatorPattern.firstMatch(line);

      if (match != null) {
        final speaker = match.group(1)?.trim();

        final dialogue = match.group(2)?.trim() ?? '';

        pendingStandaloneSpeaker = null;

        currentSegment = DialogueSegment(speaker: speaker, text: dialogue);

        if (dialogue.isNotEmpty) {
          segments.add(currentSegment);
        }

        continue;
      }

      // Bazı oyun/font kombinasyonlarında OCR:
      //
      // JOHN
      // We need to move.
      //
      // şeklinde kolon işaretini hiç göremiyor. JOHN satırını
      // konuşmacı olarak tutup bir sonraki satıra bağlıyoruz.
      if (looksLikeStandaloneSpeaker(line)) {
        pendingStandaloneSpeaker = line;

        currentSegment = null;

        debugPrint(
          'AYRI SATIR KONUŞMACI ALGILANDI: '
          '$pendingStandaloneSpeaker',
        );

        continue;
      }

      if (pendingStandaloneSpeaker != null) {
        currentSegment = DialogueSegment(
          speaker: pendingStandaloneSpeaker,
          text: line,
        );

        segments.add(currentSegment);

        pendingStandaloneSpeaker = null;

        continue;
      }

      if (currentSegment != null) {
        currentSegment.text = '${currentSegment.text} $line'.trim();
      } else {
        currentSegment = DialogueSegment(speaker: null, text: line);

        segments.add(currentSegment);
      }
    }

    return segments.where((segment) => segment.text.trim().isNotEmpty).toList();
  }

  int phraseScore(String text, List<String> phrases, int weight) {
    var score = 0;

    for (final phrase in phrases) {
      if (text.contains(phrase)) {
        score += weight;
      }
    }

    return score;
  }

  SpeechEmotion emotionPreset(String type, {required bool strong}) {
    switch (type) {
      case 'angry':
        return SpeechEmotion(
          type: 'angry',
          label: strong ? 'Öfkeli / Sert' : 'Gergin / Sert',
          speechRate: strong ? 0.54 : 0.51,
          pitchMultiplier: strong ? 0.98 : 0.99,
          volume: 1.0,
        );

      case 'fear':
        return SpeechEmotion(
          type: 'fear',
          label: strong ? 'Korku / Panik' : 'Tedirgin',
          speechRate: strong ? 0.56 : 0.53,
          pitchMultiplier: strong ? 1.03 : 1.02,
          volume: 1.0,
        );

      case 'sad':
        return SpeechEmotion(
          type: 'sad',
          label: strong ? 'Üzgün' : 'Hüzünlü',
          speechRate: strong ? 0.42 : 0.44,
          pitchMultiplier: strong ? 0.97 : 0.99,
          volume: strong ? 0.90 : 0.95,
        );

      case 'urgent':
        return SpeechEmotion(
          type: 'urgent',
          label: strong ? 'Acil / Heyecanlı' : 'Aceleci',
          speechRate: strong ? 0.56 : 0.52,
          pitchMultiplier: strong ? 1.01 : 1.0,
          volume: 1.0,
        );

      case 'calm':
        return SpeechEmotion(
          type: 'calm',
          label: strong ? 'Sakin / Yumuşak' : 'Sakin',
          speechRate: strong ? 0.41 : 0.44,
          pitchMultiplier: strong ? 0.98 : 0.99,
          volume: strong ? 0.92 : 0.96,
        );

      case 'whisper':
        return SpeechEmotion(
          type: 'whisper',
          label: 'Fısıltı',
          speechRate: 0.42,
          pitchMultiplier: 0.99,
          volume: 0.76,
        );

      case 'joy':
        return SpeechEmotion(
          type: 'joy',
          label: strong ? 'Sevinçli / Coşkulu' : 'Olumlu',
          speechRate: strong ? 0.54 : 0.51,
          pitchMultiplier: strong ? 1.04 : 1.02,
          volume: 1.0,
        );

      case 'confident':
        return SpeechEmotion(
          type: 'confident',
          label: 'Kararlı',
          speechRate: strong ? 0.52 : 0.50,
          pitchMultiplier: 0.98,
          volume: 1.0,
        );

      default:
        return const SpeechEmotion(
          type: 'neutral',
          label: 'Normal',
          speechRate: 0.48,
          pitchMultiplier: 1.0,
          volume: 1.0,
        );
    }
  }

  EmotionDecision detectSpeechEmotion(
    String sourceText,
    String translatedText,
  ) {
    final source = sourceText.trim().toLowerCase();

    final translated = translatedText.trim().toLowerCase();

    final combined = '$source $translated';

    final scores = <String, int>{
      'angry': 0,
      'fear': 0,
      'sad': 0,
      'urgent': 0,
      'calm': 0,
      'whisper': 0,
      'joy': 0,
      'confident': 0,
    };

    bool explicitCue = false;

    void add(String type, int value) {
      scores[type] = (scores[type] ?? 0) + value;
    }

    // --------------------------------------------------------
    // 1. AÇIK SAHNE / ALTYAZI İŞARETLERİ
    // --------------------------------------------------------
    // Oyun altyazılarında [shouting], (whispers), *crying* gibi
    // işaretler varsa bunlar sıradan kelime tahmininden daha güçlüdür.
    if (RegExp(
      r'[\[\(\*]\s*(shouts?|shouting|yells?|yelling|screams?|screaming|angrily|furious)\s*[\]\)\*]',
      caseSensitive: false,
    ).hasMatch(sourceText)) {
      add('angry', 12);
      explicitCue = true;
    }

    if (RegExp(
      r'[\[\(\*]\s*(afraid|fearful|terrified|panicked|panicking|gasping|frightened)\s*[\]\)\*]',
      caseSensitive: false,
    ).hasMatch(sourceText)) {
      add('fear', 12);
      explicitCue = true;
    }

    if (RegExp(
      r'[\[\(\*]\s*(crying|cries|sobbing|sadly|tearfully)\s*[\]\)\*]',
      caseSensitive: false,
    ).hasMatch(sourceText)) {
      add('sad', 12);
      explicitCue = true;
    }

    if (RegExp(
      r'[\[\(\*]\s*(whispers?|whispering|quietly|softly)\s*[\]\)\*]',
      caseSensitive: false,
    ).hasMatch(sourceText)) {
      add('whisper', 14);
      explicitCue = true;
    }

    if (RegExp(
      r'[\[\(\*]\s*(laughs?|laughing|cheering|happily|excited)\s*[\]\)\*]',
      caseSensitive: false,
    ).hasMatch(sourceText)) {
      add('joy', 11);
      explicitCue = true;
    }

    // --------------------------------------------------------
    // 2. ANLAM TABANLI CÜMLE KALIPLARI
    // --------------------------------------------------------
    add(
      'angry',
      phraseScore(combined, [
        'damn',
        'bastard',
        'idiot',
        'fool',
        'shut up',
        'son of a bitch',
        'fuck',
        'fucking',
        'hate you',
        'kill you',
        'i will kill',
        "i'll kill",
        'you are dead',
        "you're dead",
        'get away from me',
        'leave me alone',
        'get your hands off',
        'lanet',
        'aptal',
        'salak',
        'kapa çeneni',
        'senden nefret',
        'öldüreceğim',
        'geber',
        'defol',
        'çek elini',
      ], 6),
    );

    add(
      'fear',
      phraseScore(combined, [
        'help me',
        'help us',
        'they are coming',
        "they're coming",
        'coming for us',
        'scared',
        'afraid',
        'terrified',
        'frightened',
        'danger',
        'watch out',
        'look out',
        'behind you',
        'hide',
        'escape',
        'oh no',
        'we need to leave',
        'we have to leave',
        'we need to get out',
        'do not leave me',
        "don't leave me",
        'please do not',
        "please don't",
        'bizi bulacak',
        'yardım et',
        'yardım edin',
        'korkuyorum',
        'çok korktum',
        'tehlike',
        'arkanda',
        'saklan',
        'buradan çıkmalıyız',
        'gitmemiz gerek',
        'kaçmamız gerek',
        'beni bırakma',
      ], 6),
    );

    add(
      'sad',
      phraseScore(combined, [
        'i am sorry',
        "i'm sorry",
        'forgive me',
        'goodbye',
        'he is dead',
        'she is dead',
        'they are dead',
        'is dead',
        'died',
        'gone forever',
        'i miss you',
        'we lost',
        'i lost',
        'my fault',
        'regret',
        'all alone',
        'wish i could',
        'i failed',
        'it is over',
        "it's over",
        'üzgünüm',
        'affet beni',
        'hoşça kal',
        'öldü',
        'kaybettik',
        'kaybettim',
        'özlüyorum',
        'benim hatam',
        'pişmanım',
        'yalnızım',
        'başaramadım',
        'bitti artık',
      ], 6),
    );

    add(
      'urgent',
      phraseScore(combined, [
        'hurry',
        'hurry up',
        'quick',
        'quickly',
        'come on',
        "let's go",
        'lets go',
        'move now',
        'right now',
        'faster',
        'go go',
        'get moving',
        'run now',
        'we have to go',
        'we need to go',
        'çabuk',
        'acele et',
        'hadi',
        'hemen',
        'daha hızlı',
        'hareket et',
        'koş',
        'gitmeliyiz',
      ], 5),
    );

    add(
      'calm',
      phraseScore(combined, [
        'calm down',
        'relax',
        'take it easy',
        'easy now',
        'slowly',
        'be quiet',
        'quietly',
        'it is okay',
        "it's okay",
        'everything is fine',
        'do not worry',
        "don't worry",
        'listen to me',
        'wait here',
        'stay calm',
        'sakin ol',
        'rahatla',
        'yavaşça',
        'sessiz ol',
        'sessizce',
        'sorun yok',
        'her şey yolunda',
        'endişelenme',
        'beni dinle',
        'burada bekle',
      ], 6),
    );

    add(
      'joy',
      phraseScore(combined, [
        'we did it',
        'i did it',
        'thank god',
        'great news',
        'good news',
        'good to see you',
        'glad to see you',
        'finally',
        'amazing',
        'wonderful',
        'fantastic',
        'i am happy',
        "i'm happy",
        'başardık',
        'başardım',
        'çok şükür',
        'harika',
        'muhteşem',
        'sonunda',
        'seni gördüğüme sevindim',
        'mutluyum',
      ], 5),
    );

    add(
      'confident',
      phraseScore(combined, [
        'i can do this',
        'we can do this',
        'i got this',
        "i've got this",
        'trust me',
        'follow me',
        'stay behind me',
        'leave it to me',
        'i know what to do',
        'we will make it',
        "we'll make it",
        'bunu yapabilirim',
        'bunu yapabiliriz',
        'bana güven',
        'beni takip et',
        'arkamda kal',
        'bana bırak',
        'ne yapacağımı biliyorum',
        'başaracağız',
      ], 5),
    );

    // --------------------------------------------------------
    // 3. NOKTALAMA + YAZIM ŞİDDETİ
    // --------------------------------------------------------
    final exclamationCount = '!'.allMatches(sourceText).length;

    final questionCount = '?'.allMatches(sourceText).length;

    final letters = RegExp(
      r'[A-Za-z]',
    ).allMatches(sourceText).map((match) => match.group(0)!).toList();

    if (letters.length >= 6) {
      final uppercaseCount = letters
          .where((letter) => letter == letter.toUpperCase())
          .length;

      final uppercaseRatio = uppercaseCount / letters.length;

      // Sadece büyük harf tek başına öfke sayılmaz.
      // Ünlem / tehdit / aciliyet varsa şiddeti artırır.
      if (uppercaseRatio >= 0.78) {
        if (exclamationCount > 0) {
          add('angry', 2);
          add('urgent', 2);
        }

        if ((scores['angry'] ?? 0) > 0) {
          add('angry', 2);
        }

        if ((scores['fear'] ?? 0) > 0) {
          add('fear', 2);
        }
      }
    }

    if (exclamationCount >= 3) {
      add('angry', 2);
      add('urgent', 3);
    } else if (exclamationCount == 2) {
      add('urgent', 2);
      add('angry', 1);
    } else if (exclamationCount == 1) {
      add('urgent', 1);
    }

    if (questionCount >= 2 && exclamationCount >= 1) {
      add('fear', 2);
    }

    if (source.endsWith('...') || translated.endsWith('...')) {
      add('sad', 2);
      add('calm', 1);
    }

    // --------------------------------------------------------
    // 4. CÜMLE YAPISI / KOMUT
    // --------------------------------------------------------
    final normalizedStart = source.replaceFirst(
      RegExp(r'^[\[\(\*].*?[\]\)\*]\s*'),
      '',
    );

    if (RegExp(
      r'^(run|go|move|hurry|hide|duck|get down|get out|come on|quick|stop|watch out|look out)\b',
    ).hasMatch(normalizedStart)) {
      add('urgent', 3);
    }

    if (RegExp(
      r'^(shut up|get away|leave me|drop it|put it down|back off)\b',
    ).hasMatch(normalizedStart)) {
      add('angry', 3);
    }

    // "Don't worry / I'm not afraid" gibi negasyonlar yanlış korku
    // tespitini düşürür.
    if (combined.contains("don't worry") ||
        combined.contains('do not worry') ||
        combined.contains('endişelenme')) {
      add('fear', -6);
      add('calm', 4);
    }

    if (combined.contains("i'm not afraid") ||
        combined.contains('i am not afraid') ||
        combined.contains('korkmuyorum')) {
      add('fear', -6);
      add('confident', 4);
    }

    // Korku + aciliyet aynı anda güçlüyse "panik" daha mantıklıdır.
    if ((scores['fear'] ?? 0) >= 6 && (scores['urgent'] ?? 0) >= 4) {
      add('fear', 3);
    }

    // Fısıltı açıkça belirtilmişse diğer duyguların ses şiddetini
    // bastırır; örneğin [whispers] Hurry.
    if ((scores['whisper'] ?? 0) >= 10) {
      scores['angry'] = (scores['angry'] ?? 0) - 4;
      scores['urgent'] = (scores['urgent'] ?? 0) - 3;
    }

    // Negatif puanları sıfırla.
    for (final key in scores.keys.toList()) {
      if ((scores[key] ?? 0) < 0) {
        scores[key] = 0;
      }
    }

    // --------------------------------------------------------
    // 5. EN GÜÇLÜ DUYGU + GÜVEN
    // --------------------------------------------------------
    final priority = [
      'whisper',
      'angry',
      'fear',
      'sad',
      'urgent',
      'joy',
      'confident',
      'calm',
    ];

    String winner = 'neutral';
    var winnerScore = 0;
    var secondScore = 0;

    for (final type in priority) {
      final score = scores[type] ?? 0;

      if (score > winnerScore) {
        secondScore = winnerScore;
        winnerScore = score;
        winner = type;
      } else if (score > secondScore) {
        secondScore = score;
      }
    }

    if (winnerScore < 3) {
      winner = 'neutral';
      winnerScore = 0;
    }

    final scoreGap = winnerScore - secondScore;

    final confidence = explicitCue
        ? 10
        : (winnerScore + (scoreGap >= 3 ? 2 : 0)).clamp(0, 10);

    final strong =
        explicitCue || winnerScore >= 8 || (winnerScore >= 6 && scoreGap >= 3);

    debugPrint(
      'DUYGU SKORLARI: $scores | '
      'kazanan=$winner | '
      'güven=$confidence',
    );

    return EmotionDecision(
      emotion: emotionPreset(winner, strong: strong),
      confidence: confidence,
      explicitCue: explicitCue,
    );
  }

  SpeechEmotion softenEmotion(SpeechEmotion emotion) {
    switch (emotion.type) {
      case 'angry':
      case 'fear':
      case 'sad':
      case 'urgent':
      case 'calm':
      case 'joy':
      case 'confident':
        return emotionPreset(emotion.type, strong: false);

      case 'whisper':
        return emotion;

      default:
        return emotionPreset('neutral', strong: false);
    }
  }

  SpeechEmotion stabilizeEmotionForSpeaker(
    String? speaker,
    EmotionDecision decision,
  ) {
    if (speaker == null || speaker.trim().isEmpty) {
      return decision.emotion;
    }

    final key = GameVoiceStore.normalizeSpeaker(speaker);

    final now = DateTime.now();

    final previousEmotion = lastEmotionBySpeaker[key];

    final previousAt = lastEmotionAtBySpeaker[key];

    final previousIsRecent =
        previousEmotion != null &&
        previousAt != null &&
        now.difference(previousAt).inMilliseconds <= 5500;

    // Güçlü / açık bir işaret yeni duyguyu doğrudan kabul eder.
    if (decision.explicitCue || decision.confidence >= 6) {
      lastEmotionBySpeaker[key] = decision.emotion;
      lastEmotionAtBySpeaker[key] = now;

      return decision.emotion;
    }

    // Yeni cümle nötr ya da düşük güvenliyse aynı karakterin birkaç
    // saniye önceki dramatik tonunu hafif biçimde devam ettir.
    if (previousIsRecent &&
        previousEmotion.type != 'neutral' &&
        decision.confidence <= 3) {
      final softened = softenEmotion(previousEmotion);

      lastEmotionBySpeaker[key] = softened;
      lastEmotionAtBySpeaker[key] = now;

      debugPrint(
        'DUYGU BAĞLAMI KORUNDU: '
        '$key -> ${softened.label}',
      );

      return softened;
    }

    lastEmotionBySpeaker[key] = decision.emotion;
    lastEmotionAtBySpeaker[key] = now;

    return decision.emotion;
  }

  String normalizeEnglishForTranslation(String text) {
    var value = text.trim();

    // OCR bazen H U R R Y gibi tek tek harfler üretir.
    // Çeviri motoruna göndermeden önce tekrar kelime haline getir.
    value = value.replaceAllMapped(
      RegExp(r'\b(?:[A-Za-z]\s+){2,}[A-Za-z]\b'),
      (match) => match.group(0)!.replaceAll(RegExp(r'\s+'), ''),
    );

    // ML Kit bazı TAMAMI BÜYÜK İngilizce kelimeleri
    // özel isim gibi algılayıp çevirmeden bırakabiliyor.
    // Sadece tamamı büyük kelimeleri küçük harfe çeviriyoruz.
    value = value.replaceAllMapped(
      RegExp(r'\b[A-Z]{2,}\b'),
      (match) => match.group(0)!.toLowerCase(),
    );

    // Fazla boşlukları temizle.
    value = value.replaceAll(RegExp(r'\s+'), ' ');

    return value.trim();
  }

  List<String> splitEnglishIntoClauses(String text) {
    final value = text.trim();

    if (value.isEmpty) {
      return const [];
    }

    final matches = RegExp(r'[^.!?]+[.!?]*').allMatches(value);

    final clauses = <String>[];

    for (final match in matches) {
      final clause = match.group(0)?.trim() ?? '';

      if (clause.isNotEmpty) {
        clauses.add(clause);
      }
    }

    return clauses.isEmpty ? [value] : clauses;
  }

  String normalizeResidualEnglish(String translated) {
    var value = translated.trim();

    // ML Kit bazen kısa komut kelimelerini İngilizce bırakabiliyor.
    // Bunlar yalnızca çeviri sonucunda hâlâ İngilizce kaldığında
    // devreye giren güvenli oyun-diyaloğu karşılıklarıdır.
    const replacements = <String, String>{
      'hurry': 'acele et',
      'quick': 'çabuk',
      'quickly': 'çabucak',
      'now': 'hemen',
      'run': 'kaç',
      'move': 'hareket et',
      'stop': 'dur',
      'wait': 'bekle',
      'help': 'yardım et',
      'hide': 'saklan',
      'go': 'git',
      'come': 'gel',
      'listen': 'dinle',
      'look': 'bak',
      'watch': 'dikkat et',
      'behind': 'arkanda',
      'danger': 'tehlike',
      'please': 'lütfen',
      'sorry': 'üzgünüm',
      'thanks': 'teşekkürler',
      'thank': 'teşekkür et',
      'yes': 'evet',
      'no': 'hayır',
    };

    for (final entry in replacements.entries) {
      value = value.replaceAllMapped(
        RegExp('\\\\b${RegExp.escape(entry.key)}\\\\b', caseSensitive: false),
        (_) => entry.value,
      );
    }

    value = value.replaceAll(RegExp(r'\s+'), ' ');

    return value.trim();
  }

  String canonicalGamePhrase(String text) {
    var value = text
        .toLowerCase()
        .trim()
        .replaceAll(RegExp(r'[^a-z\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    return value;
  }

  int levenshteinDistance(String a, String b) {
    if (a == b) return 0;
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;

    final previous = List<int>.generate(b.length + 1, (index) => index);

    final current = List<int>.filled(b.length + 1, 0);

    for (var i = 1; i <= a.length; i++) {
      current[0] = i;

      for (var j = 1; j <= b.length; j++) {
        final substitutionCost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1)
            ? 0
            : 1;

        current[j] = [
          current[j - 1] + 1,
          previous[j] + 1,
          previous[j - 1] + substitutionCost,
        ].reduce((x, y) => x < y ? x : y);
      }

      for (var j = 0; j <= b.length; j++) {
        previous[j] = current[j];
      }
    }

    return previous[b.length];
  }

  String? exactGameDialogueTranslation(String clause) {
    final value = canonicalGamePhrase(clause);

    const exactPhrases = <String, String>{
      'shut up': 'Kapa çeneni!',
      'get away from me': 'Benden uzak dur!',
      'leave me alone': 'Beni yalnız bırak!',
      'back off': 'Geri çekil!',
      'stay away from me': 'Benden uzak dur!',
      'hurry': 'Acele et!',
      'hurry up': 'Acele et!',
      'run': 'Kaç!',
      'run now': 'Hemen kaç!',
      'get out of here': 'Buradan çık!',
      'get out of here now': 'Hemen buradan çık!',
      'we need to get out of here': 'Buradan çıkmamız gerek.',
      'we have to get out of here': 'Buradan çıkmak zorundayız.',
      'help me': 'Bana yardım et!',
      'help us': 'Bize yardım et!',
      'watch out': 'Dikkat et!',
      'look out': 'Dikkat!',
      'behind you': 'Arkanda!',
      'calm down': 'Sakin ol.',
      'listen to me': 'Beni dinle.',
      'wait here': 'Burada bekle.',
      'follow me': 'Beni takip et.',
      'trust me': 'Bana güven.',
      'come on': 'Hadi!',
      "let s go": 'Hadi gidelim!',
      'move': 'Hareket et!',
      'move now': 'Hemen hareket et!',
      'stop': 'Dur!',
      'hide': 'Saklan!',
    };

    final direct = exactPhrases[value];

    if (direct != null) {
      debugPrint(
        'OYUN KALIBI TAM EŞLEŞTİ: '
        '$value -> $direct',
      );

      return direct;
    }

    // OCR ekranda doğru görünüyor olsa bile bazen görünmeyen
    // karakter veya tek harflik sapma üretebilir. Oyun komutlarında
    // 1-2 karakterlik farkı toleranslı eşleştiriyoruz.
    String? bestKey;
    var bestDistance = 999;

    for (final key in exactPhrases.keys) {
      final distance = levenshteinDistance(value, key);

      if (distance < bestDistance) {
        bestDistance = distance;
        bestKey = key;
      }
    }

    if (bestKey != null) {
      final allowedDistance = bestKey.length >= 16 ? 2 : 1;

      if (bestDistance <= allowedDistance) {
        final translated = exactPhrases[bestKey];

        debugPrint(
          'OYUN KALIBI YAKIN EŞLEŞTİ: '
          '$value -> $bestKey '
          '(fark=$bestDistance) -> '
          '$translated',
        );

        return translated;
      }
    }

    return null;
  }

  String correctSpeakerFromKnownCharacters(String rawSpeaker) {
    final normalized = GameVoiceStore.normalizeSpeaker(rawSpeaker);

    final knownSpeakers = GameVoiceStore.assignmentsForGame(
      widget.game.id,
    ).keys.map(GameVoiceStore.normalizeSpeaker).toSet().toList();

    if (knownSpeakers.isEmpty || knownSpeakers.contains(normalized)) {
      return normalized;
    }

    final scored = knownSpeakers.map((candidate) {
      return MapEntry(candidate, levenshteinDistance(normalized, candidate));
    }).toList()..sort((a, b) => a.value.compareTo(b.value));

    if (scored.isEmpty) {
      return normalized;
    }

    final best = scored.first;

    final secondDistance = scored.length >= 2 ? scored[1].value : 999;

    final sameFirstTwo =
        normalized.length >= 2 &&
        best.key.length >= 2 &&
        normalized.substring(0, 2) == best.key.substring(0, 2);

    final safeMatch =
        best.value <= 1 ||
        (best.value <= 2 && sameFirstTwo && secondDistance > best.value);

    if (!safeMatch) {
      return normalized;
    }

    debugPrint(
      'KONUŞMACI OCR DÜZELTİLDİ: '
      '$normalized -> ${best.key} '
      '(fark=${best.value})',
    );

    return best.key;
  }

  String normalizeSubtitleCacheText(String text) {
    return text
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9çğıöşü\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  String normalizeSubtitleForFuzzyDuplicate(String text) {
    var normalized = text
        .toLowerCase()
        .replaceAll('0', 'o')
        .replaceAll(RegExp(r'[^a-z0-9\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    if (normalized.isEmpty) {
      return normalized;
    }

    // OCR bazen ':' işaretini tamamen kaybedip:
    //   ARTHURB I romomber this place
    // gibi bir çıktı üretiyor.
    // İlk token bilinen bir karakter adına çok yakınsa onu duplicate
    // karşılaştırmasından çıkarıyoruz. Bu yalnızca fuzzy eşleştirmede
    // kullanılır; gerçek çeviri metnini değiştirmez.
    final parts = normalized.split(' ');

    if (parts.length >= 2) {
      final firstToken = GameVoiceStore.normalizeSpeaker(parts.first);

      final knownSpeakers = <String>{
        ...GameVoiceStore.assignmentsForGame(
          widget.game.id,
        ).keys.map(GameVoiceStore.normalizeSpeaker),
        if (currentSpeaker != null && currentSpeaker!.trim().isNotEmpty)
          GameVoiceStore.normalizeSpeaker(currentSpeaker!),
      };

      String? bestSpeaker;
      var bestDistance = 999;
      var secondDistance = 999;

      for (final candidate in knownSpeakers) {
        final distance = levenshteinDistance(firstToken, candidate);

        if (distance < bestDistance) {
          secondDistance = bestDistance;

          bestDistance = distance;

          bestSpeaker = candidate;
        } else if (distance < secondDistance) {
          secondDistance = distance;
        }
      }

      final sameFirstTwo =
          bestSpeaker != null &&
          firstToken.length >= 2 &&
          bestSpeaker.length >= 2 &&
          firstToken.substring(0, 2) == bestSpeaker.substring(0, 2);

      final safeSpeakerPrefix =
          bestSpeaker != null &&
          (bestDistance <= 1 ||
              (bestDistance <= 2 &&
                  sameFirstTwo &&
                  secondDistance > bestDistance));

      if (safeSpeakerPrefix) {
        normalized = parts.skip(1).join(' ').trim();
      }
    }

    return normalized;
  }

  bool speakersCompatibleForFuzzyDuplicate(String? previous, String? incoming) {
    final previousNormalized = previous == null || previous.trim().isEmpty
        ? 'UNKNOWN'
        : GameVoiceStore.normalizeSpeaker(previous);

    final incomingNormalized = incoming == null || incoming.trim().isEmpty
        ? 'UNKNOWN'
        : GameVoiceStore.normalizeSpeaker(incoming);

    // İki taraf da net biçimde farklı karakterlerse aynı metni bile
    // duplicate saymıyoruz. İki farklı karakter gerçekten aynı kısa
    // cümleyi arka arkaya söyleyebilir.
    if (previousNormalized != 'UNKNOWN' &&
        incomingNormalized != 'UNKNOWN' &&
        previousNormalized != incomingNormalized) {
      return false;
    }

    return true;
  }

  double fuzzySubtitleSimilarity(String first, String second) {
    if (first.isEmpty || second.isEmpty) {
      return 0.0;
    }

    if (first == second) {
      return 1.0;
    }

    final distance = levenshteinDistance(first, second);

    final maxLength = first.length > second.length
        ? first.length
        : second.length;

    if (maxLength == 0) {
      return 1.0;
    }

    return (1.0 - distance / maxLength).clamp(0.0, 1.0).toDouble();
  }

  bool isSafeFuzzySubtitleDuplicate({
    required String sourceText,
    String? speaker,
  }) {
    if (lastProcessedSubtitleAt == null ||
        lastProcessedSubtitleFuzzyText == null) {
      return false;
    }

    final now = DateTime.now();

    if (now.difference(lastProcessedSubtitleAt!) > duplicateSubtitleWindow) {
      return false;
    }

    if (!speakersCompatibleForFuzzyDuplicate(
      lastProcessedSubtitleSpeaker,
      speaker,
    )) {
      return false;
    }

    final incoming = normalizeSubtitleForFuzzyDuplicate(sourceText);

    final previous = lastProcessedSubtitleFuzzyText!;

    if (incoming.isEmpty || previous.isEmpty) {
      return false;
    }

    // Çok kısa altyazılarda fuzzy eşleştirme riskli:
    // "Go!" / "No!" / "Run!" gibi gerçek farklı replikleri
    // yanlışlıkla yutmayalım. Kısalarda yalnızca exact duplicate.
    final maxLength = incoming.length > previous.length
        ? incoming.length
        : previous.length;

    if (maxLength < 10) {
      return incoming == previous;
    }

    final similarity = fuzzySubtitleSimilarity(previous, incoming);

    final lengthDifference = (previous.length - incoming.length).abs();

    // Uzun altyazılarda 1-3 karakterlik OCR kaymalarını güvenle
    // aynı subtitle say. Eşik bilerek yüksek tutuluyor.
    final requiredSimilarity = maxLength >= 18 ? 0.86 : 0.91;

    final maxAllowedLengthDifference = maxLength >= 18 ? 4 : 2;

    final isDuplicate =
        similarity >= requiredSimilarity &&
        lengthDifference <= maxAllowedLengthDifference;

    if (isDuplicate) {
      ocrDebugPrint(
        'FUZZY ALTYAZI DUPLICATE: '
        '${(similarity * 100).toStringAsFixed(1)}% '
        '| "$previous" ~= "$incoming"',
      );
    }

    return isDuplicate;
  }

  String subtitleCacheKey({required String sourceText, String? speaker}) {
    final normalizedSpeaker = speaker == null || speaker.trim().isEmpty
        ? 'UNKNOWN'
        : GameVoiceStore.normalizeSpeaker(speaker);

    final normalizedText = normalizeSubtitleCacheText(sourceText);

    return '${widget.game.id}|'
        '$normalizedSpeaker|'
        '$normalizedText';
  }

  bool isImmediateDuplicateSubtitle({
    required String sourceText,
    String? speaker,
  }) {
    final key = subtitleCacheKey(sourceText: sourceText, speaker: speaker);

    final now = DateTime.now();

    final withinDuplicateWindow =
        lastProcessedSubtitleAt != null &&
        now.difference(lastProcessedSubtitleAt!) <= duplicateSubtitleWindow;

    if (lastProcessedSubtitleKey == key && withinDuplicateWindow) {
      ocrDebugPrint('AYNI ALTYAZI ATLADI: $key');

      return true;
    }

    if (withinDuplicateWindow &&
        isSafeFuzzySubtitleDuplicate(
          sourceText: sourceText,
          speaker: speaker,
        )) {
      ocrDebugPrint(
        'OCR-TOLERANSLI DUPLICATE ATLADI: '
        '$sourceText',
      );

      return true;
    }

    // Yalnızca gerçekten yeni bir subtitle kabul edildiğinde referansı
    // güncelliyoruz. Fuzzy duplicate varyantı referansı bozmaz; böylece
    // aynı altyazının sonraki OCR bozulmaları da ilk temiz versiyona göre
    // karşılaştırılmaya devam eder.
    lastProcessedSubtitleKey = key;

    lastProcessedSubtitleAt = now;

    lastProcessedSubtitleFuzzyText = normalizeSubtitleForFuzzyDuplicate(
      sourceText,
    );

    lastProcessedSubtitleSpeaker = speaker;

    return false;
  }

  String? getCachedTranslation({required String sourceText, String? speaker}) {
    final key = subtitleCacheKey(sourceText: sourceText, speaker: speaker);

    final cached = translationCache[key];

    if (cached == null) {
      return null;
    }

    if (DateTime.now().difference(cached.createdAt) >
        translationCacheLifetime) {
      translationCache.remove(key);
      return null;
    }

    debugPrint(
      'ÇEVİRİ CACHE HIT: '
      '${cached.translation}',
    );

    return cached.translation;
  }

  void saveTranslationToCache({
    required String sourceText,
    String? speaker,
    required String translation,
  }) {
    final key = subtitleCacheKey(sourceText: sourceText, speaker: speaker);

    translationCache[key] = CachedTranslation(
      translation: translation,
      createdAt: DateTime.now(),
    );

    // Belleğin sınırsız büyümesini engelle.
    if (translationCache.length > maxTranslationCacheEntries) {
      final entries = translationCache.entries.toList()
        ..sort((a, b) => a.value.createdAt.compareTo(b.value.createdAt));

      final removeCount = translationCache.length - maxTranslationCacheEntries;

      for (var i = 0; i < removeCount; i++) {
        translationCache.remove(entries[i].key);
      }
    }
  }

  Future<String> translateWithGroqBackend(
    String sourceText, {
    String? speaker,
  }) async {
    final normalized = normalizeEnglishForTranslation(sourceText);

    if (normalized.isEmpty) {
      return '';
    }

    final localCacheWatch = Stopwatch()..start();

    final cached = getCachedTranslation(
      sourceText: normalized,
      speaker: speaker,
    );

    localCacheWatch.stop();

    if (cached != null) {
      final normalizedSpeaker = speaker == null || speaker.trim().isEmpty
          ? null
          : GameVoiceStore.normalizeSpeaker(speaker);

      final cachedProfile = normalizedSpeaker == null
          ? null
          : CharacterProfileStore.get(
              gameId: widget.game.id,
              speaker: normalizedSpeaker,
            );

      final hasCachedGender =
          cachedProfile?.gender == 'male' || cachedProfile?.gender == 'female';

      if (normalizedSpeaker == null || hasCachedGender) {
        logPerformance(
          'FLUTTER ÇEVİRİ CACHE',
          durationMs: localCacheWatch.elapsedMilliseconds,
          extra: 'HIT',
        );

        return cached;
      }

      // Eski cihaz içi çeviri cache'inde speakerGender yoksa
      // sadece bir kez backend'e gidip cinsiyeti de öğren.
      // Backend kendi cache'inden cevap verebildiği için bu işlem
      // ayrı karakter profili sorgusundan çok daha hızlıdır.
      logPerformance(
        'FLUTTER ÇEVİRİ CACHE',
        durationMs: localCacheWatch.elapsedMilliseconds,
        extra: 'HIT / GENDER MISS -> BACKEND',
      );
    } else {
      logPerformance(
        'FLUTTER ÇEVİRİ CACHE',
        durationMs: localCacheWatch.elapsedMilliseconds,
        extra: 'MISS',
      );
    }

    final uri = Uri.parse('$backendBaseUrl/translate/game');

    final backendWatch = Stopwatch()..start();

    final response = await http
        .post(
          uri,
          headers: const {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode({
            'text': normalized,
            'gameName': widget.game.name,
            'speaker': speaker?.trim() ?? '',
            'previousLines': recentDialogueContext.take(3).toList(),
          }),
        )
        .timeout(const Duration(milliseconds: 1500));

    backendWatch.stop();

    if (response.statusCode != 200) {
      logPerformance(
        'BACKEND İSTEĞİ',
        durationMs: backendWatch.elapsedMilliseconds,
        extra: 'HTTP ${response.statusCode}',
      );
      throw Exception(
        'Groq backend HTTP '
        '${response.statusCode}: '
        '${response.body}',
      );
    }

    final dynamic decoded = jsonDecode(response.body);

    if (decoded is! Map) {
      throw Exception('Groq backend geçersiz cevap döndürdü.');
    }

    final data = Map<String, dynamic>.from(decoded);

    final translation = data['translation']?.toString().trim() ?? '';

    final provider = data['provider']?.toString() ?? 'bilinmiyor';

    final rawSpeakerGender =
        data['speakerGender']?.toString().trim().toLowerCase() ?? 'unknown';

    final speakerGender =
        rawSpeakerGender == 'male' || rawSpeakerGender == 'female'
        ? rawSpeakerGender
        : 'unknown';

    final backendCached = data['cached'] == true;

    logPerformance(
      'BACKEND İSTEĞİ',
      durationMs: backendWatch.elapsedMilliseconds,
      extra:
          'provider=$provider, '
          'backendCache=$backendCached',
    );

    if (translation.isEmpty) {
      throw Exception('Groq boş çeviri döndürdü.');
    }

    saveTranslationToCache(
      sourceText: normalized,
      speaker: speaker,
      translation: translation,
    );

    if (speaker != null &&
        speaker.trim().isNotEmpty &&
        (speakerGender == 'male' || speakerGender == 'female')) {
      final normalizedSpeaker = GameVoiceStore.normalizeSpeaker(speaker);

      // save() belleği ilk await'ten önce günceller. Bu nedenle
      // TTS aşağıda hemen profile erişebilir; SharedPreferences
      // yazımı ise seslendirmeyi bekletmeden arka planda sürer.
      unawaited(
        CharacterProfileStore.save(
          gameId: widget.game.id,
          speaker: normalizedSpeaker,
          profile: CharacterProfile(
            found: true,
            matchedName: normalizedSpeaker,
            gender: speakerGender,
          ),
        ),
      );

      debugPrint(
        'ÇEVİRİDEN CİNSİYET KAYDEDİLDİ: '
        '$normalizedSpeaker -> $speakerGender',
      );
    }

    debugPrint(
      'GROQ ÇEVİRİSİ: '
      '$normalized -> $translation',
    );

    return translation;
  }

  void rememberDialogueContext(String sourceText, {String? speaker}) {
    final clean = sourceText.trim();

    if (clean.isEmpty) {
      return;
    }

    final line = speaker != null && speaker.trim().isNotEmpty
        ? '${speaker.trim()}: $clean'
        : clean;

    if (recentDialogueContext.isNotEmpty &&
        recentDialogueContext.last == line) {
      return;
    }

    recentDialogueContext.add(line);

    // Sadece son 3 satırı sakla.
    while (recentDialogueContext.length > 3) {
      recentDialogueContext.removeAt(0);
    }
  }

  Future<String> translateEnglishRobustly(String sourceText) async {
    final normalized = normalizeEnglishForTranslation(sourceText);

    if (normalized.isEmpty) {
      return '';
    }

    final canonicalWhole = canonicalGamePhrase(normalized);

    if (canonicalWhole == 'shut up get away from me') {
      const direct = 'Kapa çeneni! Benden uzak dur!';

      debugPrint(
        'OYUN CÜMLESİ DOĞRUDAN ÇEVRİLDİ: '
        '$canonicalWhole -> $direct',
      );

      return direct;
    }

    final clauses = splitEnglishIntoClauses(normalized);

    final translatedClauses = <String>[];

    for (final clause in clauses) {
      final exact = exactGameDialogueTranslation(clause);

      if (exact != null) {
        translatedClauses.add(exact);
        continue;
      }

      final translated = await translator.translate(clause) ?? '';

      var cleaned = translated.trim();

      if (cleaned.isEmpty) {
        continue;
      }

      cleaned = normalizeResidualEnglish(cleaned);

      translatedClauses.add(cleaned);
    }

    return translatedClauses.join(' ').replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  Future<void> translateRecognizedText(String sourceText) async {
    final parseWatch = Stopwatch()..start();

    final segments = parseDialogueSegments(sourceText);

    parseWatch.stop();

    logPerformance(
      'DİYALOG AYRIŞTIRMA',
      durationMs: parseWatch.elapsedMilliseconds,
      extra: 'segment=${segments.length}',
    );

    if (segments.isEmpty) {
      return;
    }

    final sourceSignature = segments
        .map((segment) => '${segment.speaker ?? ''}:${segment.text}')
        .join('|');

    if (sourceSignature == lastTranslatedSource) {
      // Aynı altyazı ekranda durmaya devam ettiği sürece duplicate
      // koruma penceresini canlı tut. Önceki sürümde bu erken return
      // yüzünden lastProcessedSubtitleAt yalnızca ilk çeviride kalıyordu.
      // 5+ saniye sonra OCR tek harf şaşırırsa aynı replik yeni altyazı
      // sanılabiliyordu. Artık her temiz tekrar pencereyi yeniler.
      if (lastProcessedSubtitleAt != null) {
        lastProcessedSubtitleAt = DateTime.now();
      }

      logPerformance(
        'ÇEVİRİ ATLADI',
        extra: 'aynı sourceSignature - duplicate penceresi yenilendi',
      );
      return;
    }

    // Ana çeviri artık Groq/Qwen üzerinden backend'den geliyor.
    // ML Kit yalnızca Groq erişilemezse yedek olarak tutuluyor.
    if (isTranslating) {
      logPerformance('ÇEVİRİ ATLADI', extra: 'önceki çeviri hâlâ çalışıyor');
      return;
    }

    isTranslating = true;

    final fullTranslationWatch = Stopwatch()..start();

    try {
      final translations = <String>[];

      for (final segment in segments) {
        if (segment.text.trim().isEmpty) {
          continue;
        }

        String? effectiveSpeaker = segment.speaker;

        if (effectiveSpeaker != null && effectiveSpeaker.trim().isNotEmpty) {
          effectiveSpeaker = correctSpeakerFromKnownCharacters(
            effectiveSpeaker,
          );
        }

        final normalizedCurrentDialogue = normalizeSubtitleCacheText(
          segment.text,
        );

        if (effectiveSpeaker != null && effectiveSpeaker.isNotEmpty) {
          lastSpeakerDetectedAt = DateTime.now();

          lastConfirmedSpeakerDialogue = normalizedCurrentDialogue;

          if (mounted) {
            setState(() {
              currentSpeaker = effectiveSpeaker;
            });
          }

          debugPrint(
            'KONUŞMACI DOĞRULANDI: '
            '$effectiveSpeaker',
          );
        } else {
          final sameSubtitleAsLastConfirmed =
              currentSpeaker != null &&
              currentSpeaker!.isNotEmpty &&
              lastSpeakerDetectedAt != null &&
              lastConfirmedSpeakerDialogue != null &&
              normalizedCurrentDialogue == lastConfirmedSpeakerDialogue &&
              DateTime.now().difference(lastSpeakerDetectedAt!).inSeconds <= 5;

          if (sameSubtitleAsLastConfirmed) {
            // Yalnızca AYNI altyazının sonraki OCR karesinde isim
            // kaçtıysa önceki konuşmacıyı koru. Yeni bir cümlede
            // JOHN'u kaçırıp ARTHUR sesi verme gibi hatalar artık olmaz.
            effectiveSpeaker = currentSpeaker;

            debugPrint(
              'AYNI ALTYAZIDA KONUŞMACI KORUNDU: '
              '$effectiveSpeaker',
            );
          } else {
            // Yeni bir altyazıda isim okunamadıysa önceki karakteri
            // kesinlikle devralma.
            effectiveSpeaker = null;

            debugPrint(
              'YENİ ALTYAZIDA KONUŞMACI BELİRSİZ - '
              'ÖNCEKİ KARAKTER KULLANILMADI.',
            );
          }
        }

        final sourceForTranslation = normalizeEnglishForTranslation(
          segment.text.trim(),
        );

        debugPrint(
          'ÇEVİRİYE GİDEN İNGİLİZCE: '
          '$sourceForTranslation',
        );

        if (isImmediateDuplicateSubtitle(
          sourceText: sourceForTranslation,
          speaker: effectiveSpeaker,
        )) {
          logPerformance(
            'ALTYAZI DUPLICATE',
            extra:
                'exact/fuzzy - Groq/backend çağrılmadı, TTS kuyruğuna eklenmedi',
          );
          continue;
        }

        String translated;

        try {
          translated = await translateWithGroqBackend(
            sourceForTranslation,
            speaker: effectiveSpeaker,
          );

          debugPrint(
            'ÇEVİRİ SAĞLAYICI: '
            'Groq / Qwen 3.8 27B',
          );
        } catch (groqError) {
          debugPrint(
            'GROQ ÇEVİRİ HATASI - '
            'CİHAZDA ÇEVİRİ YEDEĞİNE GEÇİLİYOR: '
            '$groqError',
          );

          if (!isTranslatorReady) {
            rethrow;
          }

          translated = await translateEnglishRobustly(sourceForTranslation);

          debugPrint(
            'ÇEVİRİ SAĞLAYICI: '
            'Cihazda çeviri (yedek)',
          );
        }

        final cleanTranslation = translated.trim();

        debugPrint(
          'ÇEVİRİ SONUCU: '
          '$cleanTranslation',
        );

        if (cleanTranslation.isEmpty) {
          continue;
        }

        translations.add(cleanTranslation);

        // Çeviri ekrana SES hazırlığını beklemeden anında düşsün.
        if (mounted) {
          setState(() {
            translatedText = translations.join('\n');
            lastTranslatedSource = sourceSignature;
          });
          if (tvRelayEnabled &&
              isTranslationRunning &&
              !isCameraPageDisposing &&
              !demoExpiryNavigationStarted) {
            TvLinkHub.instance.client.sendCaption(translations.join('\n'));
          }
        }

        rememberDialogueContext(
          sourceForTranslation,
          speaker: effectiveSpeaker,
        );

        await speakTranslation(
          cleanTranslation,
          speaker: effectiveSpeaker,
          sourceText: segment.text.trim(),
        );
      }

      if (!mounted) return;

      setState(() {
        translatedText = translations.isEmpty
            ? 'Çeviri oluşturulamadı.'
            : translations.join('\n');

        lastTranslatedSource = sourceSignature;
      });
    } catch (e, stackTrace) {
      debugPrint('ÇEVİRİ HATASI: $e');
      debugPrint('$stackTrace');

      if (!mounted) return;

      setState(() {
        translatedText = 'Çeviri hatası:\n$e';
      });
    } finally {
      fullTranslationWatch.stop();

      logPerformance(
        'ÇEVİRİ AKIŞI TAMAMLANDI',
        durationMs: fullTranslationWatch.elapsedMilliseconds,
      );

      isTranslating = false;
    }
  }

  String normalizeTextForTts(String text) {
    var value = text.trim();

    // OCR bazen "H U R R Y" gibi harfleri ayrı ayrı çıkarabiliyor.
    // Ardışık tek harfleri tekrar kelimeye birleştir.
    value = value.replaceAllMapped(
      RegExp(r'\b(?:[A-Za-zÇĞİÖŞÜçğıöşü]\s+){2,}[A-Za-zÇĞİÖŞÜçğıöşü]\b'),
      (match) => match.group(0)!.replaceAll(RegExp(r'\s+'), ''),
    );

    // Tamamı büyük yazılmış kelimeler bazı Android TTS
    // motorlarında harf harf okunabiliyor. Konuşma için
    // normal kelime biçimine çevir; ekrandaki metni değiştirme.
    value = value.replaceAllMapped(
      RegExp(r'\b[A-ZÇĞİÖŞÜ]{2,}\b'),
      (match) => match.group(0)!.toLowerCase(),
    );

    // Fazla boşlukları temizle.
    value = value.replaceAll(RegExp(r'\s+'), ' ');

    return value.trim();
  }

  Future<void> speakTranslation(
    String text, {
    String? speaker,
    String? sourceText,
  }) async {
    final cleaned = text.trim();

    if (cleaned.isEmpty) return;

    final speechKeySpeaker = speaker == null || speaker.trim().isEmpty
        ? 'ANONİM'
        : GameVoiceStore.normalizeSpeaker(speaker);

    final uniqueSpeechKey = '$speechKeySpeaker|$cleaned';

    final now = DateTime.now();

    final isRecentSameSpeech =
        uniqueSpeechKey == lastSpokenText &&
        lastSpokenAt != null &&
        now.difference(lastSpokenAt!) < ttsDuplicateCooldown;

    if (isRecentSameSpeech ||
        uniqueSpeechKey == currentSpeechKey ||
        queuedSpeechKeys.contains(uniqueSpeechKey)) {
      debugPrint(
        'TTS KUYRUK DUPLICATE ATLADI: '
        '$uniqueSpeechKey',
      );
      return;
    }

    try {
      final hasVerifiedSpeaker = speaker != null && speaker.trim().isNotEmpty;

      final ttsSpeaker = hasVerifiedSpeaker ? speaker.trim() : 'ANONİM';

      final useTemporaryVoice =
          !hasVerifiedSpeaker || isGenericSpeakerLabel(speaker);

      if (!useTemporaryVoice) {
        unawaited(
          GameAiVoiceStore.markSpeakerDetected(
            gameId: widget.game.id,
            speaker: ttsSpeaker,
          ),
        );
      }

      // Canlı seslendirme karakter profil HTTP sorgusunu beklemez.
      // Önceden öğrenilmiş profil varsa anında kullanılır; yoksa
      // bu replik hemen kuyruğa girerken profil arka planda öğrenilir.
      final profileWatch = Stopwatch()..start();

      final profile = useTemporaryVoice
          ? const CharacterProfile(
              found: false,
              matchedName: null,
              gender: 'unknown',
            )
          : getCachedCharacterProfileOrUnknown(ttsSpeaker);

      if (!useTemporaryVoice && profile.gender == 'unknown') {
        unawaited(warmCharacterProfileInBackground(ttsSpeaker));
      }

      profileWatch.stop();

      logPerformance(
        'KARAKTER PROFİLİ',
        durationMs: profileWatch.elapsedMilliseconds,
        extra:
            '${profile.matchedName ?? ttsSpeaker} / '
            '${profile.gender}',
      );

      final voiceWatch = Stopwatch()..start();

      // AI modu açıksa bütün repliklerde ElevenLabs birincil yol olsun.
      // Karakter adı/cinsiyeti eksikse prepareAiTts() genel AI fallback
      // voiceId'sini gönderir; yalnızca AI başarısız/çok yavaş olursa
      // cihaz TTS'i devreye girer.
      final shouldPreferAiTts = aiTtsEnabled;

      TtsVoiceOption? assignedVoice;
      TtsVoiceOption? voice;

      if (shouldPreferAiTts) {
        // AI birincil yolsa cihaz sesini burada seçip MethodChannel
        // gecikmesi yaratma. Gerekirse fallback anında seçilecek.
        assignedVoice = null;
        voice = null;
      } else {
        assignedVoice = useTemporaryVoice
            ? null
            : await getOrAssignVoiceForSpeaker(ttsSpeaker, profile);

        voice = assignedVoice ?? await getFallbackVoiceForUnknownSpeaker();
      }

      voiceWatch.stop();

      logPerformance(
        'SES ATAMA',
        durationMs: voiceWatch.elapsedMilliseconds,
        extra: shouldPreferAiTts
            ? 'ElevenLabs AI primary / device voice deferred'
            : (voice?.name ?? 'ses yok'),
      );

      if (!shouldPreferAiTts && (useTemporaryVoice || assignedVoice == null)) {
        debugPrint(
          'GEÇİCİ VARSAYILAN SES: '
          '$ttsSpeaker -> '
          '${voice?.name ?? 'Android varsayılanı'}',
        );
      }

      final emotionDecision = detectSpeechEmotion(
        sourceText ?? cleaned,
        cleaned,
      );

      final emotion = stabilizeEmotionForSpeaker(
        useTemporaryVoice ? null : ttsSpeaker,
        emotionDecision,
      );

      final ttsText = normalizeTextForTts(cleaned);

      final runId = activePerformanceRunId;

      final pipelineElapsedMs =
          activePerformanceTotalWatch?.elapsedMilliseconds ?? 0;

      final job = SpeechJob(
        text: cleaned,
        ttsText: ttsText,
        speaker: ttsSpeaker,
        profile: profile,
        voice: voice,
        emotion: emotion,
        uniqueSpeechKey: uniqueSpeechKey,
        enqueuedAt: DateTime.now(),
        performanceRunId: runId,
        pipelineElapsedAtQueueMs: pipelineElapsedMs,
      );

      // Eğer başka bir ses zaten oynuyorsa/bekliyorsa bu yeni AI
      // repliğini daha sırası gelmeden üretmeye başla.
      final shouldPrefetchAi =
          shouldPreferAiTts &&
          (isSpeechWorkerRunning || speechQueue.isNotEmpty);

      speechQueue.add(job);

      queuedSpeechKeys.add(uniqueSpeechKey);

      // Kısa süreli duplicate koruması. Aynı replik daha sonra tekrar
      // oynatılırsa yeniden kuyruğa girebilir; backend cache'i kullanır.
      lastSpokenText = uniqueSpeechKey;
      lastSpokenAt = DateTime.now();

      if (shouldPrefetchAi && canUseAiTtsForJob(job)) {
        debugPrint(
          '⚡ AI TTS PREFETCH BAŞLATILDI '
          '#${runId ?? '-'} | ${job.speaker} | bekleyen=${speechQueue.length}',
        );

        final prefetchFuture = prefetchAiTtsAudio(job);

        aiTtsPrefetchInFlight[uniqueSpeechKey] = prefetchFuture;

        // İndirme + .mp3 dosyasına yazma tamamlanınca, eğer bu replik
        // kuyruğun başındaysa ikinci AudioPlayer'a source olarak da yükle.
        // Böylece sırası geldiğinde yalnızca resume() gerekir.
        unawaited(
          prefetchFuture.then((_) async {
            if (!isCameraPageDisposing && mounted) {
              await maybePreloadNextAiTts();
            }
          }),
        );
      }

      debugPrint(
        'TTS KUYRUĞA EKLENDİ: '
        '${job.speaker} | '
        'bekleyen=${speechQueue.length} | '
        'PERF #${runId ?? '-'}',
      );

      // KRİTİK:
      // Burada await ETMİYORUZ. Böylece translateRecognizedText
      // hemen tamamlanır, isTranslating=false olur ve kamera yeni
      // altyazıları TTS konuşurken de taramaya devam eder.
      unawaited(processSpeechQueue());
    } catch (e, stackTrace) {
      debugPrint('SES KUYRUĞA EKLEME HATASI: $e');

      debugPrint('$stackTrace');
    }
  }

  // ==========================================================
  // ELEVENLABS AI TTS + CİHAZ TTS FALLBACK
  // ==========================================================

  bool canUseAiTtsForJob(SpeechJob job) {
    return aiTtsEnabled && job.ttsText.trim().isNotEmpty;
  }

  Future<Map<String, dynamic>> prepareAiTts(SpeechJob job) async {
    final canonicalCharacterName =
        (job.profile.matchedName ?? job.speaker).trim();

    final speaker = job.speaker.trim();
    final gender = job.profile.gender.trim().toLowerCase();

    final hasNamedCharacter =
        speaker.isNotEmpty &&
        speaker != 'ANONİM' &&
        !isGenericSpeakerLabel(speaker);

    final hasKnownGender = gender == 'male' || gender == 'female';

    // Kullanıcı Karakter Sesleri ekranından bir ElevenLabs sesi seçtiyse
    // backend'in otomatik karakter havuzundan önce bu seçim kullanılır.
    final manualAiVoice = GameAiVoiceStore.getVoice(
      gameId: widget.game.id,
      speaker: job.speaker,
    );

    final hasManualAiVoice =
        manualAiVoice != null && manualAiVoice.voiceId.trim().isNotEmpty;

    // Manuel seçim yoksa karakter adı/cinsiyeti çözülemeyen replikler
    // sabit genel AI fallback sesine gider.
    final useGenericAiFallback =
        !hasManualAiVoice && (!hasNamedCharacter || !hasKnownGender);

    final effectiveSpeaker = hasNamedCharacter && canonicalCharacterName.isNotEmpty
        ? canonicalCharacterName
        : 'ANONIM';

    final uri = Uri.parse('$aiTtsBackendBaseUrl/tts/ai/prepare');

    final String? devicePlatform = Platform.isIOS
        ? 'ios'
        : Platform.isAndroid
        ? 'android'
        : null;

    final response = await http
        .post(
          uri,
          headers: const {
            'Content-Type': 'application/json; charset=UTF-8',
            'Accept': 'application/json',
          },
          body: jsonEncode({
            'gameId': widget.game.id.toString(),
            'gameName': widget.game.name,
            'speaker': effectiveSpeaker,
            'canonicalCharacterName': effectiveSpeaker,
            'speakerGender': hasKnownGender ? gender : 'unknown',
            'text': job.ttsText,
            if (hasManualAiVoice) 'voiceId': manualAiVoice.voiceId,
            if (!hasManualAiVoice && useGenericAiFallback)
              'voiceId': genericAiFallbackVoiceId,
            if (devicePlatform != null) 'devicePlatform': devicePlatform,
          }),
        )
        .timeout(aiTtsPrepareTimeout);

    dynamic decoded;

    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      throw Exception(
        'AI TTS backend geçerli JSON döndürmedi. '
        'HTTP ${response.statusCode}',
      );
    }

    if (decoded is! Map) {
      throw Exception('AI TTS backend yanıt biçimi geçersiz.');
    }

    final data = Map<String, dynamic>.from(decoded);

    if (response.statusCode < 200 ||
        response.statusCode >= 300 ||
        data['ok'] != true) {
      throw Exception(
        'AI TTS prepare başarısız. '
        'HTTP ${response.statusCode}: '
        '${data['error'] ?? 'bilinmeyen hata'}',
      );
    }

    final audioUrl = data['audioUrl']?.toString().trim() ?? '';

    if (audioUrl.isEmpty) {
      throw Exception('AI TTS audioUrl dönmedi.');
    }

    return data;
  }

  String resolveAiVoiceName(Map<String, dynamic> data) {
    final voiceId = data['voiceId']?.toString() ?? 'unknown';

    String voiceName = voiceId == genericAiFallbackVoiceId
        ? genericAiFallbackVoiceName
        : voiceId;

    final selectionRaw = data['voiceSelection'];

    if (selectionRaw is Map) {
      final selection = Map<String, dynamic>.from(selectionRaw);

      final candidate = selection['voiceName']?.toString().trim();

      if (candidate != null && candidate.isNotEmpty) {
        voiceName = candidate;
      }
    }

    return voiceName;
  }

  Future<void> deleteAiTtsTempFile(String? path) async {
    if (path == null || path.trim().isEmpty) {
      return;
    }

    aiTtsTempFiles.remove(path);

    try {
      final file = File(path);

      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      debugPrint('AI TTS GEÇİCİ MP3 TEMİZLEME NOTU: $e');
    }
  }

  Future<AiTtsPreparedAudio?> prefetchAiTtsAudio(SpeechJob job) async {
    if (!canUseAiTtsForJob(job) || isCameraPageDisposing) {
      return null;
    }

    final totalWatch = Stopwatch()..start();
    String? localFilePath;

    try {
      final prepareWatch = Stopwatch()..start();

      final data = await prepareAiTts(job);

      prepareWatch.stop();

      if (isCameraPageDisposing || !mounted) {
        return null;
      }

      final audioUrl = data['audioUrl']?.toString().trim() ?? '';

      if (audioUrl.isEmpty) {
        throw Exception('AI TTS prefetch audioUrl dönmedi.');
      }

      final cached = data['cached'] == true;
      final streaming = data['streaming'] == true;
      final cacheSource = data['cacheSource']?.toString();
      final voiceId = data['voiceId']?.toString() ?? 'unknown';
      final voiceName = resolveAiVoiceName(data);

      final downloadWatch = Stopwatch()..start();

      // Stream'i sırası gelmeden gerçekten tüketiyoruz. Cache miss ise
      // bu çağrı ElevenLabs üretimini şimdi başlatır; backend aynı anda
      // sesi R2/Postgres cache'e yazar. Cache hit ise R2 dosyası erkenden
      // telefona alınır.
      final audioResponse = await http
          .get(
            Uri.parse(audioUrl),
            headers: const {'Accept': 'audio/mpeg,audio/*;q=0.9,*/*;q=0.1'},
          )
          .timeout(aiTtsPlaybackCompletionTimeout);

      downloadWatch.stop();

      if (audioResponse.statusCode < 200 ||
          audioResponse.statusCode >= 300 ||
          audioResponse.bodyBytes.isEmpty) {
        throw Exception(
          'AI TTS prefetch ses indirme başarısız. '
          'HTTP ${audioResponse.statusCode}',
        );
      }

      if (isCameraPageDisposing || !mounted) {
        return null;
      }

      // ÖNEMLİ:
      // Ses sırasını beklerken RAM byte dizisi olarak tutulmuyor.
      // İndirme biter bitmez gerçek .mp3 dosyasına yazılıyor.
      // Böylece sırası geldiğinde dosya yazma gecikmesi de kalmıyor.
      final fileId =
          '${DateTime.now().microsecondsSinceEpoch}_${job.uniqueSpeechKey.hashCode.toUnsigned(32)}';

      localFilePath =
          '${Directory.systemTemp.path}/gamelingo_ai_prefetch_$fileId.mp3';

      final tempFile = File(localFilePath);
      final fileWriteWatch = Stopwatch()..start();

      await tempFile.writeAsBytes(
        audioResponse.bodyBytes,
        flush: true,
      );

      fileWriteWatch.stop();

      aiTtsTempFiles.add(localFilePath);

      if (isCameraPageDisposing || !mounted) {
        await deleteAiTtsTempFile(localFilePath);
        return null;
      }

      totalWatch.stop();

      debugPrint(
        '⚡ AI TTS PREFETCH CİHAZDA HAZIR '
        '#${job.performanceRunId ?? '-'} '
        '| prepare=${prepareWatch.elapsedMilliseconds}ms '
        '| download=${downloadWatch.elapsedMilliseconds}ms '
        '| dosyaYazma=${fileWriteWatch.elapsedMilliseconds}ms '
        '| toplam=${totalWatch.elapsedMilliseconds}ms '
        '| bytes=${audioResponse.bodyBytes.length} '
        '| cached=$cached '
        '| streaming=$streaming '
        '| cacheSource=${cacheSource ?? '-'} '
        '| voice=$voiceName',
      );

      return AiTtsPreparedAudio(
        localFilePath: localFilePath,
        byteLength: audioResponse.bodyBytes.length,
        cached: cached,
        streaming: streaming,
        cacheSource: cacheSource,
        voiceId: voiceId,
        voiceName: voiceName,
        prepareMs: prepareWatch.elapsedMilliseconds,
        downloadMs: downloadWatch.elapsedMilliseconds,
        fileWriteMs: fileWriteWatch.elapsedMilliseconds,
        totalMs: totalWatch.elapsedMilliseconds,
      );
    } on TimeoutException catch (e) {
      totalWatch.stop();

      if (localFilePath != null) {
        await deleteAiTtsTempFile(localFilePath);
      }

      debugPrint(
        '⚡ AI TTS PREFETCH ZAMAN AŞIMI '
        '#${job.performanceRunId ?? '-'} | $e',
      );

      return null;
    } catch (e, stackTrace) {
      totalWatch.stop();

      if (localFilePath != null) {
        await deleteAiTtsTempFile(localFilePath);
      }

      debugPrint(
        '⚡ AI TTS PREFETCH HATASI '
        '#${job.performanceRunId ?? '-'} | $e',
      );
      debugPrint('$stackTrace');

      return null;
    }
  }

  Future<void> maybePreloadNextAiTts() async {
    if (isCameraPageDisposing ||
        !mounted ||
        isAiStandbyLoading ||
        aiStandbySpeechKey != null ||
        speechQueue.isEmpty) {
      return;
    }

    final nextJob = speechQueue.first;

    if (!canUseAiTtsForJob(nextJob)) {
      return;
    }

    final prefetchFuture = aiTtsPrefetchInFlight[nextJob.uniqueSpeechKey];

    if (prefetchFuture == null) {
      return;
    }

    isAiStandbyLoading = true;

    try {
      final prepared = await prefetchFuture;

      if (prepared == null || isCameraPageDisposing || !mounted) {
        return;
      }

      // Await sırasında kuyruk ilerlediyse artık yanlış repliği preload etme.
      if (speechQueue.isEmpty ||
          speechQueue.first.uniqueSpeechKey != nextJob.uniqueSpeechKey) {
        return;
      }

      final file = File(prepared.localFilePath);

      if (!await file.exists()) {
        return;
      }

      final preloadWatch = Stopwatch()..start();

      // Bu işlem sesi çalmaz. AVPlayer yalnızca dosyayı/source'u şimdiden
      // hazırlar. Gerçek sıra geldiğinde resume() ile başlatılır.
      await aiStandbyAudioPlayer
          .setSource(
            DeviceFileSource(
              prepared.localFilePath,
              mimeType: 'audio/mpeg',
            ),
          )
          .timeout(aiTtsPlaybackStartupTimeout);

      preloadWatch.stop();

      if (isCameraPageDisposing || !mounted) {
        return;
      }

      // Source hazırlanırken kuyruk değiştiyse bu preload'u kullanma.
      if (speechQueue.isEmpty ||
          speechQueue.first.uniqueSpeechKey != nextJob.uniqueSpeechKey) {
        return;
      }

      aiStandbySpeechKey = nextJob.uniqueSpeechKey;
      aiStandbyFilePath = prepared.localFilePath;

      debugPrint(
        '🚀 AI TTS NEXT PLAYER PRELOAD HAZIR '
        '#${nextJob.performanceRunId ?? '-'} '
        '| sourceHazırlama=${preloadWatch.elapsedMilliseconds}ms '
        '| bytes=${prepared.byteLength} '
        '| cached=${prepared.cached} '
        '| voice=${prepared.voiceName}',
      );
    } on TimeoutException catch (e) {
      debugPrint(
        '🚀 AI TTS NEXT PLAYER PRELOAD ZAMAN AŞIMI '
        '#${nextJob.performanceRunId ?? '-'} | $e',
      );
    } catch (e, stackTrace) {
      debugPrint(
        '🚀 AI TTS NEXT PLAYER PRELOAD HATASI '
        '#${nextJob.performanceRunId ?? '-'} | $e',
      );
      debugPrint('$stackTrace');
    } finally {
      isAiStandbyLoading = false;
    }
  }

  Future<bool> playAiTtsJob(
    SpeechJob job, {
    required int queueWaitMs,
  }) async {
    if (!canUseAiTtsForJob(job) || isCameraPageDisposing) {
      return false;
    }

    final aiRequestWatch = Stopwatch()..start();

    StreamSubscription<Duration>? positionSubscription;
    StreamSubscription<void>? completionSubscription;

    final playbackStarted = Completer<int>();
    final playbackCompleted = Completer<void>();

    AiTtsPreparedAudio? prefetchedAudio;
    AudioPlayer playerForJob = aiAudioPlayer;
    bool usedDoubleBuffer = false;

    try {
      final prefetchFuture = aiTtsPrefetchInFlight[job.uniqueSpeechKey];

      if (prefetchFuture != null) {
        final prefetchWaitWatch = Stopwatch()..start();

        prefetchedAudio = await prefetchFuture;

        if (isCameraPageDisposing || !mounted) {
          return false;
        }

        prefetchWaitWatch.stop();

        debugPrint(
          '⚡ AI TTS PREFETCH SIRASI GELDİ '
          '#${job.performanceRunId ?? '-'} '
          '| ekBekleme=${prefetchWaitWatch.elapsedMilliseconds}ms '
          '| hazır=${prefetchedAudio != null} '
          '| kuyrukBekleme=${queueWaitMs}ms',
        );
      }

      late final String audioUrl;
      late final bool cached;
      late final bool streaming;
      late final String? cacheSource;
      late final String voiceName;
      late final int prepareMs;

      if (prefetchedAudio != null) {
        audioUrl = '';
        cached = prefetchedAudio.cached;
        streaming = prefetchedAudio.streaming;
        cacheSource = prefetchedAudio.cacheSource;
        voiceName = prefetchedAudio.voiceName;
        prepareMs = prefetchedAudio.prepareMs;

        debugPrint(
          '🤖 AI TTS HAZIR '
          '#${job.performanceRunId ?? '-'} '
          '| prepare=${prefetchedAudio.prepareMs}ms '
          '| prefetched=true '
          '| cihazDosyası=true '
          '| prefetchToplam=${prefetchedAudio.totalMs}ms '
          '| cached=$cached '
          '| streaming=$streaming '
          '| cacheSource=${cacheSource ?? '-'} '
          '| voice=$voiceName',
        );
      } else {
        final prepareWatch = Stopwatch()..start();

        final data = await prepareAiTts(job);

        if (isCameraPageDisposing || !mounted) {
          return false;
        }

        prepareWatch.stop();

        audioUrl = data['audioUrl']?.toString().trim() ?? '';
        cached = data['cached'] == true;
        streaming = data['streaming'] == true;
        cacheSource = data['cacheSource']?.toString();
        voiceName = resolveAiVoiceName(data);
        prepareMs = prepareWatch.elapsedMilliseconds;

        debugPrint(
          '🤖 AI TTS HAZIR '
          '#${job.performanceRunId ?? '-'} '
          '| prepare=${prepareWatch.elapsedMilliseconds}ms '
          '| prefetched=false '
          '| cached=$cached '
          '| streaming=$streaming '
          '| cacheSource=${cacheSource ?? '-'} '
          '| voice=$voiceName',
        );
      }

      if (isCameraPageDisposing || !mounted) {
        return false;
      }

      // Eğer sıradaki replik ikinci player'a daha önce setSource ile
      // yüklenmişse, artık dosya/URL hazırlığı yapmıyoruz.
      usedDoubleBuffer =
          prefetchedAudio != null &&
          aiStandbySpeechKey == job.uniqueSpeechKey &&
          aiStandbyFilePath == prefetchedAudio.localFilePath;

      if (usedDoubleBuffer) {
        playerForJob = aiStandbyAudioPlayer;
      } else {
        playerForJob = aiAudioPlayer;

        // Normal akışta aktif player'ın önceki kaynağını temizle.
        try {
          await playerForJob.stop();
        } catch (e) {
          if (isCameraPageDisposing || !mounted) {
            return false;
          }
          rethrow;
        }
      }

      if (isCameraPageDisposing || !mounted) {
        return false;
      }

      positionSubscription = playerForJob.onPositionChanged.listen((position) {
        if (position <= Duration.zero || playbackStarted.isCompleted) {
          return;
        }

        final requestToPlaybackMs = aiRequestWatch.elapsedMilliseconds;

        playbackStarted.complete(requestToPlaybackMs);

        if (mounted && !isCameraPageDisposing) {
          setState(() {
            isSpeaking = true;
          });
        }

        final scanToPlaybackMs =
            job.pipelineElapsedAtQueueMs +
            queueWaitMs +
            requestToPlaybackMs;

        debugPrint(
          '🔊 AI TTS PLAYBACK BAŞLADI '
          '#${job.performanceRunId ?? '-'} '
          '| AIistek→ses=${requestToPlaybackMs}ms '
          '| tarama→ses≈${scanToPlaybackMs}ms '
          '| position=${position.inMilliseconds}ms '
          '| prefetched=${prefetchedAudio != null} '
          '| doubleBuffer=$usedDoubleBuffer '
          '| cached=$cached '
          '| voice=$voiceName',
        );
      });

      completionSubscription = playerForJob.onPlayerComplete.listen((_) {
        if (!playbackStarted.isCompleted) {
          playbackStarted.complete(aiRequestWatch.elapsedMilliseconds);
        }

        if (!playbackCompleted.isCompleted) {
          playbackCompleted.complete();
        }
      });

      final playCommandWatch = Stopwatch()..start();

      if (isCameraPageDisposing || !mounted) {
        return false;
      }

      if (usedDoubleBuffer) {
        // Source zaten ikinci player'a yüklendi. Sadece başlat.
        await playerForJob
            .resume()
            .timeout(aiTtsPlaybackStartupTimeout);

        // Şu anda oynayan standby artık aktif player olur.
        // Önceki aktif player ise bir sonraki repliği preload etmek için
        // boş standby player'a dönüşür.
        final previousActivePlayer = aiAudioPlayer;

        aiAudioPlayer = playerForJob;
        aiStandbyAudioPlayer = previousActivePlayer;
        aiStandbySpeechKey = null;
        aiStandbyFilePath = null;

        debugPrint(
          '🚀 AI TTS DOUBLE BUFFER DEVREDE '
          '#${job.performanceRunId ?? '-'} '
          '| yalnızca resume() ile başlatıldı',
        );
      } else if (prefetchedAudio != null) {
        // Ses cihazda .mp3 olarak hazır fakat AVPlayer source preload'u
        // yetişmediyse yine ağ kullanmadan yerel dosyadan oynat.
        await playerForJob
            .play(
              DeviceFileSource(
                prefetchedAudio.localFilePath,
                mimeType: 'audio/mpeg',
              ),
              volume: 1.0,
            )
            .timeout(aiTtsPlaybackStartupTimeout);
      } else {
        // Kuyruk boşken gelen ilk replik: en hızlı başlangıç için mevcut
        // progressive URL/stream davranışı korunuyor.
        await playerForJob
            .play(
              UrlSource(audioUrl),
              volume: 1.0,
            )
            .timeout(aiTtsPlaybackStartupTimeout);
      }

      playCommandWatch.stop();

      debugPrint(
        '🤖 AI TTS PLAYER KOMUTU '
        '#${job.performanceRunId ?? '-'} '
        '| playFuture=${playCommandWatch.elapsedMilliseconds}ms '
        '| prefetched=${prefetchedAudio != null} '
        '| doubleBuffer=$usedDoubleBuffer',
      );

      // Mevcut ses başlatıldı. Aynı anda sıradaki repliği ikinci player'a
      // preload etmeye çalış. Bu işlem konuşmayı bloklamaz.
      unawaited(maybePreloadNextAiTts());

      final requestToPlaybackMs = await playbackStarted.future.timeout(
        aiTtsPlaybackStartupTimeout,
      );

      final scanToPlaybackMs =
          job.pipelineElapsedAtQueueMs +
          queueWaitMs +
          requestToPlaybackMs;

      debugPrint(
        '⏱ AI TTS GERÇEK BAŞLANGIÇ '
        '#${job.performanceRunId ?? '-'} '
        '| prepare=${prepareMs}ms '
        '| AIistek→playback=${requestToPlaybackMs}ms '
        '| tarama→playback≈${scanToPlaybackMs}ms '
        '| prefetched=${prefetchedAudio != null} '
        '| doubleBuffer=$usedDoubleBuffer '
        '| cached=$cached',
      );

      await playbackCompleted.future.timeout(
        aiTtsPlaybackCompletionTimeout,
      );

      aiRequestWatch.stop();

      debugPrint(
        '🤖 AI TTS TAMAMLANDI '
        '#${job.performanceRunId ?? '-'} '
        '| toplam=${aiRequestWatch.elapsedMilliseconds}ms '
        '| ${job.speaker} '
        '| prefetched=${prefetchedAudio != null} '
        '| doubleBuffer=$usedDoubleBuffer '
        '| voice=$voiceName',
      );

      if (mounted && !isCameraPageDisposing) {
        setState(() {
          isSpeaking = false;
        });
      }

      return true;
    } on TimeoutException catch (e) {
      debugPrint(
        '🤖 AI TTS ZAMAN AŞIMI -> DEVICE TTS FALLBACK '
        '#${job.performanceRunId ?? '-'} | $e',
      );

      try {
        await playerForJob.stop();
      } catch (_) {}

      if (mounted && !isCameraPageDisposing) {
        setState(() {
          isSpeaking = false;
        });
      }

      return false;
    } catch (e, stackTrace) {
      debugPrint(
        '🤖 AI TTS HATASI -> DEVICE TTS FALLBACK '
        '#${job.performanceRunId ?? '-'} | $e',
      );
      debugPrint('$stackTrace');

      try {
        await playerForJob.stop();
      } catch (_) {}

      if (mounted && !isCameraPageDisposing) {
        setState(() {
          isSpeaking = false;
        });
      }

      return false;
    } finally {
      aiRequestWatch.stop();

      aiTtsPrefetchInFlight.remove(job.uniqueSpeechKey);

      await positionSubscription?.cancel();
      await completionSubscription?.cancel();

      // Bu repliğin dosyası artık kullanıldı. Player tamamlandıktan/fallback
      // sonrasında geçici MP3'ü cihazdan temizle.
      if (prefetchedAudio != null) {
        await deleteAiTtsTempFile(prefetchedAudio.localFilePath);
      }

      // Bir sonraki replik prefetch'i bu sırada bitmiş olabilir.
      if (!isCameraPageDisposing && mounted) {
        unawaited(maybePreloadNextAiTts());
      }
    }
  }

  Future<void> playDeviceTtsJob(
    SpeechJob job, {
    required int queueWaitMs,
  }) async {
    if (!isTtsReady) {
      debugPrint(
        'DEVICE TTS FALLBACK ATLANDI: '
        'TTS motoru henüz hazır değil.',
      );
      return;
    }

    Stopwatch? speechWatch;
    int metricLatencyMs = queueWaitMs;

    try {
      final voiceSetupWatch = Stopwatch()..start();

      var deviceVoice = job.voice;

      // AI primary işlerde cihaz sesi bilerek önceden seçilmez.
      // Fallback gerçekten gerekirse burada, tam zamanında seç.
      if (deviceVoice == null &&
          job.speaker != 'ANONİM' &&
          !isGenericSpeakerLabel(job.speaker)) {
        deviceVoice = await getOrAssignVoiceForSpeaker(
          job.speaker,
          job.profile,
        );
      }

      deviceVoice ??= await getFallbackVoiceForUnknownSpeaker();

      // TTS motor ayarlarına yalnızca bu worker dokunur.
      await applyVoice(
        deviceVoice,
        profile: job.profile,
        emotion: job.emotion,
      );

      voiceSetupWatch.stop();

      debugPrint(
        '⏱ DEVICE TTS FALLBACK '
        '#${job.performanceRunId ?? '-'} '
        'SES AYARLARI'
        ' | aşama=${voiceSetupWatch.elapsedMilliseconds}ms'
        ' | kuyrukBekleme=${queueWaitMs}ms'
        ' | duygu=${job.emotion.label}',
      );

      debugPrint('KONUŞMACI: ${job.speaker}');

      debugPrint(
        'KARAKTER: '
        '${job.profile.matchedName ?? 'Bilinmiyor'} / '
        '${job.profile.gender}',
      );

      debugPrint('SES: ${deviceVoice?.name ?? 'Varsayılan'}');

      debugPrint('DUYGU: ${job.emotion.label}');

      debugPrint('TTS METNİ: ${job.ttsText}');

      final estimatedScanToCommandMs =
          job.pipelineElapsedAtQueueMs +
          queueWaitMs +
          voiceSetupWatch.elapsedMilliseconds;

      metricLatencyMs = estimatedScanToCommandMs;

      debugPrint(
        '⏱ DEVICE TTS '
        '#${job.performanceRunId ?? '-'} '
        'TTS KOMUTU GÖNDERİLİYOR'
        ' | taramadanToplam≈${estimatedScanToCommandMs}ms'
        ' | metinUzunluğu=${job.ttsText.length}',
      );

      speechWatch = Stopwatch()..start();

      await flutterTts.speak(job.ttsText);

      speechWatch.stop();

      final audioDurationMs = speechWatch.elapsedMilliseconds;

      debugPrint(
        '⏱ DEVICE TTS '
        '#${job.performanceRunId ?? '-'} '
        'TTS KONUŞMA TAMAMLANDI'
        ' | konuşma=${audioDurationMs}ms',
      );

      unawaited(
        recordDeviceTtsMetric(
          job: job,
          audioDurationMs: audioDurationMs,
          latencyMs: metricLatencyMs,
          success: true,
        ),
      );
    } catch (e, stackTrace) {
      if (speechWatch?.isRunning == true) {
        speechWatch?.stop();
      }

      debugPrint('DEVICE TTS OYNATMA HATASI: $e');
      debugPrint('$stackTrace');

      unawaited(
        recordDeviceTtsMetric(
          job: job,
          audioDurationMs: speechWatch?.elapsedMilliseconds ?? 0,
          latencyMs: metricLatencyMs,
          success: false,
          errorCode: e.runtimeType.toString(),
        ),
      );

      if (mounted) {
        setState(() {
          isSpeaking = false;
        });
      }
    }
  }

  // ==========================================================
  // CİHAZ TTS METRİKLERİ
  // ==========================================================
  // iPhone/Android sistem TTS sesini üretmeye devam eder.
  // Backend'e seslendirilen metnin kendisi gönderilmez; yalnızca
  // teknik kullanım bilgileri gönderilir. Telemetri hatası TTS
  // kuyruğunu veya oyun içi seslendirmeyi hiçbir zaman bloklamaz.
  Future<void> recordDeviceTtsMetric({
    required SpeechJob job,
    required int audioDurationMs,
    required int latencyMs,
    required bool success,
    String? errorCode,
  }) async {
    final String? devicePlatform = Platform.isIOS
        ? 'ios'
        : Platform.isAndroid
        ? 'android'
        : null;

    if (devicePlatform == null) {
      return;
    }

    final voiceName = job.voice?.name.trim();

    final characterName = (job.profile.matchedName ?? job.speaker).trim();

    try {
      final uri = Uri.parse('$backendBaseUrl/metrics/tts');

      final response = await http
          .post(
            uri,
            headers: const {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: jsonEncode({
              'devicePlatform': devicePlatform,
              'gameId': widget.game.id,
              'gameName': widget.game.name,
              'voiceKey': voiceName == null || voiceName.isEmpty
                  ? 'system-default'
                  : voiceName,
              'characterName': characterName.isEmpty ? null : characterName,
              'textCharCount': job.ttsText.length,
              'audioDurationMs': audioDurationMs,
              'latencyMs': latencyMs,
              'success': success,
              if (!success) 'errorCode': errorCode ?? 'device_tts_error',
            }),
          )
          .timeout(const Duration(seconds: 4));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        debugPrint(
          'TTS METRİK HTTP HATASI: '
          '${response.statusCode}',
        );
        return;
      }

      debugPrint(
        'TTS METRİK GÖNDERİLDİ: '
        '$devicePlatform | '
        '${voiceName ?? 'system-default'} | '
        '${characterName.isEmpty ? job.speaker : characterName} | '
        'ses=${audioDurationMs}ms | '
        'gecikme=${latencyMs}ms | '
        'başarılı=$success',
      );
    } catch (e) {
      // Telemetri hiçbir koşulda gerçek seslendirmeyi bozmasın.
      debugPrint('TTS METRİK GÖNDERME HATASI: $e');
    }
  }

  Future<void> processSpeechQueue() async {
    if (isSpeechWorkerRunning || isCameraPageDisposing) {
      return;
    }

    isSpeechWorkerRunning = true;

    try {
      while (speechQueue.isNotEmpty && !isCameraPageDisposing) {
        final job = speechQueue.removeAt(0);

        queuedSpeechKeys.remove(job.uniqueSpeechKey);

        currentSpeechKey = job.uniqueSpeechKey;

        final queueWaitMs = DateTime.now()
            .difference(job.enqueuedAt)
            .inMilliseconds;

        try {
          var aiPlaybackCompleted = false;

          if (canUseAiTtsForJob(job)) {
            debugPrint(
              '🤖 AI TTS PRIMARY '
              '#${job.performanceRunId ?? '-'} '
              '| ${job.speaker} '
              '| ${job.profile.gender} '
              '| kuyrukBekleme=${queueWaitMs}ms',
            );

            aiPlaybackCompleted = await playAiTtsJob(
              job,
              queueWaitMs: queueWaitMs,
            );
          }

          if (!aiPlaybackCompleted && !isCameraPageDisposing) {
            debugPrint(
              '🔁 DEVICE TTS DEVREDE '
              '#${job.performanceRunId ?? '-'} '
              '| reason=${canUseAiTtsForJob(job) ? 'ai_failed_or_slow' : 'ai_not_eligible'}',
            );

            await playDeviceTtsJob(
              job,
              queueWaitMs: queueWaitMs,
            );
          }
        } finally {
          if (currentSpeechKey == job.uniqueSpeechKey) {
            currentSpeechKey = null;
          }
        }
      }
    } finally {
      isSpeechWorkerRunning = false;

      // Tam worker kapanırken yeni iş eklendiyse onu kaçırma.
      if (speechQueue.isNotEmpty && !isCameraPageDisposing) {
        unawaited(processSpeechQueue());
      }
    }
  }

  Future<void> scanCurrentFrame() async {
    final controller = cameraController;

    if (controller == null ||
        !controller.value.isInitialized ||
        isProcessingImage ||
        controller.value.isTakingPicture) {
      return;
    }

    isProcessingImage = true;

    final runId = ++performanceRunId;

    final totalWatch = Stopwatch()..start();

    activePerformanceRunId = runId;

    activePerformanceTotalWatch = totalWatch;

    logPerformance('TARAMA BAŞLADI');

    XFile? originalImage;
    File? croppedImage;

    try {
      final captureWatch = Stopwatch()..start();

      originalImage = await controller.takePicture();

      captureWatch.stop();

      logPerformance(
        'KAMERA FOTOĞRAF',
        durationMs: captureWatch.elapsedMilliseconds,
      );

      final cropWatch = Stopwatch()..start();

      croppedImage = await cropSubtitleRegion(originalImage);

      cropWatch.stop();

      logPerformance('GÖRSEL CROP', durationMs: cropWatch.elapsedMilliseconds);

      final inputImage = InputImage.fromFilePath(croppedImage.path);

      final ocrWatch = Stopwatch()..start();

      final result = await textRecognizer.processImage(inputImage);

      ocrWatch.stop();

      logPerformance('OCR', durationMs: ocrWatch.elapsedMilliseconds);

      final text = result.text.trim();

      debugPrint('OCR HAM METİN:\n$text');

      if (!mounted) return;

      if (text.isEmpty) {
        setState(() {
          recognizedText = 'Tarama alanında metin algılanmadı...';
        });
      } else {
        setState(() {
          recognizedText = text;
        });

        await translateRecognizedText(text);
      }
    } catch (e, stackTrace) {
      debugPrint('OCR HATASI: $e');
      debugPrint('$stackTrace');

      if (mounted) {
        setState(() {
          recognizedText = 'OCR hatası:\n$e';
        });
      }
    } finally {
      if (originalImage != null) {
        try {
          final file = File(originalImage.path);

          if (await file.exists()) {
            await file.delete();
          }
        } catch (_) {}
      }

      if (croppedImage != null) {
        try {
          if (await croppedImage.exists()) {
            await croppedImage.delete();
          }
        } catch (_) {}
      }

      totalWatch.stop();

      logPerformance(
        'TARAMA BİTTİ',
        durationMs: totalWatch.elapsedMilliseconds,
      );

      isProcessingImage = false;

      if (activePerformanceRunId == runId) {
        activePerformanceRunId = null;
        activePerformanceTotalWatch = null;
      }
    }
  }

  Future<void> stopAndDisposeCamera(CameraController controller) async {
    try {
      if (controller.value.isStreamingImages) {
        await controller.stopImageStream();
      }
    } catch (e) {
      debugPrint('CANLI KAMERA DURDURMA NOTU: $e');
    }

    try {
      await controller.dispose();
    } catch (e) {
      debugPrint('KAMERA DISPOSE NOTU: $e');
    }
  }

  @override
  void dispose() {
    isCameraPageDisposing = true;
    if (tvRelayEnabled) TvLinkHub.instance.client.clear();

    ocrTimer?.cancel();
    cameraZoomDebounceTimer?.cancel();
    demoUsageTimer?.cancel();
    demoUsageTimer = null;

    if (isDemoUsageLoaded) {
      unawaited(FreeTranslationTrialStore.saveUsedSeconds(demoUsedSeconds));
    }

    clearPendingOcrCandidate();

    // Yeni iş kabul etmeyi bırak ve henüz konuşmamış altyazıları temizle.
    speechQueue.clear();
    queuedSpeechKeys.clear();
    aiTtsPrefetchInFlight.clear();
    currentSpeechKey = null;

    aiStandbySpeechKey = null;
    aiStandbyFilePath = null;

    // Oynatılmadan kalan prefetch dosyalarını da cihazdan temizle.
    final tempFilesToDelete = List<String>.from(aiTtsTempFiles);
    aiTtsTempFiles.clear();

    for (final path in tempFilesToDelete) {
      unawaited(deleteAiTtsTempFile(path));
    }

    flutterTts.stop();
    unawaited(aiAudioPlayer.dispose());
    unawaited(aiStandbyAudioPlayer.dispose());

    final controller = cameraController;

    cameraController = null;

    if (controller != null) {
      unawaited(stopAndDisposeCamera(controller));
    }

    textRecognizer.close();
    translator.close();

    // Canlı çeviri ekranından çıkınca uygulamanın geri kalanı yeniden
    // yalnızca dikey moda döner.
    unawaited(_restorePortraitOrientation());

    super.dispose();
  }

  Widget buildScanResizeHandle({
    required Alignment alignment,
    required Size canvasSize,
    required bool resizeLeft,
    required bool resizeTop,
  }) {
    return Align(
      alignment: alignment,
      child: GestureDetector(
        behavior:
            HitTestBehavior.opaque,
        onPanUpdate:
            (details) {
          resizeScanArea(
            details,
            canvasSize,
            resizeLeft:
                resizeLeft,
            resizeTop:
                resizeTop,
          );
        },
        child: SizedBox(
          width: 38,
          height: 38,
          child: Center(
            child: Container(
              width: 16,
              height: 16,
              decoration:
                  BoxDecoration(
                color: Colors.white,
                borderRadius:
                    BorderRadius.circular(
                  5,
                ),
                border: Border.all(
                  color:
                      const Color(
                    0xFF7C5CFF,
                  ),
                  width: 3,
                ),
                boxShadow: const [
                  BoxShadow(
                    color:
                        Colors.black54,
                    blurRadius: 5,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildScanAreaOverlay() {
    return Positioned.fill(
      child: IgnorePointer(
        ignoring:
            !isEditingScanArea,
        child: LayoutBuilder(
          builder:
              (
            context,
            constraints,
          ) {
            final width =
                constraints.maxWidth;

            final height =
                constraints.maxHeight;

            final canvasSize =
                Size(
              width,
              height,
            );

            final rectWidth =
                width *
                (
                  scanRightFactor -
                  scanLeftFactor
                );

            final rectHeight =
                height *
                (
                  scanBottomFactor -
                  scanTopFactor
                );

            return Stack(
              children: [
                if (isEditingScanArea)
                  Positioned.fill(
                    child: Container(
                      color:
                          Colors.black12,
                    ),
                  ),
                Positioned(
                  left:
                      width *
                      scanLeftFactor,
                  top:
                      height *
                      scanTopFactor,
                  width:
                      rectWidth,
                  height:
                      rectHeight,
                  child:
                      GestureDetector(
                    behavior:
                        HitTestBehavior
                            .translucent,
                    onPanUpdate:
                        isEditingScanArea
                            ? (
                                details,
                              ) {
                                moveScanArea(
                                  details,
                                  canvasSize,
                                );
                              }
                            : null,
                    child: Container(
                      decoration:
                          BoxDecoration(
                        color:
                            isEditingScanArea
                                ? const Color(
                                    0x147C5CFF,
                                  )
                                : Colors
                                    .transparent,
                        borderRadius:
                            BorderRadius
                                .circular(
                          16,
                        ),
                        border:
                            Border.all(
                          color:
                              const Color(
                            0xFF7C5CFF,
                          ),
                          width:
                              isEditingScanArea
                                  ? 3.0
                                  : 2.5,
                        ),
                      ),
                      child: Stack(
                        children: [
                          if (isEditingScanArea)
                            const Center(
                              child:
                                  Column(
                                mainAxisSize:
                                    MainAxisSize
                                        .min,
                                children: [
                                  Icon(
                                    Icons
                                        .open_with_rounded,
                                    color:
                                        Colors.white70,
                                    size: 26,
                                  ),
                                  SizedBox(
                                    height: 4,
                                  ),
                                  Text(
                                    'Sürükle',
                                    style:
                                        TextStyle(
                                      color:
                                          Colors.white70,
                                      fontSize:
                                          12,
                                      fontWeight:
                                          FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          if (isEditingScanArea) ...[
                            buildScanResizeHandle(
                              alignment:
                                  Alignment
                                      .topLeft,
                              canvasSize:
                                  canvasSize,
                              resizeLeft:
                                  true,
                              resizeTop:
                                  true,
                            ),
                            buildScanResizeHandle(
                              alignment:
                                  Alignment
                                      .topRight,
                              canvasSize:
                                  canvasSize,
                              resizeLeft:
                                  false,
                              resizeTop:
                                  true,
                            ),
                            buildScanResizeHandle(
                              alignment:
                                  Alignment
                                      .bottomLeft,
                              canvasSize:
                                  canvasSize,
                              resizeLeft:
                                  true,
                              resizeTop:
                                  false,
                            ),
                            buildScanResizeHandle(
                              alignment:
                                  Alignment
                                      .bottomRight,
                              canvasSize:
                                  canvasSize,
                              resizeLeft:
                                  false,
                              resizeTop:
                                  false,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  bool _cameraTranscriptExpanded = true;

  Future<void> _showCameraSettings() async {
    bool isZoomDragging = false;

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.transparent,
      isScrollControlled: true,
      showDragHandle: false,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, refreshSheet) {
          final sliderPosition =
              _zoomSliderPositionFromLevel(currentCameraZoom);

          return SafeArea(
            top: false,
            child: FractionallySizedBox(
              heightFactor: 0.72,
              child: AnimatedOpacity(
                opacity: isZoomDragging ? 0.28 : 1.0,
                duration: const Duration(milliseconds: 120),
                curve: Curves.easeOut,
                child: Container(
                  decoration: BoxDecoration(
                    color: isZoomDragging
                        ? const Color(0x99111116)
                        : const Color(0xFF111116),
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  child: Column(
                  children: [
                    const SizedBox(height: 10),
                    Container(
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                        20,
                        16,
                        14,
                        10,
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: const Color(0xFF211C35),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: const Color(0x557C5CFF),
                              ),
                            ),
                            child: const Icon(
                              Icons.tune_rounded,
                              color: Color(0xFFB9AAFF),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Çeviri Kontrolleri',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.35,
                                  ),
                                ),
                                SizedBox(height: 3),
                                Text(
                                  'Kamera ve altyazı görünümünü ayarla',
                                  style: TextStyle(
                                    color: Colors.white38,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: () =>
                                Navigator.pop(sheetContext),
                            icon: const Icon(
                              Icons.close_rounded,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(
                      height: 1,
                      color: Color(0xFF24242C),
                    ),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(
                          20,
                          18,
                          20,
                          24,
                        ),
                        children: [
                          Container(
                            padding: const EdgeInsets.fromLTRB(
                              16,
                              16,
                              16,
                              14,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFF18181E),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: const Color(0xFF282831),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 38,
                                      height: 38,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF252136),
                                        borderRadius:
                                            BorderRadius.circular(12),
                                      ),
                                      child: const Icon(
                                        Icons.zoom_in_rounded,
                                        size: 21,
                                        color: Color(0xFFB9AAFF),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    const Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Kamera yakınlaştırma',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                              fontWeight:
                                                  FontWeight.w700,
                                            ),
                                          ),
                                          SizedBox(height: 2),
                                          Text(
                                            'Daha hassas kontrol',
                                            style: TextStyle(
                                              color: Colors.white38,
                                              fontSize: 11,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      padding:
                                          const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF211C35),
                                        borderRadius:
                                            BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        '${currentCameraZoom.toStringAsFixed(1)}×',
                                        style: const TextStyle(
                                          color: Color(0xFFD8D0FF),
                                          fontSize: 14,
                                          fontWeight:
                                              FontWeight.w800,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 14),
                                SliderTheme(
                                  data: SliderTheme.of(
                                    sheetContext,
                                  ).copyWith(
                                    activeTrackColor:
                                        const Color(0xFF7C5CFF),
                                    inactiveTrackColor:
                                        const Color(0xFF32323A),
                                    thumbColor:
                                        const Color(0xFFB9AAFF),
                                    overlayColor:
                                        const Color(0x227C5CFF),
                                    trackHeight: 5,
                                    thumbShape:
                                        const RoundSliderThumbShape(
                                      enabledThumbRadius: 8,
                                    ),
                                  ),
                                  child: Slider(
                                    value: sliderPosition,
                                    min: 0,
                                    max: 1,
                                    divisions: 100,
                                    onChangeStart:
                                        isCameraZoomReady
                                            ? (_) {
                                                isZoomDragging = true;
                                                refreshSheet(() {});
                                              }
                                            : null,
                                    onChanged:
                                        isCameraZoomReady
                                            ? (position) {
                                                final zoom =
                                                    _zoomLevelFromSliderPosition(
                                                  position,
                                                );

                                                previewCameraZoom(
                                                  zoom,
                                                );

                                                refreshSheet(
                                                  () {},
                                                );
                                              }
                                            : null,
                                    onChangeEnd:
                                        isCameraZoomReady
                                            ? (position) {
                                                final zoom =
                                                    _zoomLevelFromSliderPosition(
                                                  position,
                                                );

                                                isZoomDragging = false;
                                                refreshSheet(() {});

                                                unawaited(
                                                  commitCameraZoom(
                                                    zoom,
                                                  ),
                                                );
                                              }
                                            : null,
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      '${minCameraZoom.toStringAsFixed(1)}×',
                                      style: const TextStyle(
                                        color: Colors.white30,
                                        fontSize: 10,
                                      ),
                                    ),
                                    Text(
                                      isCameraZoomReady
                                          ? 'Bu oyun için kaydedilir'
                                          : 'Kamera hazırlanıyor…',
                                      style: const TextStyle(
                                        color: Colors.white30,
                                        fontSize: 10,
                                      ),
                                    ),
                                    Text(
                                      '${maxCameraZoom.toStringAsFixed(1)}×',
                                      style: const TextStyle(
                                        color: Colors.white30,
                                        fontSize: 10,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          Material(
                            color: const Color(0xFF18181E),
                            shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(20),
                              side: const BorderSide(
                                color: Color(0xFF282831),
                              ),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                              onTap: isSavingScanArea
                                  ? null
                                  : () {
                                      Navigator.pop(
                                        sheetContext,
                                      );

                                      if (isEditingScanArea) {
                                        unawaited(
                                          saveScanAreaForGame(),
                                        );
                                      } else {
                                        startEditingScanArea();
                                      }
                                    },
                              child: const Padding(
                                padding: EdgeInsets.all(16),
                                child: Row(
                                  children: [
                                    _CameraMenuIcon(
                                      icon:
                                          Icons.crop_free_rounded,
                                    ),
                                    SizedBox(width: 13),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Tarama alanını ayarla',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 14,
                                              fontWeight:
                                                  FontWeight.w700,
                                            ),
                                          ),
                                          SizedBox(height: 3),
                                          Text(
                                            'Altyazının bulunduğu bölgeyi seç',
                                            style: TextStyle(
                                              color: Colors.white38,
                                              fontSize: 11,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Icon(
                                      Icons.chevron_right_rounded,
                                      color: Colors.white30,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFF18181E),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: const Color(0xFF282831),
                              ),
                            ),
                            child: Column(
                              children: [
                                SwitchListTile.adaptive(
                                  contentPadding:
                                      const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 2,
                                  ),
                                  secondary: const _CameraMenuIcon(
                                    icon:
                                        Icons.closed_caption_rounded,
                                  ),
                                  title: const Text(
                                    'İngilizce altyazı',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  subtitle: const Text(
                                    'Kameranın okuduğu özgün metin',
                                    style: TextStyle(
                                      color: Colors.white38,
                                      fontSize: 11,
                                    ),
                                  ),
                                  value: showEnglishText,
                                  activeThumbColor:
                                      const Color(0xFF7C5CFF),
                                  onChanged: (value) {
                                    setState(() {
                                      showEnglishText = value;
                                      _cameraTranscriptExpanded =
                                          true;
                                    });

                                    refreshSheet(() {});
                                  },
                                ),
                                const Divider(
                                  height: 1,
                                  color: Color(0xFF282831),
                                ),
                                SwitchListTile.adaptive(
                                  contentPadding:
                                      const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 2,
                                  ),
                                  secondary: const _CameraMenuIcon(
                                    icon: Icons.translate_rounded,
                                  ),
                                  title: const Text(
                                    'Türkçe çeviri',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  subtitle: const Text(
                                    'Çeviriyi ekranda göster',
                                    style: TextStyle(
                                      color: Colors.white38,
                                      fontSize: 11,
                                    ),
                                  ),
                                  value: showTurkishText,
                                  activeThumbColor:
                                      const Color(0xFF7C5CFF),
                                  onChanged: (value) {
                                    setState(() {
                                      showTurkishText = value;
                                      _cameraTranscriptExpanded =
                                          true;
                                    });

                                    refreshSheet(() {});
                                  },
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          Material(
                            color: const Color(0xFF18181E),
                            shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(20),
                              side: const BorderSide(
                                color: Color(0xFF282831),
                              ),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                              onTap: isLoadingVoices
                                  ? null
                                  : () {
                                      Navigator.pop(
                                        sheetContext,
                                      );

                                      showTurkishVoicesDialog();
                                    },
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Row(
                                  children: [
                                    const _CameraMenuIcon(
                                      icon: Icons
                                          .record_voice_over_rounded,
                                    ),
                                    const SizedBox(width: 13),
                                    const Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Türkçe sesler',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 14,
                                              fontWeight:
                                                  FontWeight.w700,
                                            ),
                                          ),
                                          SizedBox(height: 3),
                                          Text(
                                            'Cihazdaki kullanılabilir sesleri gör',
                                            style: TextStyle(
                                              color: Colors.white38,
                                              fontSize: 11,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if (isLoadingVoices)
                                      const SizedBox(
                                        width: 18,
                                        height: 18,
                                        child:
                                            CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: Color(0xFF7C5CFF),
                                        ),
                                      )
                                    else
                                      const Icon(
                                        Icons.chevron_right_rounded,
                                        color: Colors.white30,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _cameraHeader() {
    final ready = !isLoading && cameraError == null;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: AppDesign.background.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppDesign.border),
      ),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Oyuna dön',
            constraints: const BoxConstraints(minWidth: 48, minHeight: 48),
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_rounded, color: AppDesign.text),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.game.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  isLoading
                      ? 'Kamera hazırlanıyor…'
                      : cameraError != null
                      ? 'Kamera kullanılamıyor'
                      : isEditingScanArea
                      ? 'Tarama alanı düzenleniyor'
                      : !isTranslationRunning
                      ? 'Hazırlık modu · ayarlarını yap ve başlat'
                      : isDemoUsageLoaded && !isPremiumUser
                      ? 'Canlı çeviri · Ücretsiz $demoRemainingLabel'
                      : 'Canlı çeviri',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    color: ready ? AppDesign.primary : AppDesign.muted,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          IconButton(
            tooltip: 'Çeviri ayarları',
            constraints: const BoxConstraints(minWidth: 48, minHeight: 48),
            onPressed: ready ? _showCameraSettings : null,
            icon: const Icon(Icons.tune_rounded),
            color: AppDesign.text,
          ),
        ],
      ),
    );
  }

  Widget _cameraTranscriptPanel({required double maxHeight}) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxHeight),
      child: Container(
        decoration: BoxDecoration(
          color: AppDesign.background.withValues(alpha: 0.96),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppDesign.border),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 8, 10, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    isSpeaking
                        ? Icons.graphic_eq_rounded
                        : Icons.subtitles_outlined,
                    size: 20,
                    color: AppDesign.primary,
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      currentSpeaker != null && currentSpeaker!.isNotEmpty
                          ? currentSpeaker!
                          : 'Canlı altyazı',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: _cameraTranscriptExpanded
                        ? 'Altyazıyı daralt'
                        : 'Altyazıyı genişlet',
                    onPressed: () => setState(
                      () => _cameraTranscriptExpanded =
                          !_cameraTranscriptExpanded,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 48,
                      minHeight: 48,
                    ),
                    icon: Icon(
                      _cameraTranscriptExpanded
                          ? Icons.expand_more_rounded
                          : Icons.expand_less_rounded,
                    ),
                    color: AppDesign.muted,
                  ),
                ],
              ),
              if (_cameraTranscriptExpanded) ...[
                if (showEnglishText) ...[
                  const Text(
                    'İNGİLİZCE',
                    style: TextStyle(
                      color: AppDesign.muted,
                      letterSpacing: 1.3,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    recognizedText,
                    style: const TextStyle(color: AppDesign.muted, height: 1.5),
                  ),
                ],
                if (showEnglishText && showTurkishText)
                  const Divider(height: 26, color: AppDesign.border),
                if (showTurkishText) ...[
                  const Text(
                    'TÜRKÇE',
                    style: TextStyle(
                      color: AppDesign.primary,
                      letterSpacing: 1.3,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    translatedText,
                    style: const TextStyle(
                      color: AppDesign.text,
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                      height: 1.5,
                    ),
                  ),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _cameraActions() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (!isEditingScanArea &&
            !showEnglishText &&
            !showTurkishText &&
            currentSpeaker != null &&
            currentSpeaker!.isNotEmpty)
          Align(
            alignment: Alignment.centerLeft,
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: AppDesign.background.withValues(alpha: 0.94),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppDesign.border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    isSpeaking
                        ? Icons.graphic_eq_rounded
                        : Icons.person_outline_rounded,
                    size: 18,
                    color: AppDesign.primary,
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      currentSpeaker!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        if (isEditingScanArea)
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppDesign.background.withValues(alpha: 0.94),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Text(
              'Çerçeveyi altyazıya taşı. Köşelerinden boyutlandır.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppDesign.text,
                fontSize: 12,
                height: 1.4,
              ),
            ),
          ),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: isSavingScanArea
                    ? null
                    : isEditingScanArea
                    ? saveScanAreaForGame
                    : startEditingScanArea,
                icon: Icon(
                  isEditingScanArea
                      ? Icons.check_rounded
                      : Icons.crop_free_rounded,
                  size: 20,
                ),
                label: Text(
                  isSavingScanArea
                      ? 'Kaydediliyor…'
                      : isEditingScanArea
                      ? 'Alanı kaydet'
                      : 'Tarama alanı',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                style: FilledButton.styleFrom(
                  minimumSize: const Size(0, 52),
                  backgroundColor: AppDesign.primary,
                  foregroundColor: AppDesign.background,
                  disabledBackgroundColor: AppDesign.surfaceRaised,
                  disabledForegroundColor: AppDesign.muted,
                  textStyle: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(17),
                  ),
                ),
              ),
            ),
            if (!isEditingScanArea) ...[
              const SizedBox(width: 10),
              IconButton.filledTonal(
                tooltip: showEnglishText || showTurkishText
                    ? 'Altyazı panelini gizle'
                    : 'Türkçe altyazıyı göster',
                onPressed: () => setState(() {
                  if (showEnglishText || showTurkishText) {
                    showEnglishText = false;
                    showTurkishText = false;
                  } else {
                    showTurkishText = true;
                    _cameraTranscriptExpanded = true;
                  }
                }),
                style: IconButton.styleFrom(
                  minimumSize: const Size(52, 52),
                  backgroundColor: AppDesign.surface,
                  foregroundColor: showEnglishText || showTurkishText
                      ? AppDesign.primary
                      : AppDesign.text,
                  side: const BorderSide(color: AppDesign.border),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(17),
                  ),
                ),
                icon: const Icon(Icons.subtitles_outlined),
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _introCallout({
    required IconData arrow,
    required String title,
    required String body,
    double maxWidth = 280,
  }) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: maxWidth),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xF21A1724),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0x887C5CFF)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x66000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(arrow, color: const Color(0xFFB9AAFF), size: 24),
            const SizedBox(width: 10),
            Flexible(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    body,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 11,
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCameraIntroOverlay() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final landscape = constraints.maxWidth > constraints.maxHeight;

        return ColoredBox(
          color: const Color(0x99000000),
          child: Stack(
            children: [
              Positioned(
                top: landscape ? 68 : 78,
                right: 14,
                child: _introCallout(
                  arrow: Icons.north_east_rounded,
                  title: '1 · Kamera ayarları',
                  body: 'Yakınlaştırmayı ve altyazı görünümünü buradan ayarla.',
                  maxWidth: landscape ? 250 : 270,
                ),
              ),
              Positioned(
                left: landscape ? 18 : 24,
                right: landscape ? 300 : 24,
                top: landscape ? 132 : 245,
                child: _introCallout(
                  arrow: Icons.south_rounded,
                  title: '2 · Mor çerçeve',
                  body:
                      'Tarama alanını yalnızca oyundaki altyazıları kapsayacak şekilde yerleştir.',
                  maxWidth: landscape ? 330 : 360,
                ),
              ),
              Positioned(
                left: 18,
                right: 18,
                bottom: landscape ? 76 : 92,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Flexible(
                      child: _introCallout(
                        arrow: Icons.south_rounded,
                        title: '3 · Hazır olduğunda başlat',
                        body:
                            'Ayarları yapman şart değil. Aşağıdaki Çeviriyi Başlat düğmesine dokunduğun anda OCR ve sesli çeviri çalışır.',
                        maxWidth: landscape ? 430 : 360,
                      ),
                    ),
                    const SizedBox(width: 10),
                    FilledButton(
                      onPressed: dismissCameraIntro,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF7C5CFF),
                        foregroundColor: Colors.white,
                        minimumSize: const Size(92, 48),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text(
                        'Anladım',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final shouldShowTextPanel =
        showEnglishText || showTurkishText;

    final screenHeight =
        MediaQuery.sizeOf(context).height;

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: buildCamera(),
            ),

            // Üst alan artık tek ve sade bir kontrol çubuğu.
            Positioned(
              top: 12,
              left: 14,
              right: 14,
              child: _cameraHeader(),
            ),

            // Tarama alanı düzenlenirken yalnızca gerekli aksiyon görünür.
            if (!isLoading &&
                cameraError == null &&
                isEditingScanArea)
              Positioned(
                left: 18,
                right: 18,
                bottom: 22,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xF2111116),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0x557C5CFF),
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x55000000),
                        blurRadius: 24,
                        offset: Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'Tarama alanını düzenle',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Alanı sürükle veya köşelerden boyutlandır.',
                                style: TextStyle(
                                  color: Colors.white38,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      FilledButton.icon(
                        onPressed: isSavingScanArea
                            ? null
                            : saveScanAreaForGame,
                        style: FilledButton.styleFrom(
                          backgroundColor:
                              const Color(0xFF7C5CFF),
                          foregroundColor: Colors.white,
                          disabledBackgroundColor:
                              const Color(0xFF34343D),
                          shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(14),
                          ),
                          minimumSize: const Size(0, 48),
                          padding:
                              const EdgeInsets.symmetric(
                            horizontal: 15,
                          ),
                        ),
                        icon: isSavingScanArea
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child:
                                    CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(
                                Icons.check_rounded,
                                size: 19,
                              ),
                        label: Text(
                          isSavingScanArea
                              ? 'Kaydediliyor'
                              : 'Kaydet',
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // Kamera önizlemesi ve ayarlar kullanıcıya hemen açıktır;
            // OCR/çeviri ise kullanıcı hazır olduğunda manuel başlatılır.
            if (!isLoading &&
                cameraError == null &&
                !isEditingScanArea &&
                !isTranslationRunning)
              Positioned(
                left: 18,
                right: 18,
                bottom: 20,
                child: FilledButton.icon(
                  onPressed: isStartingTranslation
                      ? null
                      : startTranslationSession,
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF7C5CFF),
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: const Color(0xFF34343D),
                    minimumSize: const Size(0, 58),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  icon: isStartingTranslation
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.play_arrow_rounded, size: 26),
                  label: Text(
                    isStartingTranslation
                        ? 'Başlatılıyor…'
                        : 'Çeviriyi Başlat',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),

            // Konuşmacı etiketi, altyazı kapalıyken de görünür.
            if (!isEditingScanArea &&
                currentSpeaker != null &&
                currentSpeaker!.trim().isNotEmpty)
              Positioned(
                left: 18,
                bottom: shouldShowTextPanel ? 238 : 22,
                child: Container(
                  constraints: BoxConstraints(
                    maxWidth:
                        MediaQuery.sizeOf(context).width * 0.70,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xE8111116),
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(
                      color: const Color(0xFF2A2A32),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.person_rounded,
                        size: 16,
                        color: Color(0xFFB9AAFF),
                      ),
                      const SizedBox(width: 7),
                      Flexible(
                        child: Text(
                          currentSpeaker!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            if (!isEditingScanArea &&
                shouldShowTextPanel)
              Positioned(
                left: 18,
                right: 18,
                bottom: isTranslationRunning ? 20 : 92,
                child: _cameraTranscriptPanel(
                  maxHeight:
                      math.min(205.0, screenHeight * 0.27),
                ),
              ),

            if (isCameraIntroLoaded &&
                showCameraIntro &&
                !isLoading &&
                cameraError == null)
              Positioned.fill(
                child: _buildCameraIntroOverlay(),
              ),
          ],
        ),
      ),
    );
  }

  Widget buildCamera() {
    if (isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (cameraError != null) {
      return Center(
        child: Padding(
          padding:
              const EdgeInsets.all(28),
          child: Text(
            cameraError!,
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    final controller =
        cameraController;

    if (controller == null ||
        !controller.value.isInitialized) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    return Center(
      child: RepaintBoundary(
        child: CameraPreview(
          controller,
          // Çerçeveyi CameraPreview'in kendi AspectRatio alanının içine
          // çiziyoruz. Böylece portrait/landscape fark etmeksizin kullanıcı
          // ekranda hangi dikdörtgeni görüyorsa OCR koordinatları aynı kamera
          // görüntüsü üzerinde o bölgeye karşılık gelir.
          child: buildScanAreaOverlay(),
        ),
      ),
    );
  }
}

class CharacterProfile {
  final bool found;
  final String? matchedName;
  final String gender;

  const CharacterProfile({
    required this.found,
    required this.matchedName,
    required this.gender,
  });

  factory CharacterProfile.fromJson(Map<String, dynamic> json) {
    return CharacterProfile(
      found: json['found'] == true,
      matchedName: json['matchedName']?.toString(),
      gender: json['gender']?.toString().toLowerCase().trim() ?? 'unknown',
    );
  }

  Map<String, dynamic> toJson() {
    return {'found': found, 'matchedName': matchedName, 'gender': gender};
  }
}

class AiTtsPreparedAudio {
  final String localFilePath;
  final int byteLength;
  final bool cached;
  final bool streaming;
  final String? cacheSource;
  final String voiceId;
  final String voiceName;
  final int prepareMs;
  final int downloadMs;
  final int fileWriteMs;
  final int totalMs;

  const AiTtsPreparedAudio({
    required this.localFilePath,
    required this.byteLength,
    required this.cached,
    required this.streaming,
    required this.cacheSource,
    required this.voiceId,
    required this.voiceName,
    required this.prepareMs,
    required this.downloadMs,
    required this.fileWriteMs,
    required this.totalMs,
  });
}

class SpeechJob {
  final String text;
  final String ttsText;
  final String speaker;
  final CharacterProfile profile;
  final TtsVoiceOption? voice;
  final SpeechEmotion emotion;
  final String uniqueSpeechKey;
  final DateTime enqueuedAt;
  final int? performanceRunId;
  final int pipelineElapsedAtQueueMs;

  const SpeechJob({
    required this.text,
    required this.ttsText,
    required this.speaker,
    required this.profile,
    required this.voice,
    required this.emotion,
    required this.uniqueSpeechKey,
    required this.enqueuedAt,
    required this.performanceRunId,
    required this.pipelineElapsedAtQueueMs,
  });
}

class CachedTranslation {
  final String translation;
  final DateTime createdAt;

  const CachedTranslation({required this.translation, required this.createdAt});
}

class EmotionDecision {
  final SpeechEmotion emotion;
  final int confidence;
  final bool explicitCue;

  const EmotionDecision({
    required this.emotion,
    required this.confidence,
    required this.explicitCue,
  });
}

class SpeechEmotion {
  final String type;
  final String label;
  final double speechRate;
  final double pitchMultiplier;
  final double volume;

  const SpeechEmotion({
    required this.type,
    required this.label,
    required this.speechRate,
    required this.pitchMultiplier,
    required this.volume,
  });
}

class DialogueSegment {
  final String? speaker;
  String text;

  DialogueSegment({required this.speaker, required this.text});
}

class TtsVoiceOption {
  final String name;
  final String locale;

  const TtsVoiceOption({required this.name, required this.locale});

  String get key => '$name|$locale';
}

class GameResult {
  final int id;
  final String name;
  final String? coverUrl;
  final int? firstReleaseDate;

  GameResult({
    required this.id,
    required this.name,
    required this.coverUrl,
    required this.firstReleaseDate,
  });

  factory GameResult.fromJson(Map<String, dynamic> json) {
    return GameResult(
      id: json['id'],
      name: json['name'],
      coverUrl: json['coverUrl'],
      firstReleaseDate: json['firstReleaseDate'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'coverUrl': coverUrl,
      'firstReleaseDate': firstReleaseDate,
    };
  }
}
