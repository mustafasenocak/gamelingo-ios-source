import 'dart:io';
import 'package:flutter/material.dart';

enum ConnectionGuide { television, playstation }

/// Available again from both connection screens; setup never depends on a Mac.
class ConnectionGuidePage extends StatefulWidget {
  const ConnectionGuidePage({
    super.key,
    this.initialGuide = ConnectionGuide.television,
  });
  final ConnectionGuide initialGuide;

  @override
  State<ConnectionGuidePage> createState() => _ConnectionGuidePageState();
}

class _ConnectionGuidePageState extends State<ConnectionGuidePage> {
  late ConnectionGuide _guide = widget.initialGuide;

  @override
  Widget build(BuildContext context) {
    final android = Platform.isAndroid;
    final tv = _guide == ConnectionGuide.television;
    return Scaffold(
      appBar: AppBar(title: const Text('Adım adım kurulum')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          SegmentedButton<ConnectionGuide>(
            segments: const [
              ButtonSegment(
                value: ConnectionGuide.television,
                label: Text('TV altyazısı'),
                icon: Icon(Icons.tv),
              ),
              ButtonSegment(
                value: ConnectionGuide.playstation,
                label: Text('PS5 bağlantısı'),
                icon: Icon(Icons.sports_esports_outlined),
              ),
            ],
            selected: {_guide},
            onSelectionChanged: (value) =>
                setState(() => _guide = value.single),
          ),
          const SizedBox(height: 24),
          Text(
            tv ? 'Çeviriyi oyun ekranında gör' : 'Kamera kullanmadan çeviri',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 12),
          Text(
            tv
                ? 'Telefon çeviriyi yapar; TV, telefondan gelen Türkçe altyazıyı gösterir. Seslendirme telefondan gelir. Her iki cihaza da aynı Game Lingo uygulamasını kurarsın.'
                : 'PS5 görüntüsü aynı ağ üzerinden telefonuna gelir. Game Lingo yalnızca ekranın alt bölümündeki yazıları okur; oyunun altyazıları açık olmalı. Bilgisayar veya kamera gerekmez.',
          ),
          const SizedBox(height: 20),
          if (tv) ...[
            const _GuideStep(
              1,
              'TV’nin uyumunu kontrol et',
              'Android TV veya Google TV’de Play Store’u aç, “Game Lingo”yu arat ve yükle. Uygulama TV mağazanda görünmüyorsa bu TV ya da bölge henüz desteklenmiyor olabilir. Normal LCD monitöre doğrudan altyazı eklenmez. HDMI üzerinde gösterim, TV’nin üstte gösterme desteğine bağlıdır.',
            ),
            const _GuideStep(
              2,
              'Telefon ve TV’yi aynı ağa bağla',
              'TV altyazıları için aktif Premium gerekir; mevcut telefon aboneliğin TV’de de geçerlidir. Telefonda Premium’u satın al veya satın alımları geri yükle. İki cihazı aynı ev modemine bağla; TV Ethernet ile de bağlı olabilir. Aboneliği doğrulamak için ikisinin de internete erişmesi gerekir. Ücretsiz kamera denemesi TV erişimi sağlamaz.',
            ),
            const _GuideStep(
              3,
              'TV’de altyazı iznini aç',
              'Kumandayla Ana ekran → Uygulamalar → Game Lingo’yu aç. “Altyazı gösterme izni”ne bas, Game Lingo için “Diğer uygulamaların üzerinde göster” iznini aç ve geri tuşuyla uygulamaya dön. Bu izin, Türkçe yazının HDMI oyun görüntüsünün üzerinde görünmesini sağlar.',
            ),
            const _GuideStep(
              4,
              'TV kodunu telefonla tara',
              'TV’de “Telefonu bağla”ya bas. Telefonda Game Lingo → TV simgesi → “TV kodunu tara” yolunu açıp bu TV’nin QR kodunu okut. Kamera izni yalnızca QR kodunu okumak içindir. Yerel ağ izni sorulursa izin ver. Birden fazla TV varsa yalnızca kullanacağın TV’nin ekranındaki kodu tara. Kod 5 dakika içinde kullanılmalı; süresi dolarsa TV’den yeni kod oluştur.',
            ),
            const _GuideStep(
              5,
              'Test et ve oyuna dön',
              'Telefonda “TV’ye test yazısı gönder”e bas. Yazıyı gördükten sonra TV kumandasıyla konsolun HDMI girişine geç. Telefon uygulamasına dön: PS5 çevirisinde “Altyazı” veya “İkisi” modunu seçip “Altyazıyı TV’ye de gönder”i aç; kamera çevirisinde oyunun özgün altyazısını tarama alanına al. Game Lingo telefonda açık kalsın.',
            ),
            const _GuideStep(
              6,
              'Oturumu yönet',
              'Bitirdiğinde telefondan çeviriyi durdur ve TV bağlantısını kes. TV’de Game Lingo → “Bağlantıyı kapat” ile de durdurabilirsin. TV bağlantısı en fazla 2 saat sürer; süre dolunca yeni QR koduyla eşleştir. Yeniden kurulum için bilgisayar gerekmez.',
            ),
          ] else ...[
            const _GuideStep(
              1,
              'PS5 ve telefonu aynı ağa bağla',
              'PS5 açık olsun. Telefonu ve PS5’i aynı modeme bağla; PS5’te Ethernet de kullanılabilir. Çeviri ve ElevenLabs sesi için internet gerekir. Yeni bir Wi-Fi ağına geçtiğinde kayıtlı eşleşmeyi silme; bağlantı ekranındaki “Bu ağda PS5 ara” ile konsolunu yeniden bul.',
            ),
            _GuideStep(
              2,
              'Telefon internetini kullanacaksan',
              android
                  ? 'Telefonda Ayarlar → Bağlantılar / Ağ ve internet → Mobil erişim noktası bölümünü aç. PS5 → Ayarlar → Ağ → Ayarlar → İnternet Bağlantısını Ayarla yolundan telefonun ağını seç. Menü adları telefon markasına göre değişebilir. PS5 bulunamazsa “Adresle bul”u dene; bazı telefonlar erişim noktası üzerinden cihaz bağlantısına izin vermez. Bu durumda iki cihazı aynı Wi-Fi ağına bağla.'
                  : 'iPhone’da Ayarlar → Kişisel Erişim Noktası → Diğerleri Katılabilsin seçeneğini aç. PS5 → Ayarlar → Ağ → Ayarlar → İnternet Bağlantısını Ayarla yolundan iPhone’un ağını seç. PS5 bulunamazsa “Adresle bul”u dene. Bağlantı yine kurulmazsa iki cihazı aynı Wi-Fi ağına bağla.',
            ),
            const _GuideStep(
              3,
              'Çeviri için ikinci PSN hesabını hazırla',
              'PS5’te ikinci bir kullanıcı profili aç ve ayrı bir PlayStation Network hesabıyla giriş yap. Yalnızca yerel bir profil oluşturmak yeterli değildir. İkinci profilde Ayarlar → Sistem → Uzaktan Oynama → Uzaktan Oynama’yı Etkinleştir seçeneğini aç. Kumandayla oynarken ana hesabını kullanacaksın.',
            ),
            const _GuideStep(
              4,
              'Sony hesabını telefondan onayla',
              'Game Lingo’nun PS5 bağlantı ekranında “PlayStation hesabına bağlan”a, ardından “Sony sayfasında onayla”ya bas. Sony’nin kendi sayfasında ikinci PSN hesabınla giriş yapıp onayla, sonra Game Lingo’ya dön. Ana hesabını yanlışlıkla seçtiysen doğru ikinci hesapla yeniden bağlan.',
            ),
            const _GuideStep(
              5,
              'Konsolu seç ve 8 haneli kodu gir',
              '“Bu ağda PS5 ara”ya bas ve konsolunun adını kontrol ederek seç. Bulunmazsa PS5 → Ayarlar → Ağ → Bağlantı Durumu → Bağlantı Durumunu Görüntüle bölümündeki IP adresini “Adresle bul”a yaz. İkinci profil açıkken Ayarlar → Sistem → Uzaktan Oynama → Cihazı Eşleştir ekranındaki 8 haneli kodu uygulamaya gir. Kod süresi dolarsa PS5’ten yenisini al.',
            ),
            const _GuideStep(
              6,
              'Oyununu ve çeviri biçimini seç',
              'Kumandadan ana profiline geçip oyunu aç. Oyun ayarlarında Subtitles / Altyazılar seçeneğini aç. Game Lingo’da oyununu seç; “Ses”, “Altyazı” veya “İkisi” modunu aç. TV’ye yazı için ayrıca TV’yi QR ile eşleştirip “Altyazıyı TV’ye de gönder”i etkinleştir. Ses telefondan gelir; TV eşleştirmesi ses için gerekli değildir.',
            ),
            const _GuideStep(
              7,
              'Çeviriyi başlat',
              '“ElevenLabs sesini dene” ile telefonun sesini kontrol et, ardından “Kamerasız çeviriyi başlat”a bas. Game Lingo ekranda açık kalmalı; telefonu kilitlemek veya başka uygulamaya geçmek çeviriyi durdurur. Çeviri, oyunun alt kısmında yeni bir yazı göründüğünde gelir. Konuşmada ekranda altyazı yoksa çevrilecek metin de yoktur.',
            ),
          ],
          const SizedBox(height: 16),
          Text(
            'Bir adımda takılırsan',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const _Help(
            'TV kodu okunmuyor',
            'TV’de bağlantıyı kapatıp yeniden “Telefonu bağla”ya bas. Ekrandaki yeni QR kodunun tamamını telefon kamerasına al. Telefon ve TV’nin aynı ağda olduğunu kontrol et.',
          ),
          const _Help(
            'TV bağlı ama yazı yok',
            'Önce “TV’ye test yazısı gönder”i dene. Test görünmüyorsa TV’nin üstte gösterme iznini kontrol et. Test görünüyorsa Altyazı/İkisi modunu, “Altyazıyı TV’ye de gönder” seçeneğini ve oyunun İngilizce altyazı ayarını kontrol et. Harici TV kutusunun yazısı, TV’nin başka bir HDMI girişindeki PS5 görüntüsüne eklenemez.',
          ),
          const _Help(
            'PS5 bulunamıyor veya bağlantı kesiliyor',
            'PS5 açık, Uzaktan Oynama etkin ve iki cihaz aynı ağda olmalı. Misafir ağından çık; VPN kullanıyorsan yerel ağ erişimini kontrol et. Konsolun güncel IP adresini “Adresle bul”a gir. Kumandada ana hesabını, Game Lingo bağlantısında ikinci PSN hesabını kullan.',
          ),
          const _Help(
            'Yazı var ama ses yok',
            'Ses veya İkisi modunu seç. Telefonun medya sesini yükselt ve sesin Bluetooth kulaklığa yönlenmediğini kontrol et. “ElevenLabs sesini dene”yi kullan; internet erişimini kontrol et. Telefon kilitliyse Game Lingo’yu yeniden açıp çeviriyi başlat.',
          ),
          const _Help(
            'Konuşmalar geriden geliyor',
            'Telefonu modeme yaklaştır; mümkünse PS5’i Ethernet ile bağla. Game Lingo’da “Biriken konuşmalara yetiş”i aç ve konuşma hızını artır. Çok uzun bir kuyruk oluşursa çeviriyi durdurup yeniden başlat.',
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Bağlantı ekranına dön'),
          ),
        ],
      ),
    );
  }
}

class _GuideStep extends StatelessWidget {
  const _GuideStep(this.number, this.title, this.description);
  final int number;
  final String title, description;
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$number. $title',
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(description, style: const TextStyle(height: 1.5)),
        ],
      ),
    ),
  );
}

class _Help extends StatelessWidget {
  const _Help(this.title, this.answer);
  final String title, answer;
  @override
  Widget build(BuildContext context) => ExpansionTile(
    title: Text(title),
    tilePadding: EdgeInsets.zero,
    childrenPadding: const EdgeInsets.only(bottom: 16),
    children: [Text(answer, style: const TextStyle(height: 1.5))],
  );
}
