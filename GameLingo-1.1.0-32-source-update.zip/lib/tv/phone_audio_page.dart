import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../voices/elevenlabs_speech_player.dart';
import 'phone_audio_controller.dart';
import 'phone_game_translator.dart';
import 'ps5_discovery.dart';
import 'remote_play_bridge.dart';
import 'tv_link_hub.dart';
import 'tv_pairing_scanner_page.dart';
import 'tv_relay_client.dart';
import 'ps5_game_picker.dart';
import 'translation_access.dart';
import 'tv_premium_access.dart';
import 'translation_sample_page.dart';
import 'connection_guide_page.dart';

enum Ps5OutputMode { voice, subtitles, both }

class PhoneAudioPage extends StatefulWidget {
  const PhoneAudioPage({super.key, this.access});
  final TranslationAccess? access;
  @override
  State<PhoneAudioPage> createState() => _PhoneAudioPageState();
}

class _PhoneAudioPageState extends State<PhoneAudioPage>
    with WidgetsBindingObserver {
  final _pin = TextEditingController(), _ip = TextEditingController();
  final _game = TextEditingController(text: 'Grand Theft Auto V');
  int? _gameId;
  late final ElevenLabsSpeechPlayer _speech;
  late final PhoneAudioController _controller;
  final _tv = TvLinkHub.instance;
  bool _sendToTv = false;
  bool _hotspot = false, _testing = false, _initialState = true;
  String _voiceStatus = '', _voiceName = '';
  int _step = 0;
  Timer? _healthTimer;
  Timer? _usageTimer;
  bool _accounting = false, _accessChecking = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _speech = ElevenLabsSpeechPlayer(
      nativePlayback: Platform.isIOS && remotePlayEnabled,
      onMetric: (name, ms) => _controller.recordMetric(name, ms),
      onStatus: (status, voice) {
        if (mounted) {
          setState(() {
            _voiceStatus = status;
            _voiceName = voice;
          });
        }
      },
    );
    _controller = PhoneAudioController(
      native: IPhoneRemotePlayBridge(),
      finder: LocalPs5Finder(),
      makeTranslator: PhoneGameTranslator.new,
      stopSpeech: _speech.stop,
      onSpeechRate: _speech.setRate,
      prepareSpeech: (line, game, translator) => _speech.prepare(
        line.translation!,
        gameName: game,
        gameId: _gameId,
        speaker: subtitleSpeaker(line.source),
        gender: translator is PhoneGameTranslator
            ? translator.genderFor(line.source)
            : 'unknown',
      ),
      onSubtitleScene: (scene) {
        if (!_sendToTv || _tv.client.state != TvLinkState.connected) return;
        if (scene.regions.isEmpty) {
          _tv.client.clear();
        } else {
          _tv.client.sendScene(scene);
        }
      },
      speak: (line, game, translator) => _speech.speak(
        line.translation!,
        gameName: game,
        gameId: _gameId,
        rate: line.playbackRate,
        speaker: subtitleSpeaker(line.source),
        gender: translator is PhoneGameTranslator
            ? translator.genderFor(line.source)
            : 'unknown',
      ),
    )..addListener(_changed);
    _tv.addListener(_tvChanged);
    unawaited(_load());
    unawaited(_controller.initialize());
    _usageTimer = Timer.periodic(const Duration(seconds: 1), (_) async {
      if (!mounted ||
          _accounting ||
          _controller.phase != 'streaming' ||
          !_controller.foreground) {
        return;
      }
      final access = widget.access;
      if (access == null) return;
      _accounting = true;
      try {
        if (!await access.consumeSeconds(1) && mounted) {
          await _controller.stop();
          if (mounted) await access.expired();
        }
      } on Object {
        await _controller.stop();
        if (mounted) {
          _notice('Kullanım süresi kaydedilemedi. Çeviriyi yeniden başlat.');
        }
      } finally {
        _accounting = false;
      }
    });
  }

  Future<void> _startTranslation() async {
    if (_accessChecking) return;
    setState(() => _accessChecking = true);
    try {
      final access = widget.access;
      final allowed = access != null
          ? await access.request()
          : const bool.fromEnvironment('GAME_LINGO_PHONE_AUDIO_PREVIEW');
      if (!mounted || !allowed) return;
      await _save();
      await _controller.start(_game.text.trim());
    } on Object {
      if (mounted) {
        _notice(
          'Çeviri erişimi kontrol edilemedi. İnternet bağlantını kontrol edip yeniden dene.',
        );
      }
    } finally {
      if (mounted) setState(() => _accessChecking = false);
    }
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _hotspot = prefs.getBool('ps5_phone_hotspot') ?? false;
      _game.text = prefs.getString('ps5_phone_game') ?? 'Grand Theft Auto V';
      _gameId = prefs.getInt('ps5_phone_game_id');
      final seconds = prefs.getInt('ps5_background_seconds') ?? 7200;
      _controller.backgroundSeconds =
          const [1800, 3600, 7200, 14400].contains(seconds) ? seconds : 7200;
    });
    _controller.setTiming(
      rate: prefs.getDouble('ps5_speech_rate') ?? 1.1,
      automatic: prefs.getBool('ps5_automatic_timing') ?? true,
    );
    final mode = prefs.getString('ps5_output_mode') ?? 'voice';
    _setMode(
      Ps5OutputMode.values.firstWhere(
        (m) => m.name == mode,
        orElse: () => Ps5OutputMode.voice,
      ),
      save: false,
    );
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('ps5_phone_hotspot', _hotspot);
    await prefs.setString('ps5_phone_game', _game.text.trim());
    if (_gameId != null) {
      await prefs.setInt('ps5_phone_game_id', _gameId!);
    } else {
      await prefs.remove('ps5_phone_game_id');
    }
    await prefs.setDouble('ps5_speech_rate', _controller.baseSpeechRate);
    await prefs.setBool('ps5_automatic_timing', _controller.automaticCatchUp);
    await prefs.setInt('ps5_background_seconds', _controller.backgroundSeconds);
    await prefs.setString('ps5_output_mode', _mode.name);
  }

  Ps5OutputMode get _mode => _controller.voiceEnabled
      ? _controller.subtitlesEnabled
            ? Ps5OutputMode.both
            : Ps5OutputMode.voice
      : Ps5OutputMode.subtitles;

  void _setMode(Ps5OutputMode mode, {bool save = true}) {
    _controller.setOutputs(
      voice: mode != Ps5OutputMode.subtitles,
      subtitles: mode != Ps5OutputMode.voice,
    );
    if (save) unawaited(_save());
  }

  void _tvChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _selectGame() async {
    final game = await Navigator.of(context).push<Ps5GameChoice>(
      MaterialPageRoute(builder: (_) => const Ps5GamePicker()),
    );
    if (!mounted || game == null) return;
    setState(() {
      _game.text = game.name;
      _gameId = game.id;
    });
    await _save();
  }

  Future<void> _connectTv() async {
    final subscription = await TvPremiumAccess.request(context);
    if (!mounted || subscription == null) return;
    final pairing = await Navigator.of(context).push<TvPairing>(
      MaterialPageRoute(builder: (_) => const TvPairingScannerPage()),
    );
    if (!mounted || pairing == null) return;
    try {
      await _tv.client.connect(pairing, subscription: subscription);
      if (mounted && _tv.client.state == TvLinkState.connected) {
        setState(() => _sendToTv = true);
      }
    } on TvPremiumException catch (error) {
      _notice(error.message);
    } on Object {
      _notice(
        'TV’ye bağlanılamadı. TV’de yeni eşleştirme kodu açıp yeniden dene.',
      );
    }
  }

  Future<void> _showSubtitles() => Navigator.of(context).push<void>(
    MaterialPageRoute(
      builder: (_) => ListenableBuilder(
        listenable: _controller,
        builder: (context, _) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            title: const Text('Türkçe altyazı'),
            backgroundColor: Colors.black,
          ),
          body: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(28),
                child: Text(
                  _controller.subtitlesEnabled &&
                          _controller.lastTranslation.isNotEmpty
                      ? _controller.lastTranslation
                      : _controller.active
                      ? 'Altyazı bekleniyor…'
                      : 'Çeviri durduruldu.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 28,
                    height: 1.4,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );

  void _changed() {
    if (!mounted) return;
    _tv.keepAliveInBackground =
        _controller.active && _controller.backgroundTaskActive;
    setState(() {
      final c = _controller;
      if (_initialState &&
          c.phase != 'initializing' &&
          c.phase != 'uninitialized') {
        _initialState = false;
        if (c.paired) _step = 4;
      }
      if (c.phase == 'awaitingPin' && _step == 1) _step = 2;
      if (c.phase == 'paired' && _step == 3) _step = 4;
    });
    _healthTimer ??= Timer(const Duration(milliseconds: 500), () {
      _healthTimer = null;
      unawaited(_health());
    });
  }

  Future<void> _health() async {
    try {
      final c = _controller;
      final directory = await getApplicationDocumentsDirectory();
      await File('${directory.path}/phone-audio-health.json').writeAsString(
        jsonEncode({
          'at': DateTime.now().toUtc().toIso8601String(),
          'phase': c.phase,
          'foreground': c.foreground,
          'paired': c.paired,
          'found': c.nearby.length,
          'selected': c.selected != null,
          'frames': c.frames,
          'spoken': c.spoken,
          'errors': c.errors,
          'waiting': c.waiting,
          'hotspot': _hotspot,
          'step': _step,
          'message': c.message,
          'voice': _voiceName,
          'outputMode': _mode.name,
          'tvConnected': _tv.client.state == TvLinkState.connected,
          'sendToTv': _sendToTv,
          'performance': c.diagnostics,
        }),
      );
    } on Object {
      /* Diagnostic failure must not interrupt the user. */
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_controller.setForeground(true));
    } else if (state == AppLifecycleState.paused) {
      unawaited(_controller.setForeground(false));
      if (!_controller.active || !_controller.voiceEnabled) _speech.stop();
    } else if (state == AppLifecycleState.detached) {
      if (_controller.active ||
          _controller.preparing ||
          _controller.searching) {
        unawaited(_controller.stop());
      }
      _speech.stop();
      // Sony's browser approval must be allowed to finish while outside the app.
    }
  }

  Future<void> _sony() async {
    final url = _controller.approvalUrl;
    if (url == null) return;
    try {
      if (!await launchUrl(url, mode: LaunchMode.inAppBrowserView)) {
        _notice('Sony sayfası açılamadı. Yeniden dene.');
      }
    } on Object {
      _notice('Sony sayfası açılamadı. Yeniden dene.');
    }
  }

  void _notice(String text) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    }
  }

  Future<void> _test() async {
    setState(() => _testing = true);
    try {
      await _speech.speak(
        'Game Lingo hazır. Oyun altyazılarını Türkçe olarak buradan dinleyeceksin.',
        gameName: _game.text.trim(),
        gameId: _gameId,
        rate: _controller.baseSpeechRate,
      );
    } on Object {
      _notice(
        'Ses alınamadı. İnternetini ve telefonun ses düzeyini kontrol et.',
      );
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Widget _paragraph(String text) =>
      Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(text));
  Widget _next(int step) => FilledButton(
    onPressed: _controller.busy || _testing
        ? null
        : () {
            unawaited(_save());
            setState(() => _step = step);
          },
    child: const Text('Devam et'),
  );

  @override
  Widget build(BuildContext context) {
    final c = _controller;
    final locked = c.busy || _testing;
    return Scaffold(
      appBar: AppBar(
        title: const Text('PS5 · Canlı çeviri'),
        actions: [
          IconButton(
            tooltip: 'Adım adım PS5 kurulumu',
            icon: const Icon(Icons.help_outline),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const ConnectionGuidePage(
                  initialGuide: ConnectionGuide.playstation,
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Ana sayfa',
            onPressed: () async {
              await c.stop();
              if (context.mounted) {
                Navigator.of(context).pushReplacementNamed('/home');
              }
            },
            icon: const Icon(Icons.home_outlined),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'PS5 görüntüsü doğrudan telefonuna gelir. Alt bölümdeki yazıları Türkçe altyazı, ElevenLabs sesi veya ikisi birlikte takip edebilirsin.',
                ),
                const SizedBox(height: 10),
                TextButton.icon(
                  onPressed: locked
                      ? null
                      : () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const TranslationSamplePage(),
                          ),
                        ),
                  icon: const Icon(Icons.play_circle_outline),
                  label: const Text('PS5 bağlamadan örnek çeviriyi dene'),
                ),
                Text(
                  c.preparing
                      ? 'Çeviri hazırlanıyor…'
                      : switch (c.phase) {
                          'initializing' ||
                          'uninitialized' => 'Bağlantı hazırlanıyor…',
                          'signingIn' => 'Sony girişi hazırlanıyor…',
                          'awaitingApproval' => 'Sony onayı bekleniyor',
                          'pairing' => 'PS5 eşleştiriliyor…',
                          'connecting' => 'PS5 görüntüsüne bağlanıyor…',
                          'streaming' => 'Bağlı · ${c.waiting} altyazı sırada',
                          'paired' => 'PS5 eşleşmesi kayıtlı',
                          'unavailable' => 'Bu sürümde bağlantı açılamadı',
                          _ => 'Kurulum adımlarını tamamla',
                        },
                  style: const TextStyle(
                    color: Color(0xFFB9AAFF),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (c.message.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      c.message,
                      style: const TextStyle(color: Colors.orangeAccent),
                    ),
                  ),
                if (c.busy || _testing) ...[
                  const SizedBox(height: 10),
                  const LinearProgressIndicator(),
                  TextButton(
                    onPressed: () {
                      _speech.stop();
                      unawaited(c.stop());
                    },
                    child: const Text('Durdur'),
                  ),
                ],
              ],
            ),
          ),
          Expanded(
            child: Stepper(
              currentStep: _step,
              onStepTapped: (value) {
                if (!locked) setState(() => _step = value);
              },
              controlsBuilder: (_, _) => const SizedBox.shrink(),
              steps: [
                Step(
                  title: const Text('Bağlantını seç'),
                  isActive: _step == 0,
                  content: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SegmentedButton<bool>(
                        segments: const [
                          ButtonSegment(
                            value: false,
                            label: Text('Wi-Fi'),
                            icon: Icon(Icons.wifi),
                          ),
                          ButtonSegment(
                            value: true,
                            label: Text('Telefon interneti'),
                            icon: Icon(Icons.cell_tower),
                          ),
                        ],
                        selected: {_hotspot},
                        onSelectionChanged: locked
                            ? null
                            : (value) {
                                setState(() => _hotspot = value.first);
                                unawaited(_save());
                              },
                      ),
                      const SizedBox(height: 16),
                      if (_hotspot) ...[
                        _paragraph(
                          Platform.isAndroid
                              ? '1. Telefonda Ayarlar → Bağlantılar / Ağ ve internet → Mobil erişim noktası bölümünü aç. Menü adları telefon markasına göre değişebilir.'
                              : '1. iPhone’da Ayarlar → Kişisel Erişim Noktası → Diğerleri Katılabilsin seçeneğini aç.',
                        ),
                        _paragraph(
                          '2. PS5’te Ayarlar → Ağ → Ayarlar → İnternet Bağlantısını Ayarla yolundan telefonunun ağını seç ve şifresini gir.',
                        ),
                        _paragraph(
                          '3. PS5 bağlandıktan sonra Game Lingo’ya dön. Bulunamazsa “Adresle bul” seçeneğini dene. Bağlantı kurulamıyorsa Wi-Fi seçeneğine geçip iki cihazı aynı modeme bağla.',
                        ),
                        _paragraph(
                          'Bu bağlantıyı ilk kullanımda test et. Seslendirme için mobil internet erişimi de gerekli.',
                        ),
                      ] else ...[
                        _paragraph(
                          '1. Telefonunu ve PS5’i aynı modem ağına bağla. PS5 modemine Ethernet kablosuyla da bağlanabilir.',
                        ),
                        _paragraph(
                          '2. Misafir ağı yerine cihazların birbirini görebildiği normal ağı kullan. Çeviri ve ElevenLabs sesi için internet açık olmalı.',
                        ),
                      ],
                      _paragraph(
                        'Yerel Ağ izni istenirse izin ver. Ağ değiştirince eşleşmeyi silme; “Bu ağda PS5 ara” ile kayıtlı konsolunu yeniden bul.',
                      ),
                      _next(c.paired ? 2 : 1),
                    ],
                  ),
                ),
                Step(
                  title: const Text('PlayStation hesabını bağla'),
                  isActive: _step == 1,
                  state: c.onlineId.isNotEmpty
                      ? StepState.complete
                      : StepState.indexed,
                  content: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _paragraph(
                        'PS5’te çeviri için ikinci bir profil aç ve bu profilde ayrı bir PSN hesabıyla giriş yap. Ana hesabını oyunu kumandayla oynamak için kullanacaksın.',
                      ),
                      _paragraph(
                        'İkinci profilde Ayarlar → Sistem → Uzaktan Oynama → Uzaktan Oynama’yı Etkinleştir seçeneğini aç.',
                      ),
                      if (c.onlineId.isNotEmpty)
                        _paragraph('Bağlı hesap: ${c.onlineId}'),
                      if (!c.paired)
                        FilledButton(
                          onPressed: locked ? null : c.signIn,
                          child: const Text('PlayStation hesabına bağlan'),
                        ),
                      if (c.phase == 'awaitingApproval') ...[
                        if (c.approvalCode.isNotEmpty)
                          SelectableText('Onay kodu: ${c.approvalCode}'),
                        FilledButton(
                          onPressed: c.approvalUrl == null ? null : _sony,
                          child: const Text('Sony sayfasında onayla'),
                        ),
                        _paragraph(
                          'Sony sayfasında ikinci PSN hesabınla giriş yap. Onaylayınca bu ekrana dön. Kod yenilenirse sayfayı düğmeden yeniden aç.',
                        ),
                      ],
                      if (c.onlineId.isNotEmpty && !locked) _next(2),
                    ],
                  ),
                ),
                Step(
                  title: const Text('PS5’ini bul ve seç'),
                  isActive: _step == 2,
                  state: c.selected != null
                      ? StepState.complete
                      : StepState.indexed,
                  content: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _paragraph(
                        'PS5 açık olsun. Birden fazla konsol görünürse kullanacağın PS5 Slim’i seç. Konsol adını PS5 → Ayarlar → Sistem → Sistem Yazılımı → Konsol Bilgileri bölümünde kontrol edebilirsin.',
                      ),
                      FilledButton.icon(
                        onPressed: locked ? null : () => c.search(),
                        icon: const Icon(Icons.search),
                        label: Text(
                          c.searching ? 'Aranıyor…' : 'Bu ağda PS5 ara',
                        ),
                      ),
                      for (final console in c.nearby)
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(
                            c.selected?.id == console.id
                                ? Icons.check_circle
                                : Icons.sports_esports_outlined,
                          ),
                          title: Text(console.name),
                          subtitle: Text(
                            '${console.ip} · ${console.ready ? 'Açık' : 'Dinlenme modunda'}',
                          ),
                          onTap: locked ? null : () => c.select(console),
                        ),
                      ExpansionTile(
                        title: const Text('Adresle bul'),
                        tilePadding: EdgeInsets.zero,
                        children: [
                          _paragraph(
                            'Otomatik arama bulamazsa PS5 → Ayarlar → Ağ → Bağlantı Durumu → Bağlantı Durumunu Görüntüle bölümündeki IP adresini buraya gir.',
                          ),
                          TextField(
                            controller: _ip,
                            enabled: !locked,
                            keyboardType: const TextInputType.numberWithOptions(
                              decimal: true,
                            ),
                            decoration: const InputDecoration(
                              labelText: 'PS5’in bu ağdaki IP adresi',
                            ),
                          ),
                          OutlinedButton(
                            onPressed: locked
                                ? null
                                : () => c.search(host: _ip.text.trim()),
                            child: const Text('Bu adreste ara'),
                          ),
                        ],
                      ),
                      if (c.selected != null)
                        _next(
                          c.paired
                              ? 4
                              : c.onlineId.isEmpty
                              ? 1
                              : 3,
                        ),
                    ],
                  ),
                ),
                Step(
                  title: const Text('Eşleştirme kodunu gir'),
                  isActive: _step == 3,
                  state: c.paired ? StepState.complete : StepState.indexed,
                  content: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _paragraph(
                        'PS5’te ikinci profil açıkken Ayarlar → Sistem → Uzaktan Oynama → Cihazı Eşleştir bölümünü aç. Ekrandaki 8 haneli kodu aşağıya gir.',
                      ),
                      TextField(
                        controller: _pin,
                        enabled: !locked && !c.paired,
                        obscureText: true,
                        autocorrect: false,
                        enableSuggestions: false,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(8),
                        ],
                        decoration: const InputDecoration(
                          labelText: '8 haneli kod',
                        ),
                      ),
                      const SizedBox(height: 12),
                      FilledButton(
                        onPressed:
                            locked ||
                                c.paired ||
                                c.selected == null ||
                                c.onlineId.isEmpty
                            ? null
                            : () {
                                final code = _pin.text;
                                _pin.clear();
                                unawaited(c.pair(code));
                              },
                        child: const Text('PS5’i eşleştir'),
                      ),
                      if (c.paired) ...[
                        _paragraph(
                          'Eşleşme telefonuna kaydedildi. Wi-Fi değişince tekrar kod girmen gerekmez.',
                        ),
                        _next(4),
                      ],
                    ],
                  ),
                ),
                Step(
                  title: const Text('Çeviri biçimini seç ve başlat'),
                  isActive: _step == 4,
                  content: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _paragraph(
                        'Kumandadan ana profiline geçip oyunu aç. Oyun ayarlarında İngilizce altyazıları açık tut; Game Lingo bu yazıları doğrudan PS5 görüntüsünden okuyacak.',
                      ),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(_game.text),
                        subtitle: const Text('Oyun seç / değiştir'),
                        leading: const Icon(Icons.sports_esports_outlined),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: locked ? null : _selectGame,
                      ),
                      const Text('Çeviri biçimi'),
                      const SizedBox(height: 8),
                      SegmentedButton<Ps5OutputMode>(
                        segments: const [
                          ButtonSegment(
                            value: Ps5OutputMode.voice,
                            label: Text('Ses'),
                          ),
                          ButtonSegment(
                            value: Ps5OutputMode.subtitles,
                            label: Text('Altyazı'),
                          ),
                          ButtonSegment(
                            value: Ps5OutputMode.both,
                            label: Text('İkisi'),
                          ),
                        ],
                        selected: {_mode},
                        onSelectionChanged: _testing
                            ? null
                            : (modes) => _setMode(modes.single),
                      ),
                      const SizedBox(height: 16),
                      if (c.voiceEnabled)
                        _paragraph(
                          'Kayıtlı karakter seslerin kullanılır. Konuşanın adı altyazıda belirtilmiyorsa genel ElevenLabs anlatıcısı kullanılır.',
                        ),
                      if (c.voiceEnabled)
                        OutlinedButton.icon(
                          onPressed: locked ? null : _test,
                          icon: const Icon(Icons.volume_up_outlined),
                          label: const Text('ElevenLabs sesini dene'),
                        ),
                      if (c.voiceEnabled && _voiceStatus.isNotEmpty)
                        _paragraph(_voiceStatus),
                      if (c.voiceEnabled) ...[
                        Text(
                          'Konuşma hızı · ${c.baseSpeechRate.toStringAsFixed(1)}×',
                        ),
                        Slider(
                          value: c.baseSpeechRate,
                          min: .9,
                          max: 1.4,
                          divisions: 5,
                          label: '${c.baseSpeechRate.toStringAsFixed(1)}×',
                          onChanged: (rate) {
                            c.setTiming(
                              rate: rate,
                              automatic: c.automaticCatchUp,
                            );
                            unawaited(_save());
                          },
                        ),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('Biriken konuşmalara yetiş'),
                          subtitle: const Text(
                            'Kuyruk uzayınca konuşma hızı kontrollü artar.',
                          ),
                          value: c.automaticCatchUp,
                          onChanged: (value) {
                            c.setTiming(
                              rate: c.baseSpeechRate,
                              automatic: value,
                            );
                            unawaited(_save());
                          },
                        ),
                      ],
                      if (c.subtitlesEnabled) ...[
                        _paragraph(
                          'Türkçe altyazı bu telefonda gösterilir. Uyumlu Android/Google TV’ye de gönderebilirsin.',
                        ),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('Altyazıyı TV’ye de gönder'),
                          subtitle: Text(
                            _tv.client.state == TvLinkState.connected
                                ? '${_tv.client.tvName ?? 'TV'} bağlı'
                                : 'TV’de Game Lingo’yu açıp “Telefonu bağla” kodunu tara.',
                          ),
                          value: _sendToTv,
                          onChanged: (enabled) {
                            if (enabled &&
                                _tv.client.state != TvLinkState.connected) {
                              if (c.active) {
                                _notice(
                                  'TV’yi eşleştirmek için önce çeviriyi durdur.',
                                );
                                return;
                              }
                              unawaited(_connectTv());
                            } else {
                              setState(() => _sendToTv = enabled);
                              if (!enabled) _tv.client.clear();
                            }
                          },
                        ),
                        if (_tv.client.state != TvLinkState.connected)
                          OutlinedButton.icon(
                            onPressed: locked ? null : _connectTv,
                            icon: const Icon(Icons.qr_code_scanner),
                            label: const Text('Game Lingo TV’yi eşleştir'),
                          ),
                        ExpansionTile(
                          tilePadding: EdgeInsets.zero,
                          title: const Text(
                            'TV’de eşleştirme kodu nasıl açılır?',
                          ),
                          children: [
                            _paragraph(
                              'Kumandadan Ana ekran → Uygulamalar → Game Lingo → Telefonu bağla yolunu aç. Kod görünmüyorsa Bağlantıyı kapat, ardından Telefonu bağla düğmesine bas.',
                            ),
                            _paragraph(
                              'Game Lingo listede görünmüyorsa TV Ayarları → Uygulamalar → Tüm uygulamalar → Game Lingo → Aç yolunu kullan. QR kodunu okuttuktan sonra PS5’in HDMI girişine dön.',
                            ),
                          ],
                        ),
                      ],
                      FilledButton.icon(
                        onPressed: locked || !c.paired || _accessChecking
                            ? null
                            : _startTranslation,
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('Kamerasız çeviriyi başlat'),
                      ),
                      _paragraph(
                        'Çeviri sırasında Game Lingo’yu ekranda açık tut. Ekran kilitlenirse veya başka uygulamaya geçersen çeviri durur. TV’ye gönderiyorsan TV’yi PS5’in HDMI girişine geçir.',
                      ),
                      if (c.subtitlesEnabled)
                        OutlinedButton.icon(
                          onPressed: _showSubtitles,
                          icon: const Icon(Icons.fullscreen),
                          label: const Text('Altyazıyı büyük ekranda oku'),
                        ),
                      if (c.subtitlesEnabled && c.lastTranslation.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          child: Text(
                            c.lastTranslation,
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ),
                      if (c.paired && !locked)
                        TextButton(
                          onPressed: () async {
                            final remove = await showDialog<bool>(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text(
                                  'PS5 eşleşmesi kaldırılsın mı?',
                                ),
                                content: const Text(
                                  'Yalnızca başka bir konsol veya PSN hesabına geçerken gerekir. Ağ değiştirmek için kaldırmana gerek yok.',
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, false),
                                    child: const Text('Vazgeç'),
                                  ),
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, true),
                                    child: const Text('Kaldır'),
                                  ),
                                ],
                              ),
                            );
                            if (remove == true) {
                              await c.forget();
                              if (mounted) setState(() => _step = 0);
                            }
                          },
                          child: const Text('Başka PS5 / eşleşmeyi kaldır'),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _usageTimer?.cancel();
    _tv.keepAliveInBackground = false;
    WidgetsBinding.instance.removeObserver(this);
    _healthTimer?.cancel();
    _controller.removeListener(_changed);
    _tv.removeListener(_tvChanged);
    _controller.dispose();
    unawaited(_speech.dispose());
    _pin.dispose();
    _ip.dispose();
    _game.dispose();
    super.dispose();
  }
}
