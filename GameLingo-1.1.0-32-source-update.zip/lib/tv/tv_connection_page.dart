import 'package:flutter/material.dart';
import 'tv_relay_client.dart';
import 'tv_link_hub.dart';
import 'tv_pairing_scanner_page.dart';
import 'connection_guide_page.dart';
import 'tv_premium_access.dart';
export 'tv_link_hub.dart';

// Same phone application pairs with Game Lingo on Android TV.
const tvRelayEnabled = bool.fromEnvironment(
  'GAME_LINGO_TV_ENABLED',
  defaultValue: false,
);

class TvConnectButton extends StatelessWidget {
  const TvConnectButton({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: TvLinkHub.instance,
    builder: (context, _) => IconButton(
      tooltip: 'TV’ye bağlan',
      icon: Icon(
        TvLinkHub.instance.client.state == TvLinkState.connected
            ? Icons.connected_tv_rounded
            : Icons.tv_rounded,
        color: const Color(0xFFB9AAFF),
      ),
      onPressed: () => Navigator.of(
        context,
      ).push(MaterialPageRoute<void>(builder: (_) => const TvConnectionPage())),
    ),
  );
}

class TvConnectionPage extends StatefulWidget {
  const TvConnectionPage({super.key});
  @override
  State<TvConnectionPage> createState() => _TvConnectionPageState();
}

class _TvConnectionPageState extends State<TvConnectionPage> {
  final hub = TvLinkHub.instance;
  Future<void> scan() async {
    final subscription = await TvPremiumAccess.request(context);
    if (!mounted || subscription == null) return;
    final pairing = await Navigator.of(context).push<TvPairing>(
      MaterialPageRoute(builder: (_) => const TvPairingScannerPage()),
    );
    if (!mounted || pairing == null) return;
    try {
      await hub.client.connect(pairing, subscription: subscription);
    } on TvPremiumException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } catch (_) {
      /* The client state supplies the recoverable error UI. */
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('TV bağlantısı'),
      actions: [
        IconButton(
          tooltip: 'Adım adım TV kurulumu',
          icon: const Icon(Icons.help_outline),
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => const ConnectionGuidePage(),
            ),
          ),
        ),
      ],
    ),
    body: ListenableBuilder(
      listenable: hub,
      builder: (context, _) {
        final state = hub.client.state;
        final connected = state == TvLinkState.connected;
        return ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const Icon(
              Icons.connected_tv_rounded,
              size: 72,
              color: Color(0xFFB9AAFF),
            ),
            const SizedBox(height: 24),
            Text(
              connected
                  ? '${hub.client.tvName ?? 'TV'} bağlı'
                  : 'Çevirileri TV’de gör',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const ConnectionGuidePage(),
                ),
              ),
              icon: const Icon(Icons.menu_book_outlined),
              label: const Text('İlk kez mi bağlıyorsun? Kurulum rehberi'),
            ),
            const SizedBox(height: 12),
            const Text(
              'TV altyazıları aktif Premium abonelik gerektirir; mevcut telefon aboneliğin TV’de de geçerlidir. Telefon ve TV aynı Wi-Fi ağına ve internete bağlı olmalı. TV’de Game Lingo → “Telefonu bağla”ya bas, sonra aşağıdan TV’nin QR kodunu tara. Ücretsiz kamera denemesi TV erişimi sağlamaz.',
            ),
            const SizedBox(height: 16),
            const Text(
              'TV’deki Game Lingo, telefonda oluşturulan Türkçe altyazıları gösterir. Seslendirme telefondan gelir. TV’nin diğer uygulamaların üzerinde gösterme izni açık olmalı. İlk eşleştirmeden sonra aşağıdaki test düğmesiyle bağlantıyı kontrol et.',
              style: TextStyle(color: Colors.white60),
            ),
            if (state == TvLinkState.error) ...[
              const SizedBox(height: 16),
              const Text(
                'TV bağlantısı kurulamadı veya kesildi. İki cihazın aynı ağda olduğunu ve yerel ağ izninin açık olduğunu kontrol et. TV’de yeni bir QR kodu oluşturup tekrar tara.',
                style: TextStyle(color: Colors.orangeAccent),
              ),
            ],
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: state == TvLinkState.connecting ? null : scan,
              icon: const Icon(Icons.qr_code_scanner),
              label: Text(
                state == TvLinkState.connecting
                    ? 'TV’ye bağlanıyor…'
                    : 'TV kodunu tara',
              ),
            ),
            if (connected) ...[
              const SizedBox(height: 16),
              DropdownButtonFormField<bool>(
                initialValue: hub.client.captionAtTop,
                decoration: const InputDecoration(
                  labelText: 'TV’de altyazı konumu',
                ),
                items: const [
                  DropdownMenuItem(value: true, child: Text('Üstte')),
                  DropdownMenuItem(value: false, child: Text('Altta')),
                ],
                onChanged: (value) => hub.client.captionAtTop = value ?? true,
              ),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () => hub.client.sendCaption(
                  'Game Lingo TV bağlantısı hazır.',
                  durationMs: 8000,
                ),
                child: const Text('TV’ye test yazısı gönder'),
              ),
              TextButton(
                onPressed: hub.client.disconnect,
                child: const Text('Bağlantıyı kes'),
              ),
              const Text(
                'TV’de konsolun HDMI girişine geç. Ardından bu ekrandan geri dönüp oyunun için kamera çevirisini başlat. Game Lingo telefonda açık kalmalı. Kamera tarama alanına yalnızca oyunun özgün altyazılarını al.',
              ),
            ],
          ],
        );
      },
    ),
  );
}
