import 'package:flutter/material.dart';
import 'tv_premium_proof.dart';

/// Wired to the app's existing store purchase controller at startup.
class TvPremiumAccess {
  static Future<TvPremiumProof> Function()? verify;
  static Future<void> Function(BuildContext)? openPremium;

  static Future<TvPremiumProof?> request(BuildContext context) async {
    final provider = verify;
    if (provider == null) {
      _notice(context, const TvPremiumException('subscription_check_failed'));
      return null;
    }
    try {
      return await provider();
    } on TvPremiumException catch (error) {
      if (!context.mounted) return null;
      if (error.code == 'premium_required' && openPremium != null) {
        await openPremium!(context);
        if (!context.mounted) return null;
        try {
          return await provider();
        } on TvPremiumException catch (retry) {
          if (context.mounted) _notice(context, retry);
        }
      } else {
        _notice(context, error);
      }
      return null;
    }
  }

  static void _notice(BuildContext context, TvPremiumException error) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(error.message)));
  }
}
