/// A store verification reference sent only over the QR-pinned TV connection.
/// The TV independently checks it with Game Lingo's subscription backend.
class TvPremiumProof {
  TvPremiumProof({required this.store, required this.verificationId}) {
    if (!['apple', 'google_play'].contains(store) ||
        verificationId.length < 6 ||
        verificationId.length > 2000 ||
        RegExp(r'[\s\x00-\x1f\x7f]').hasMatch(verificationId)) {
      throw const FormatException('Abonelik doğrulama bilgisi geçersiz.');
    }
  }
  final String store, verificationId;
  Map<String, String> toJson() => {
    'store': store,
    'verificationId': verificationId,
  };
  @override
  String toString() => 'TvPremiumProof($store, redacted)';
}

class TvPremiumException implements Exception {
  const TvPremiumException(this.code);
  final String code;
  String get message => switch (code) {
    'premium_required' =>
      'TV altyazıları için aktif Premium abonelik gerekiyor. Telefonda Premium’u aç veya satın alımları geri yükle.',
    'update_required' =>
      'Telefon ve TV’deki Game Lingo’yu en güncel sürüme yükselt.',
    _ =>
      'Premium abonelik doğrulanamadı. Telefonun ve TV’nin internet bağlantısını kontrol edip yeniden dene.',
  };
  @override
  String toString() => message;
}
