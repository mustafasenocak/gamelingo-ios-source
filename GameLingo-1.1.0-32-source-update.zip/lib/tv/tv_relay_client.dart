import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'positioned_text.dart';
import 'tv_premium_proof.dart';
export 'tv_premium_proof.dart';

enum TvLinkState { disconnected, connecting, connected, error }

class TvPairing {
  const TvPairing._(
    this.host,
    this.port,
    this.fingerprint,
    this.key,
    this.name,
  );
  final String host, fingerprint, key, name;
  final int port;
  factory TvPairing.parse(String code) {
    if (code.length > 2048) throw const FormatException('Geçersiz TV kodu.');
    final uri = Uri.parse(code);
    final q = uri.queryParameters;
    if (uri.scheme != 'gamelingo-tv' ||
        uri.host != 'pair' ||
        uri.path.isNotEmpty ||
        uri.userInfo.isNotEmpty ||
        uri.hasPort ||
        uri.hasFragment ||
        q['v'] != '2' ||
        uri.queryParametersAll.values.any((values) => values.length != 1)) {
      throw const FormatException('Bu bir Game Lingo TV kodu değil.');
    }
    final host = q['host'] ?? '';
    final ip = InternetAddress.tryParse(host);
    final parts = ip?.rawAddress;
    final private =
        ip?.type == InternetAddressType.IPv4 &&
        parts != null &&
        (parts[0] == 10 ||
            (parts[0] == 172 && parts[1] >= 16 && parts[1] <= 31) ||
            (parts[0] == 192 && parts[1] == 168));
    final port = int.tryParse(q['port'] ?? '') ?? 0;
    if (!private ||
        ip!.address != host ||
        port < 1024 ||
        port > 65535 ||
        !RegExp(r'^[a-f0-9]{64}$').hasMatch(q['pin'] ?? '') ||
        !RegExp(r'^[A-Za-z0-9_-]{43}$').hasMatch(q['key'] ?? '') ||
        (q['name'] ?? '').length > 80) {
      throw const FormatException('TV eşleştirme bilgileri geçersiz.');
    }
    return TvPairing._(
      host,
      port,
      q['pin']!,
      q['key']!,
      q['name'] ?? 'Game Lingo TV',
    );
  }
  // Never put the QR's secret in logs, preferences or analytics.
  @override
  String toString() => 'TvPairing($name)';
}

String boundedTvCaption(String value) {
  var text = value
      .replaceAll(RegExp(r'[\u0000-\u0008\u000B\u000C\u000E-\u001F]'), '')
      .trim();
  if (text.length <= 500) return text;
  text = text.substring(0, 500);
  final last = text.codeUnitAt(text.length - 1);
  if (last >= 0xD800 && last <= 0xDBFF) {
    text = text.substring(0, text.length - 1);
  }
  return text;
}

/// Local TLS, pinned to the certificate scanned from the selected TV.
class TvRelayClient {
  final _changes = StreamController<TvLinkState>.broadcast(sync: true);
  Stream<TvLinkState> get changes => _changes.stream;
  TvLinkState state = TvLinkState.disconnected;
  String? tvName;
  SecureSocket? _socket;
  StreamSubscription<List<int>>? _subscription;
  Completer<void>? _ready;
  Timer? _heartbeat;
  int _generation = 0, _sequence = 0;
  DateTime _lastReceive = DateTime.now();
  Map<String, Object>? _pending;
  bool _sending = false;
  bool captionAtTop = true;
  bool supportsPositionedText = false;
  int maxSceneRegions = 32;
  void _state(TvLinkState value) {
    state = value;
    _changes.add(value);
  }

  Future<void> connect(
    TvPairing pairing, {
    required TvPremiumProof subscription,
  }) async {
    disconnect();
    final generation = _generation;
    tvName = pairing.name;
    _state(TvLinkState.connecting);
    try {
      final socket = await SecureSocket.connect(
        pairing.host,
        pairing.port,
        context: SecurityContext(withTrustedRoots: false),
        onBadCertificate: (cert) =>
            sha256.convert(cert.der).toString() == pairing.fingerprint,
        timeout: const Duration(seconds: 15),
      );
      if (generation != _generation) {
        socket.destroy();
        throw StateError('Bağlantı iptal edildi.');
      }
      if (socket.peerCertificate == null ||
          sha256.convert(socket.peerCertificate!.der).toString() !=
              pairing.fingerprint) {
        socket.destroy();
        throw const HandshakeException('TV sertifikası eşleşmiyor.');
      }
      _socket = socket;
      unawaited(
        socket.done.then<void>(
          (_) {
            if (generation == _generation) _drop(TvLinkState.error);
          },
          onError: (Object _, StackTrace _) {
            if (generation == _generation) _drop(TvLinkState.error);
          },
        ),
      );
      _ready = Completer<void>();
      final bytes = <int>[];
      _subscription = socket.listen(
        (chunk) {
          if (generation != _generation) return;
          try {
            for (final byte in chunk) {
              if (byte == 10) {
                final frame =
                    jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
                bytes.clear();
                if (frame['v'] == 2 && frame['type'] == 'error') {
                  final error = TvPremiumException(
                    frame['code'] == 'premium_required'
                        ? 'premium_required'
                        : 'subscription_check_failed',
                  );
                  if (!_ready!.isCompleted) _ready!.completeError(error);
                  _drop(TvLinkState.error);
                  return;
                }
                if (frame['v'] != 2 ||
                    !['ready', 'pong'].contains(frame['type'])) {
                  throw const FormatException('TV protokolü geçersiz.');
                }
                _lastReceive = DateTime.now();
                if (frame['type'] == 'ready' && !_ready!.isCompleted) {
                  final features = frame['features'];
                  supportsPositionedText =
                      features is List &&
                      features.contains('positioned_text_v1');
                  final limit = frame['maxSceneRegions'];
                  maxSceneRegions = limit is int && limit >= 1 && limit <= 128
                      ? limit
                      : 32;
                  _ready!.complete();
                }
              } else {
                if (bytes.length >= 8192) {
                  throw const FormatException('TV yanıtı çok uzun.');
                }
                bytes.add(byte);
              }
            }
          } catch (_) {
            if (generation == _generation) _drop(TvLinkState.error);
          }
        },
        onError: (Object _) {
          if (generation == _generation) _drop(TvLinkState.error);
        },
        onDone: () {
          if (generation == _generation) _drop(TvLinkState.error);
        },
        cancelOnError: true,
      );
      socket.write(
        '${jsonEncode({'v': 2, 'type': 'hello', 'key': pairing.key, 'subscription': subscription.toJson()})}\n',
      );
      await _ready!.future.timeout(const Duration(seconds: 25));
      if (generation != _generation) throw StateError('Bağlantı iptal edildi.');
      _lastReceive = DateTime.now();
      _state(TvLinkState.connected);
      _heartbeat = Timer.periodic(const Duration(seconds: 10), (_) {
        if (generation != _generation) return;
        if (DateTime.now().difference(_lastReceive).inSeconds >= 30) {
          _drop(TvLinkState.error);
          return;
        }
        try {
          socket.write('{"v":2,"type":"ping"}\n');
        } catch (_) {
          _drop(TvLinkState.error);
        }
      });
    } catch (_) {
      if (generation == _generation) _drop(TvLinkState.error);
      rethrow;
    }
  }

  void sendCaption(String text, {int? durationMs}) {
    if (state != TvLinkState.connected) return;
    final caption = boundedTvCaption(text);
    _pending = caption.isEmpty
        ? {'type': 'clear'}
        : {
            'type': 'caption',
            'text': caption,
            'durationMs': (durationMs ?? (caption.length * 80 + 3000)).clamp(
              3000,
              15000,
            ),
            'position': captionAtTop ? 'top' : 'bottom',
          };
    if (!_sending) unawaited(_pump());
  }

  void clear() => sendCaption('');

  /// Requires coordinates from a direct game frame, never raw camera coordinates.
  void sendScene(PositionedTvScene scene) {
    if (state != TvLinkState.connected) return;
    if (!supportsPositionedText) {
      throw UnsupportedError('TV’deki Game Lingo sürümü güncellenmeli.');
    }
    if (scene.regions.length > maxSceneRegions) {
      throw ArgumentError('TV scene exceeds the negotiated region limit.');
    }
    final frame = scene.toJson();
    // Leave space for protocol metadata and UTF-8 escaping on the wire.
    if (utf8.encode(jsonEncode(frame)).length > 32000) {
      throw ArgumentError('TV scene is too large.');
    }
    _pending = frame;
    if (!_sending) unawaited(_pump());
  }

  Future<void> _pump() async {
    _sending = true;
    final generation = _generation;
    try {
      while (_pending != null && _socket != null && generation == _generation) {
        final frame = _pending!;
        _pending = null;
        final socket = _socket!;
        socket.write('${jsonEncode({'v': 2, 'seq': ++_sequence, ...frame})}\n');
        await socket.flush().timeout(const Duration(seconds: 3));
      }
    } catch (_) {
      if (generation == _generation) _drop(TvLinkState.error);
    } finally {
      if (generation == _generation) {
        _sending = false;
        if (_pending != null && state == TvLinkState.connected) {
          unawaited(_pump());
        }
      }
    }
  }

  void disconnect() => _drop(TvLinkState.disconnected);
  void _drop(TvLinkState next) {
    _generation++;
    _heartbeat?.cancel();
    _heartbeat = null;
    final ready = _ready;
    _ready = null;
    if (ready != null && !ready.isCompleted) {
      ready.completeError(StateError('TV bağlantısı kapandı.'));
    }
    unawaited(_subscription?.cancel());
    _subscription = null;
    _socket?.destroy();
    _socket = null;
    _pending = null;
    _sending = false;
    _sequence = 0;
    supportsPositionedText = false;
    maxSceneRegions = 32;
    _state(next);
  }

  Future<void> dispose() async {
    disconnect();
    await _changes.close();
  }
}
