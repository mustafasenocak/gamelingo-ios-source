import 'package:flutter_test/flutter_test.dart';
import 'package:oyun_ceviri/tv/tv_relay_client.dart';

void main() {
  String code({
    String host = '192.168.68.105',
    String port = '45000',
    String? pin,
    String? key,
  }) => Uri(
    scheme: 'gamelingo-tv',
    host: 'pair',
    queryParameters: {
      'v': '2',
      'host': host,
      'port': port,
      'pin': pin ?? List.filled(64, 'a').join(),
      'key': key ?? List.filled(43, 'b').join(),
      'name': 'Beko Google TV QLED',
    },
  ).toString();
  test(
    'Pairs with the QR-selected private IPv4 TV; token stays out of display text',
    () {
      final pairing = TvPairing.parse(code());
      expect(pairing.host, '192.168.68.105');
      expect(pairing.port, 45000);
      expect(pairing.name, 'Beko Google TV QLED');
      expect(pairing.toString(), isNot(contains(pairing.key)));
    },
  );
  test(
    'Rejects public addresses, loopback, DNS names and unsupported endpoint ranges',
    () {
      for (final host in [
        '8.8.8.8',
        '127.0.0.1',
        '169.254.1.2',
        'example.com',
        '::1',
        '172.32.0.1',
      ]) {
        expect(
          () => TvPairing.parse(code(host: host)),
          throwsFormatException,
          reason: host,
        );
      }
      for (final port in ['0', '80', '65536', 'abc']) {
        expect(() => TvPairing.parse(code(port: port)), throwsFormatException);
      }
    },
  );
  test('Rejects missing pins, weak tokens and ambiguous QR parameters', () {
    expect(
      () => TvPairing.parse(code().replaceFirst('v=2', 'v=1')),
      throwsFormatException,
    );
    expect(() => TvPairing.parse(code(pin: '')), throwsFormatException);
    expect(() => TvPairing.parse(code(key: '123456')), throwsFormatException);
    expect(
      () => TvPairing.parse('${code()}&host=192.168.1.1'),
      throwsFormatException,
    );
    expect(
      () => TvPairing.parse(code().replaceFirst('gamelingo-tv:', 'https:')),
      throwsFormatException,
    );
    expect(() => TvPairing.parse('${code()}#extra'), throwsFormatException);
  });
  test('Limits subtitle length without breaking an emoji surrogate pair', () {
    expect(boundedTvCaption(' Türkçe\naltyazı\u0000 '), 'Türkçe\naltyazı');
    final result = boundedTvCaption('${List.filled(499, 'a').join()}🎮!');
    expect(result.length, 499);
    expect(boundedTvCaption(List.filled(600, 'ğ').join()).length, 500);
  });
  test('Does not queue captions before pairing or after disconnect', () async {
    final client = TvRelayClient();
    client.sendCaption('Cannot be delivered');
    expect(client.state, TvLinkState.disconnected);
    client.disconnect();
    client.sendCaption('Cannot be replayed into a later session');
    expect(client.state, TvLinkState.disconnected);
    await client.dispose();
  });
}
