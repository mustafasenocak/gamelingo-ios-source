import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:oyun_ceviri/tv/tv_premium_access.dart';
import 'package:oyun_ceviri/tv/tv_premium_proof.dart';

void main() {
  tearDown(() {
    TvPremiumAccess.verify = null;
    TvPremiumAccess.openPremium = null;
  });
  test(
    'Store proof rejects unknown stores and keeps identifiers out of logs',
    () {
      expect(
        () => TvPremiumProof(
          store: 'free_trial',
          verificationId: 'fake-reference',
        ),
        throwsFormatException,
      );
      expect(
        () => TvPremiumProof(store: 'apple', verificationId: 'bad\nreference'),
        throwsFormatException,
      );
      final proof = TvPremiumProof(
        store: 'apple',
        verificationId: 'private-reference',
      );
      expect(proof.toString(), isNot(contains('private-reference')));
    },
  );
  Future<BuildContext> page(WidgetTester tester) async {
    late BuildContext context;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Builder(
            builder: (c) {
              context = c;
              return const Text('TV');
            },
          ),
        ),
      ),
    );
    return context;
  }

  testWidgets('A missing configuration fails closed', (tester) async {
    final context = await page(tester);
    expect(await TvPremiumAccess.request(context), isNull);
  });
  testWidgets('Unpaid and cancelled purchase cannot obtain TV proof', (
    tester,
  ) async {
    final context = await page(tester);
    var paywallOpened = 0;
    TvPremiumAccess.verify = () async =>
        throw const TvPremiumException('premium_required');
    TvPremiumAccess.openPremium = (_) async {
      paywallOpened++;
    };
    expect(await TvPremiumAccess.request(context), isNull);
    expect(paywallOpened, 1);
  });
  testWidgets(
    'Successful purchase or restore is verified again before TV access',
    (tester) async {
      final context = await page(tester);
      var premium = false, calls = 0;
      TvPremiumAccess.verify = () async {
        calls++;
        if (!premium) throw const TvPremiumException('premium_required');
        return TvPremiumProof(
          store: 'google_play',
          verificationId: 'private-purchase-token',
        );
      };
      TvPremiumAccess.openPremium = (_) async {
        premium = true;
      };
      expect(await TvPremiumAccess.request(context), isA<TvPremiumProof>());
      expect(calls, 2);
    },
  );
  testWidgets(
    'A verification outage cannot grant access or trigger another purchase',
    (tester) async {
      final context = await page(tester);
      TvPremiumAccess.verify = () async =>
          throw const TvPremiumException('subscription_check_failed');
      TvPremiumAccess.openPremium = (_) async {
        fail('Outage must not ask for payment');
      };
      expect(await TvPremiumAccess.request(context), isNull);
    },
  );
}
