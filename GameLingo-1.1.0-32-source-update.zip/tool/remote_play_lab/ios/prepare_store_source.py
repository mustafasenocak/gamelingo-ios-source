#!/usr/bin/env python3
"""Prepare and verify the authorized iPhone corresponding-source package.
Never uploads. Excludes the server, admin app, credentials and device records.
"""
from pathlib import Path
import argparse, hashlib, json, re, subprocess, zipfile, os
ROOT=Path(__file__).resolve().parents[3]
parser=argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args=parser.parse_args()
OUT=args.out.resolve()
OUT.mkdir(parents=True,exist_ok=True)
version=re.search(r'^version:\s*(\S+)',(ROOT/'pubspec.yaml').read_text(),re.M).group(1)
version_name, build_number=version.split('+')
archive=OUT/('GameLingo-'+version.replace('+','-')+'-source.zip')
if archive.exists(): raise RuntimeError('Refusing to overwrite an existing corresponding-source archive')
entries={}
blocked={'.git','.dart_tool','build','Pods','xcuserdata','__pycache__','.gradle','node_modules','.symlinks'}
def add_tree(base,prefix):
 for p in sorted(base.rglob('*')):
  if not p.is_file() or p.is_symlink() or any(x in blocked for x in p.relative_to(base).parts): continue
  if p.name in ['.DS_Store','local.properties'] or p.suffix in ['.pyc','.a','.dylib','.so','.ipa','.apk','.aab','.mobileprovision','.p12','.p8']: continue
  entries[prefix+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
def add(name): entries[name]=(ROOT/name).read_bytes()
for name in ['lib','assets','test','packages','ios/Runner','ios/RunnerTests','ios/Runner.xcodeproj','ios/GameLingoVision','ios/RemotePlay/Classes','tool/remote_play_lab/vendor/chiaki-ng-core','tool/remote_play_lab/vendor/fmt']:
 add_tree(ROOT/name,name)
for name in ['pubspec.yaml','pubspec.lock','analysis_options.yaml','LICENSE-iOS','LICENSING-SCOPE.txt','ios/Podfile','ios/Podfile.lock','ios/Flutter/Debug.xcconfig','ios/Flutter/Release.xcconfig','ios/Flutter/AppFrameworkInfo.plist','ios/Runner.xcworkspace/contents.xcworkspacedata','ios/RemotePlay/GameLingoRemotePlay.podspec','tool/remote_play_lab/ios/build_engine.py','tool/remote_play_lab/ios/prepare_store_source.py']:
 add(name)
for p in (ROOT/'ios/RemotePlay/Engine').glob('*-LICENSE'): add(p.relative_to(ROOT).as_posix())
for name,digest in [('openssl-3.5.9.tar.gz','603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a'),('curl-8.23.0.tar.bz2','95b22eb32bf6d1fa6e3e9463bdb61cece3efc56d86576a9b3cbd428246a6d854')]:
 p=ROOT/'dependency-sources'/name
 if not p.exists(): p=next((Path.home()/'Library/Caches/Homebrew/downloads').glob('*--'+name))
 data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==digest
 entries['dependency-sources/'+name]=data
config=json.loads((ROOT/'.dart_tool/package_config.json').read_text())
from urllib.parse import unquote,urlparse
pub_names=[]
for p in config['packages']:
 uri=p['rootUri']
 if not uri.startswith('file:'): continue
 path=Path(unquote(urlparse(uri).path))
 if '/.pub-cache/hosted/pub.dev/' not in str(path): continue
 pub_names.append(path.name)
 add_tree(path,'dependency-sources/pub/'+path.name)
sdk=Path('/opt/homebrew/share/flutter')
for part in ['packages/flutter','packages/flutter_localizations','packages/flutter_test','engine/src/flutter']:
 add_tree(sdk/part,'dependency-sources/flutter/'+part)
entries['dependency-sources/flutter/LICENSE']=(sdk/'LICENSE').read_bytes()
flutter=json.loads(subprocess.check_output(['/opt/homebrew/share/flutter/bin/flutter','--version','--machine'],text=True))
entries['TOOLCHAIN.json']=json.dumps({k:flutter[k] for k in ['frameworkVersion','frameworkRevision','engineRevision','dartSdkVersion']},indent=2).encode()
# App-owned sources must never contain private keys or live tokens. Public
# upstream crypto fixtures and unmodified public package source are separate.
patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'(?:sk-[A-Za-z0-9_-]{20,}|sk_[A-Za-z0-9_-]{24,}|AIza[0-9A-Za-z_-]{30,}|ghp_[A-Za-z0-9]{25,})',rb'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}']
for name,data in entries.items():
 if name.startswith(('tool/remote_play_lab/vendor/','dependency-sources/')): continue
 if any(re.search(pattern,data) for pattern in patterns): raise RuntimeError('Possible credential; inspect file without printing value: '+name)
readme=f'''# Game Lingo iPhone {version} — Corresponding Source

The iPhone client is distributed under LICENSE-iOS: GNU AGPL-3.0-or-later
with the included OpenSSL and application-store additional permissions.
Copyright for Game Lingo client changes: Mustafa SENOCAK, 2026.
Third-party files retain their copyright and license notices. No server,
admin application, user data, PSN registration, API key, signing identity,
provisioning profile or device diagnostic record is included.

This version supports foreground translation. Screen-lock/background speech
is not advertised or enabled. The app keeps the iOS 15.5 deployment target.
Apple on-device Translation is used when the OS/language pair supports it;
on older iOS versions the Game Lingo online translation service is required.

## Contents and reproducible build inputs

- Flutter/Dart iPhone client, assets, tests and Xcode project.
- Apple Vision camera reader and Apple Translation bridge.
- Native PS5 bridge and patched chiaki-ng core (upstream revision
  ee7d5d8b2bdd32d0f1e4b9bdd466e738f4e62a4a); fmt 12.2.0 is header-only.
- Exact OpenSSL/curl source archives and public Dart/plugin source packages.
- pubspec.lock and TOOLCHAIN.json pin dependencies and the Flutter revision.
- SOURCE-MANIFEST.json lists SHA-256 for every source file in this archive.

## Build on macOS

Use Xcode 27.2, Python 3.9+, CMake, Ninja, Perl and CocoaPods 1.17.0.
Install Flutter {flutter['frameworkVersion']} at framework revision
{flutter['frameworkRevision']}. Its unmodified SDK, Dart/Flutter runtime
source and licenses are available from the official Flutter repositories:
https://github.com/flutter/flutter/tree/{flutter['frameworkRevision']}
https://github.com/flutter/flutter/tree/{flutter['frameworkRevision']}/engine
The unmodified Flutter framework and native engine source are also included
in dependency-sources/flutter. Dart SDK toolchain source: https://github.com/dart-lang/sdk
See TOOLCHAIN.json and the engine DEPS file for exact toolchain/dependency revisions.
Run these commands at the extracted project root (Flutter must be on PATH):

    flutter pub get
    python3 tool/remote_play_lab/ios/build_engine.py --minimum-ios 15.5
    GAME_LINGO_APP_STORE_RELEASE=1 flutter build ios --release --no-codesign --config-only --build-name={version_name} --build-number={build_number} --dart-define=GAME_LINGO_TV_ENABLED=true --dart-define=GAME_LINGO_PS5_ENABLED=true
    cd ios
    GAME_LINGO_APP_STORE_RELEASE=1 pod install
    cd ..
    GAME_LINGO_APP_STORE_RELEASE=1 xcodebuild -workspace ios/Runner.xcworkspace -scheme Runner -configuration Release -sdk iphoneos -destination generic/platform=iOS IPHONEOS_DEPLOYMENT_TARGET=15.5 CODE_SIGNING_ALLOWED=NO build

Use your own bundle/team signing settings to install on your devices. Apple
signing credentials are deliberately not included. Service endpoints are public
client configuration; access to paid third-party services remains subject to
those services' terms and availability. Source rights do not require a Premium
subscription. This package does not license Sony trademarks or grant PSN access.

## Changes to upstream components

The iOS core uses MIT fmt and the already vendored fast_float parser instead
of libc++ APIs unavailable on iOS 15.5. The provider retains earlier DTLS and
certificate-chain fixes. iOS native ML Kit binaries were removed; local MIT
Dart/plugin forks retain Android declarations only. Android is not a target of
this iPhone source release; backend and admin code are not relicensed.
'''
entries['README.md']=readme.encode()
manifest={'appVersion':version,'publicDistributionAuthorized':True,'scope':'iPhone client only','pubPackages':sorted(pub_names),'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())]}
entries['SOURCE-MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in sorted(entries.items()): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for x in manifest['files']: assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
result={'archive':archive.name,'bytes':archive.stat().st_size,'fileCount':len(entries),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'verified':True,'published':False}
(OUT/'README.md').write_text(readme);(OUT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'SHA256SUMS').write_text(result['sha256']+'  '+archive.name+'\n')
print(json.dumps(result))
